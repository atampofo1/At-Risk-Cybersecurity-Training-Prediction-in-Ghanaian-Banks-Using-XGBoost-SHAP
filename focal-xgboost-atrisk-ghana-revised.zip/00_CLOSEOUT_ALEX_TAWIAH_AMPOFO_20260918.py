"""
00_CLOSEOUT_ALEX_TAWIAH_AMPOFO_20260918.py

CLOSE-OUT SCRIPT. Source-code items only. Run it beside src/ (the folder
already committed inside focal-xgboost-atrisk-ghana-revised.zip) so its
imports resolve.

  RUN ANCHOR : RUN-ALEX_TAWIAH_AMPOFO-20260918
  OWNER      : ALEX TAWIAH AMPOFO

THE SCRIPT BELOW IS AN EXEMPLAR. IT IS NOT A FORCED SOLUTION. RUN IT IN
YOUR OWN ENVIRONMENT. CHECK EVERY COLUMN NAME, FILE PATH, OBJECT NAME, SEED,
LIBRARY VERSION AND DATA CONDITION. MODIFY IT WHERE YOUR STUDY CONTEXT
REQUIRES MODIFICATION. YOU OWN THE FINAL VERSION. DO NOT RUN IT BLINDLY.

IT PRODUCES EVIDENCE, NOT OUTCOMES. IT CAN COME BACK WITH A RESULT YOU DID
NOT WANT. THAT IS WHAT MAKES IT WORTH RUNNING. REPORT WHAT RETURNS, INCLUDING
WHEN IT CONTRADICTS YOUR DRAFT.

SOME OF THESE CLOSURES WILL MAKE YOUR NUMBER WORSE. THAT IS THE CORRECT
OUTCOME FOR SOME OF THE SEVENTEEN CAUSES. A SMALLER GAP AFTER FIXING A LEAK
IS THE FIRST HONEST NUMBER YOU HAVE HAD.

THIS IS THE LAST ENGINEERING PASS. AFTER THIS SCRIPT RETURNS, THE NUMBERS
ARE THE NUMBERS AND THE WRITING BEGINS.

RUN ORDER
  1. Place this file next to src/, requirements.txt (repo root).
  2. pip install -r requirements.txt
  3. RUN_CLOSE_BLOCKS is False below. Run Half 1 first:
       python 00_CLOSEOUT_ALEX_TAWIAH_AMPOFO_20260918.py --corpus field
       python 00_CLOSEOUT_ALEX_TAWIAH_AMPOFO_20260918.py --corpus ibm
  4. Paste back BOTH verdict tables before touching RUN_CLOSE_BLOCKS.
  5. Only then set RUN_CLOSE_BLOCKS = True and re-run to execute K1.
"""

# --------------------------------------------------------------------------
# ENV DETECT
# --------------------------------------------------------------------------
try:
    import google.colab  # noqa: F401
    ENV = "colab"
except ImportError:
    ENV = "local"
print("ENVIRONMENT:", ENV)

import argparse
import json
import math
import os
import re
import sys
import time
import warnings

warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd

# --------------------------------------------------------------------------
# CONFIG — every literal below carries a source comment (H14)
# --------------------------------------------------------------------------
SRC_DIR = "src"                                    # source: repo layout, README.md "Structure"
if SRC_DIR not in sys.path:
    sys.path.insert(0, SRC_DIR)

if ENV == "colab":
    DATA_DIR = "/content/drive/MyDrive/alexta_field"  # <<< FILL IN: your Drive folder >>>
else:
    DATA_DIR = "data"                                 # source: repo layout, README.md "Data"

FIELD_DATA_PATH = os.environ.get(
    "FIELD_DATA_PATH", os.path.join(DATA_DIR, "field_survey.xlsx")
)                                                      # <<< FILL IN: your field corpus file >>>

N_TRIALS_INNER = 8            # source: src/field_pipeline.py / ibm_pipeline.py, --trials default
N_SEEDS_REQUIRED = 10         # source: instrument SECTION 10, V1a / clearance C1
MODEL_SEEDS_10 = [42, 123, 456, 7, 19, 77, 101, 202, 303, 909]
                               # 42/123/456 are the three already used in Part 4 of
                               # full_diagnostic_battery.py; the other seven are added
                               # here only to reach the ten C1 requires — arbitrary,
                               # change them if you prefer, but publish whichever you use.
ALPHA_TWO_SIDED = 0.05        # source: Methods M16, "alpha = 0.05" convention used throughout
Z_ALPHA = 1.959964            # two-sided 95% critical z, for the CI and the MDE formula
Z_POWER80 = 0.841621          # z for 80% power, for the MDE formula (C3)
CI_LEVEL_TXT = "95%"

OUT_DIR = "closeout_output"   # everything this script writes goes here
os.makedirs(OUT_DIR, exist_ok=True)

RUN_CLOSE_BLOCKS = False      # F11 GATE. Set True only after BOTH Half-1 verdict
                               # tables have been returned and read. See RUN ORDER above.

# --------------------------------------------------------------------------
# IMPORTS FROM THE STUDENT'S OWN CODE (never re-implemented, always imported)
# --------------------------------------------------------------------------
try:
    from preprocessing import SEED, full_metrics, impute_per_fold, procedure_a_folds, procedure_b_split
    from focal_loss import focal_loss_obj, sigmoid
except ImportError as e:
    print("CODE EVIDENCE REQUIRED. Could not import preprocessing.py / focal_loss.py "
          "from", SRC_DIR, "-", e)
    print("Place this script beside src/ (repo root) and re-run. STOP.")
    sys.exit(1)

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
from sklearn.feature_selection import RFE
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_auc_score, f1_score, confusion_matrix, precision_score, recall_score
from imblearn.over_sampling import SMOTE
from xgboost import XGBClassifier
import xgboost as xgb
import shap
import optuna
from scipy.stats import wilcoxon, shapiro

optuna.logging.set_verbosity(optuna.logging.WARNING)

# --------------------------------------------------------------------------
# VERSION GUARD (H4) — pinned in requirements.txt; printed and asserted here
# --------------------------------------------------------------------------
EXPECTED_VERSIONS = {
    "numpy": "2.4.4", "pandas": "3.0.2", "sklearn": "1.8.0", "xgboost": "3.4.1",
    "imblearn": "0.14.2", "shap": "0.52.0", "optuna": "4.9.0", "scipy": "1.17.1",
}  # source: repo requirements.txt


def version_guard():
    import sklearn, xgboost as xgb_mod, imblearn, shap as shap_mod, optuna as optuna_mod, scipy
    got = {
        "numpy": np.__version__, "pandas": pd.__version__, "sklearn": sklearn.__version__,
        "xgboost": xgb_mod.__version__, "imblearn": imblearn.__version__,
        "shap": shap_mod.__version__, "optuna": optuna_mod.__version__, "scipy": scipy.__version__,
    }
    print("\n--- VERSION GUARD ---")
    mismatched = []
    for name, exp in EXPECTED_VERSIONS.items():
        g = got[name]
        flag = "OK" if g == exp else "MISMATCH"
        print(f"  {name:<10} expected {exp:<10} got {g:<10} {flag}")
        if g != exp:
            mismatched.append(name)
    if mismatched:
        print("  API MISMATCH — verify parameter names for your installed version:", mismatched)
    return mismatched


# --------------------------------------------------------------------------
# DATA LOADERS — reuse the student's own pipelines, not re-implemented
# --------------------------------------------------------------------------
def load_field():
    import field_pipeline as fp
    if not os.path.exists(FIELD_DATA_PATH):
        print("DATA NOT AVAILABLE. STOP.")
        print("  Looked for:", FIELD_DATA_PATH)
        print("  Set FIELD_DATA_PATH or edit CONFIG above.")
        sys.exit(1)
    df = fp.load_and_prepare(FIELD_DATA_PATH)
    X = df[fp.CANDIDATE_FEATURES].values.astype(float)
    y = df[fp.LABEL_COLUMN].values
    return X, y, list(fp.CANDIDATE_FEATURES), "FIELD (Ghana Banking Survey)"


def load_ibm():
    import ibm_pipeline as ip
    path = ip.download_data()
    df = ip.load_and_prepare(path)
    X = df[ip.FEATURES].values.astype(float)
    y = df[ip.LABEL_COLUMN].values
    return X, y, list(ip.FEATURES), "IBM HR Analytics (Validation Corpus)"


# --------------------------------------------------------------------------
# PREFLIGHT
# --------------------------------------------------------------------------
def preflight(X, y, candidate_features, corpus_label):
    print(f"\n--- PREFLIGHT: {corpus_label} ---")
    print(f"  shape X={X.shape} y={y.shape}")
    assert X.shape[0] == y.shape[0], "X/y row mismatch — SCHEMA finding, do not proceed silently."
    assert X.shape[1] == len(candidate_features), "candidate_features count != X columns."
    n_missing = np.isnan(X).sum(axis=0)
    for f, m in zip(candidate_features, n_missing):
        if m > 0:
            print(f"  missing: {f} = {int(m)} of {X.shape[0]} ({100*m/X.shape[0]:.1f}%)")
    pos = int((y == 1).sum()); neg = int((y == 0).sum())
    print(f"  class counts: positive={pos} ({100*pos/len(y):.1f}%)  negative={neg} ({100*neg/len(y):.1f}%)")
    print(f"  seed = {SEED}  (source: preprocessing.py SEED)")
    return dict(n=len(y), pos=pos, neg=neg, n_features=len(candidate_features))


# ==========================================================================
# HALF 1 — VERIFY (read-only w.r.t. the pipeline; safe to batch)
# ==========================================================================

# ---- V1a-f : the mandatory null-state block --------------------------------
# BLOCK V1 — TEN-SEED STABILITY, LEAVE-ONE-OUT, MDE, BASE RATE, LEAK SCAN, TUNING COUNTS
# CLOSES            : NULL STATE determination (C1, C2, C3, C5); evidence for C4, C6
# OPEN ITEM         : R10 claims "a supplementary ten-seed stability check ...
#                      confirmed the sign ... stable across all ten seeds" — the
#                      repository contains a three-seed block only (Part 4,
#                      model_seeds = [42, 123, 456]). No ten-seed, leave-one-out,
#                      MDE or leak-scan artefact exists anywhere in the tree.
#                      full_diagnostic_battery.py has no such block. CLAIMED, NOT PUSHED.
# ANSWERS           : which of the five null states (SECTION 10) this result is in
# EXPECTED DIRECTION: NEUTRAL — this block only measures; it does not change the pipeline
# RUNTIME           : dominant cost is V1a's 10-seed loop x 15 folds = 150 fits per
#                      corpus, a few minutes on CPU
# IF IT RETURNS
# SOMETHING BAD     : a sign flip across seeds, or MDE larger than the claimed
#                      effect, means STATE 5 (INCONCLUSIVE), not STATE 4. Do not
#                      write "no effect" — write the state-5 shape (SECTION 10).
# PASTE OUTPUT WHERE: Results R3 (seed decomposition), R10 (null state), and the
#                      null clearance certificate if you keep one in the appendix.
def block_v1_null_state(X_full, y_full, candidate_features, corpus_label, n_trials_inner):
    print(f"\n=== BLOCK V1 — NULL STATE ({corpus_label}) ===")
    outer_folds = list(procedure_a_folds(X_full, y_full))
    n_folds = len(outer_folds)

    # ---- V1f: tuning trial counts for every arm (C4 evidence) ----
    print("\n-- V1f: tuning trial counts per arm (static read of CONFIG, not a re-run) --")
    arms = ["baseline (tune_xgb)", "proposed (tune_focal)", "random_forest (tune_rf)",
            "logistic_regression (tune_lr)", "svm (tune_svm)"]
    for a in arms:
        print(f"  {a:<32} n_trials={n_trials_inner}  hyperparams=5  "
              f"(source: full_diagnostic_battery.py run_battery(), all five study_*.optimize calls)")
    print("  VERDICT: all five arms share n_trials and hyperparameter count -> C4 budget half is TRUE.")
    print("  C4 also requires a parity STATEMENT in the Methods — that half is a writing item, not this block's to close.")

    # ---- V1e: static leak scan (C6 evidence) ----
    print("\n-- V1e: static leak scan — every .fit(/.fit_transform( call, by line --")
    battery_path = os.path.join(SRC_DIR, "full_diagnostic_battery.py")
    if os.path.exists(battery_path):
        with open(battery_path) as fh:
            lines = fh.readlines()
        pat = re.compile(r"\.fit(_transform|_resample)?\(")
        for i, ln in enumerate(lines, start=1):
            if pat.search(ln):
                print(f"  {battery_path}:{i}  {ln.strip()[:90]}")
        print("  Read each line above against the split immediately preceding it in the same "
              "fold loop. A fit call using X_full, X_tmp or any object built before the fold's "
              "own train_test_split/outer index is a leak. None should appear outside a fold "
              "loop after K1 (Parts 2-5 now iterate outer_folds / a fresh split per fold).")
    else:
        print("  NOT IN SOURCE:", battery_path, "— run this script from the repo root.")

    # ---- V1d: base rate, per-class recall, confusion counts (C5 evidence) ----
    print("\n-- V1d: outcome base rate and confusion counts --")
    pos_rate = float(y_full.mean())
    trivial_acc = max(pos_rate, 1 - pos_rate)
    trivial_prec = pos_rate if pos_rate >= 0.5 else float("nan")
    trivial_f1 = (2 * trivial_prec * 1.0 / (trivial_prec + 1.0)) if pos_rate >= 0.5 else float("nan")
    print(f"  positive rate = {pos_rate:.4f}")
    print(f"  trivial (always-positive) classifier: accuracy={trivial_acc:.3f}  "
          f"F1={trivial_f1:.3f}  (QUOTED comparison basis only, not fed into any model)")

    # ---- V1a: ten-seed stability + V1b leave-one-fold-out + V1c MDE ----
    print(f"\n-- V1a: {len(MODEL_SEEDS_10)}-seed stability (partitioning fixed, model seed varied) --")
    print("  proposed model: fixed config matching Part 4's style (max_depth=3, eta=0.03, "
          "subsample=0.85, colsample_bytree=0.8, focal_loss_obj(0.95, 0.5))")
    print("  baseline model: identical config, standard logistic objective (no focal substitution)")
    deltas_per_seed = []
    per_fold_delta_by_seed = []
    for seed in MODEL_SEEDS_10:
        fold_deltas = []
        for tr_idx, te_idx in outer_folds:
            X_tr_raw, X_te_raw = X_full[tr_idx], X_full[te_idx]
            X_tr_raw, X_te_raw = impute_per_fold(X_tr_raw, X_te_raw, candidate_features)
            y_tr, y_te = y_full[tr_idx], y_full[te_idx]
            sc = MinMaxScaler(); X_tr = sc.fit_transform(X_tr_raw); X_te = sc.transform(X_te_raw)
            X_sm, y_sm = SMOTE(random_state=seed).fit_resample(X_tr, y_tr)

            base_m = XGBClassifier(objective="binary:logistic", n_estimators=200, max_depth=3,
                                    learning_rate=0.03, subsample=0.85, colsample_bytree=0.8,
                                    use_label_encoder=False, eval_metric="logloss",
                                    random_state=seed, verbosity=0)
            base_m.fit(X_sm, y_sm)
            base_prob = base_m.predict_proba(X_te)[:, 1]

            prop_bst = xgb.train({"max_depth": 3, "eta": 0.03, "subsample": 0.85,
                                   "colsample_bytree": 0.8, "seed": seed,
                                   "disable_default_eval_metric": 1},
                                  xgb.DMatrix(X_sm, label=y_sm), num_boost_round=200,
                                  obj=focal_loss_obj(0.95, 0.5))
            prop_prob = sigmoid(prop_bst.predict(xgb.DMatrix(X_te)))

            d = roc_auc_score(y_te, prop_prob) - roc_auc_score(y_te, base_prob)
            fold_deltas.append(d)
        per_fold_delta_by_seed.append(fold_deltas)
        seed_mean = float(np.mean(fold_deltas))
        deltas_per_seed.append(seed_mean)
        print(f"  seed {seed:<5} mean(delta AUC over {n_folds} folds) = {seed_mean:+.4f}")

    deltas_per_seed = np.array(deltas_per_seed)
    sign_flip_count = int(np.sum(np.sign(deltas_per_seed) != np.sign(deltas_per_seed[0])))
    print(f"  overall mean delta = {deltas_per_seed.mean():+.4f}  SD across seeds = {deltas_per_seed.std(ddof=1):.4f}")
    print(f"  sign-flip count against seed[0] = {sign_flip_count} of {len(MODEL_SEEDS_10)}")
    c1_pass = sign_flip_count == 0 and deltas_per_seed.std(ddof=1) < abs(deltas_per_seed.mean() + 1e-9) * 5
    print(f"  C1 (sign stable across >=10 seeds): {'CANDIDATE PASS' if sign_flip_count == 0 else 'FAIL — sign flips'}")

    # V1b: leave-one-fold-out on the seed[0] run
    print("\n-- V1b: leave-one-fold-out (does the conclusion survive dropping the largest contributor?) --")
    base_fold_deltas = np.array(per_fold_delta_by_seed[0])
    full_mean = base_fold_deltas.mean()
    worst_idx = int(np.argmax(np.abs(base_fold_deltas - full_mean)))
    loo_mean = np.delete(base_fold_deltas, worst_idx).mean()
    print(f"  full mean (seed[0]) = {full_mean:+.4f}")
    print(f"  largest-contributor fold index = {worst_idx}, its delta = {base_fold_deltas[worst_idx]:+.4f}")
    print(f"  mean with that fold removed   = {loo_mean:+.4f}")
    c2_pass = np.sign(loo_mean) == np.sign(full_mean) or abs(full_mean) < 1e-4
    print(f"  C2 (survives leave-one-out): {'CANDIDATE PASS' if c2_pass else 'FAIL — conclusion flips'}")

    # V1c: MDE at this n, paired solver
    print("\n-- V1c: minimum detectable effect (paired, 80% power, alpha=0.05 two-sided) --")
    sd_diff = base_fold_deltas.std(ddof=1)
    n_pairs = len(base_fold_deltas)
    mde = (Z_ALPHA + Z_POWER80) * sd_diff / math.sqrt(n_pairs)
    print(f"  SD of paired per-fold deltas = {sd_diff:.4f}  (n={n_pairs} folds)")
    print(f"  MDE at this n = {mde:.4f} AUC-ROC")
    print(f"  observed |mean delta| = {abs(full_mean):.4f}")
    c3_pass_route1 = abs(full_mean) >= mde  # a real effect this size would have been detectable
    c3_pass_route2 = True  # C3's second route: state INCONCLUSIVE + the required n — always available
    if c3_pass_route1:
        print("  C3 route 1: observed effect >= MDE -> the design COULD have detected an effect this size.")
    else:
        n_required = ((Z_ALPHA + Z_POWER80) * sd_diff / max(abs(full_mean), 1e-6)) ** 2
        print("  C3 route 1 FAILS: observed |delta| < MDE. Route 2 (always available): report INCONCLUSIVE.")
        print(f"  n folds that would have been required to detect the observed effect at 80% power "
              f"~= {n_required:.0f} (paired formula; treat as an order-of-magnitude guide, not a promise).")

    result = dict(
        corpus=corpus_label,
        v1a_seed_deltas={str(s): float(d) for s, d in zip(MODEL_SEEDS_10, deltas_per_seed)},
        v1a_sign_flip_count=sign_flip_count,
        v1b_full_mean=float(full_mean), v1b_loo_mean=float(loo_mean),
        v1b_dropped_fold_index=worst_idx,
        v1c_sd_diff=float(sd_diff), v1c_mde=float(mde),
        v1d_positive_rate=pos_rate, v1d_trivial_acc=trivial_acc, v1d_trivial_f1=trivial_f1,
        c1_candidate_pass=bool(sign_flip_count == 0),
        c2_candidate_pass=bool(c2_pass),
        c3_route1_pass=bool(c3_pass_route1),
    )
    return result


# ---- V2 : the "d = 8" claim, fork pattern -----------------------------------
# BLOCK V2 — FEATURE-COUNT FORK (Methods M2's "d = 8")
# CLOSES            : M2's declared feature dimensionality vs what the selection
#                      code in full_diagnostic_battery.py actually retains
# OPEN ITEM         : M2 states d = 8 for both corpora. The selection branch
#                      (n_sel = min(8, len(pruned)) if len(candidate_features) <= 10
#                      else min(12, len(pruned))) has been unchanged since commit
#                      e356689; it only started returning 9/12 instead of 8 once
#                      the corrected pipeline pushed both corpora's candidate
#                      counts past 10. This is a FORK, not a fix: the code may be
#                      correct and M2 wrong, or M2 may state the intended design
#                      and the branch threshold needs changing. Not this
#                      instrument's call (F10) — printed for the supervisor.
# ANSWERS           : how many features are actually selected per fold, right now
# EXPECTED DIRECTION: NEUTRAL — no pipeline change in this block
# RUNTIME           : seconds (reads CONFIG constants, no fits)
# IF IT RETURNS
# SOMETHING BAD     : n/a — this block cannot make the result worse, it only reports
# PASTE OUTPUT WHERE: Methods M2, and Results R6 (retention frequency totals)
def block_v2_feature_count_fork(candidate_features, corpus_label):
    print(f"\n=== BLOCK V2 — FEATURE-COUNT FORK ({corpus_label}) ===")
    n_cand = len(candidate_features)
    n_drop = max(1, n_cand // 5)
    pruned_len = n_cand - n_drop
    n_sel_as_coded = min(8, pruned_len) if n_cand <= 10 else min(12, pruned_len)
    n_sel_as_claimed = 8  # source: Methods M2, "d = 8"
    print(f"  candidate_features (n) = {n_cand}")
    print(f"  n_drop = max(1, n//5) = {n_drop}   pruned length = {pruned_len}")
    print(f"  branch taken: {'<=10 -> min(8, pruned)' if n_cand <= 10 else '>10 -> min(12, pruned)'}")
    print(f"  {'AS-CODED':<14}{'AS-CLAIMED (M2)':<18}{'GAP'}")
    print(f"  d={n_sel_as_coded:<12} d={n_sel_as_claimed:<16} {n_sel_as_coded - n_sel_as_claimed:+d}")
    print("  No verdict printed. Supervisor rules whether M2 or the selection branch changes. (F10)")
    return dict(n_candidates=n_cand, n_sel_as_coded=n_sel_as_coded, n_sel_as_claimed=n_sel_as_claimed)


# ---- V3 : per-fold test-n --------------------------------------------------
# BLOCK V3 — PER-FOLD OUTER TEST-N
# CLOSES            : Q5 "no per-fold test-n column" — Results Table 8
# OPEN ITEM         : the per-corpus results table has no per-fold n column
# ANSWERS           : the real outer-fold test sizes for this corpus, from the
#                      actual data (not a synthetic estimate)
# EXPECTED DIRECTION: NEUTRAL
# RUNTIME           : seconds
# IF IT RETURNS
# SOMETHING BAD     : n/a
# PASTE OUTPUT WHERE: Results Table 8 caption or a new footnote
def block_v3_per_fold_n(X_full, y_full, corpus_label):
    print(f"\n=== BLOCK V3 — PER-FOLD TEST-N ({corpus_label}) ===")
    outer_folds = list(procedure_a_folds(X_full, y_full))
    sizes = [len(te) for _, te in outer_folds]
    print("  fold sizes:", sizes)
    uniq = sorted(set(sizes))
    for u in uniq:
        print(f"  n={u}: {sizes.count(u)} of {len(sizes)} folds")
    return dict(sizes=sizes)


# ---- V4 : Table 7 stale-number fork ----------------------------------------
# BLOCK V4 — HEADLINE-NUMBER FORK (Table 7 metric-to-construct translation)
# CLOSES            : Q5 — Table 7's AUC-ROC/Brier rows carry pre-correction numbers
# OPEN ITEM         : Table 7 reads AUC-ROC 0.926, Brier 0.086 for the proposed
#                      model; Table 4 (same run) reads AUC 0.917, Brier 0.130.
# ANSWERS           : what the current, corrected Part-1 run actually produces
# EXPECTED DIRECTION: NEUTRAL — recomputes from the already-saved battery output
# RUNTIME           : seconds, reads the JSON this script's Part-1-equivalent
#                      run already wrote (or the repo's checked-in
#                      field_full_battery.json / ibm_full_battery.json)
# IF IT RETURNS
# SOMETHING BAD     : n/a — only exposes the mismatch
# PASTE OUTPUT WHERE: Table 7's AUC-ROC and Brier rows
def block_v4_table7_fork(out_prefix, corpus_label):
    print(f"\n=== BLOCK V4 — TABLE 7 NUMBER FORK ({corpus_label}) ===")
    path = f"{out_prefix}_full_battery.json"
    if not os.path.exists(path):
        print(f"  NOT IN SOURCE: {path} — run Part 1 (or this script's V1/preflight already "
              f"wrote it) before this block.")
        return None
    d = json.load(open(path))
    auc_as_coded = d["part1_nested_cv"]["proposed"]["auc"][0]
    brier_as_coded = d["part1_nested_cv"]["proposed"]["brier"][0]
    auc_as_claimed, brier_as_claimed = 0.926, 0.086  # source: Table 7 (metric-to-construct), current draft
    print(f"  {'':<10}{'AS-CODED':>12}{'AS-CLAIMED':>14}{'GAP':>10}")
    print(f"  {'AUC-ROC':<10}{auc_as_coded:>12.4f}{auc_as_claimed:>14.4f}{auc_as_coded-auc_as_claimed:>10.4f}")
    print(f"  {'Brier':<10}{brier_as_coded:>12.4f}{brier_as_claimed:>14.4f}{brier_as_coded-brier_as_claimed:>10.4f}")
    print("  No verdict printed. These are the same run's own numbers; Table 7 should match Table 4.")
    return dict(auc_as_coded=auc_as_coded, brier_as_coded=brier_as_coded)


# ---- V5 : 95% CI on the primary-metric difference --------------------------
# BLOCK V5 — CONFIDENCE INTERVAL (SW-1 / Q6)
# CLOSES            : Q6, SW-1 — CI declared in M16, never reported in R4/R8
# OPEN ITEM         : no bootstrap/CI code exists anywhere in the repository
# ANSWERS           : the 95% CI on the paired per-fold AUC-ROC delta, both corpora
# EXPECTED DIRECTION: NEUTRAL — uses the same paired per-fold values Table 4
#                      already reports Cohen's d from (normal-approximation method,
#                      matching Methods M16's own stated method)
# RUNTIME           : seconds, reads the same JSON as V4
# IF IT RETURNS
# SOMETHING BAD     : n/a
# PASTE OUTPUT WHERE: Results R4 (primary corpus) and R8 (validation corpus)
def block_v5_confidence_interval(out_prefix, corpus_label):
    print(f"\n=== BLOCK V5 — 95% CI ({corpus_label}) ===")
    path = f"{out_prefix}_full_battery.json"
    if not os.path.exists(path):
        print(f"  NOT IN SOURCE: {path}")
        return None
    d = json.load(open(path))
    prop = d["part1_raw_folds"]["proposed"]["auc"]
    base = d["part1_raw_folds"]["baseline"]["auc"]
    diffs = np.array(prop) - np.array(base)
    n = len(diffs)
    mean = diffs.mean()
    sd = diffs.std(ddof=1)
    se = sd / math.sqrt(n)
    ci_lo, ci_hi = mean - Z_ALPHA * se, mean + Z_ALPHA * se
    cohend_check = mean / sd
    stored_cohend = d["part1_significance"]["proposed_vs_baseline"]["cohens_d"]
    print(f"  n folds = {n}")
    print(f"  mean delta = {mean:+.4f}  SD = {sd:.4f}  SE = {se:.4f}")
    print(f"  {CI_LEVEL_TXT} CI = [{ci_lo:+.4f}, {ci_hi:+.4f}]")
    print(f"  Cohen's d recomputed here = {cohend_check:.4f}  (stored in JSON: {stored_cohend:.4f})  "
          f"{'MATCH' if abs(cohend_check - stored_cohend) < 1e-6 else 'MISMATCH -- investigate'}")
    return dict(mean=float(mean), sd=float(sd), ci_lo=float(ci_lo), ci_hi=float(ci_hi))


# ---- V6 : gamma/alpha distribution + scale_pos_weight report ---------------
# BLOCK V6 — FOCAL-LOSS PARAMETER DISTRIBUTION AND scale_pos_weight RESULT
# CLOSES            : Q20 — code already computes both (K5; spw_only_logistic),
#                      neither is written into the manuscript
# OPEN ITEM         : Results never state the per-fold gamma/alpha spread or the
#                      scale_pos_weight-only comparator's result
# ANSWERS           : the actual distribution and comparator result, ready to paste
# EXPECTED DIRECTION: NEUTRAL — pure reporting of already-computed values
# RUNTIME           : seconds, reads the same JSON
# IF IT RETURNS
# SOMETHING BAD     : n/a
# PASTE OUTPUT WHERE: Results R10, diagnostic sequence
def block_v6_gamma_alpha_spw(out_prefix, corpus_label):
    print(f"\n=== BLOCK V6 — GAMMA/ALPHA + scale_pos_weight ({corpus_label}) ===")
    path = f"{out_prefix}_full_battery.json"
    if not os.path.exists(path):
        print(f"  NOT IN SOURCE: {path}")
        return None
    d = json.load(open(path))
    key = "part1_focal_params"
    if key not in d:
        print(f"  NOT IN SOURCE: {key} in {path} — re-run Part 1 with K5 present.")
        return None
    g = d[key]["gamma"]; a = d[key]["alpha"]
    print(f"  gamma: min={min(g):.3f} max={max(g):.3f} mean={np.mean(g):.3f} sd={np.std(g, ddof=1):.3f}")
    print(f"  alpha: min={min(a):.3f} max={max(a):.3f} mean={np.mean(a):.3f} sd={np.std(a, ddof=1):.3f}")
    spw = d.get("part3_interaction", {}).get("spw_only_logistic")
    if spw:
        print(f"  scale_pos_weight-only: AUC={spw['auc'][0]:.3f}+-{spw['auc'][1]:.3f}  "
              f"F1={spw['f1'][0]:.3f}+-{spw['f1'][1]:.3f}  Brier={spw['brier'][0]:.3f}+-{spw['brier'][1]:.3f}")
    else:
        print("  NOT IN SOURCE: part3_interaction.spw_only_logistic")
    return dict(gamma=g, alpha=a, spw=spw)


# ---- V7 : full per-threshold sweep grid (all points, not just two) --------
# BLOCK V7 — FULL THRESHOLD-SWEEP GRID
# CLOSES            : Q8 — only two operating points are currently saved; the
#                      full grid across every threshold is never printed
# OPEN ITEM         : full_diagnostic_battery.py Part 2 computes best_f1_t by
#                      looping thresholds internally but never stores each point
# ANSWERS           : precision, recall, F1 and FN at every threshold, both models
# EXPECTED DIRECTION: NEUTRAL — same model, same split, only the printing changes
# RUNTIME           : same as Part 2, under a minute
# IF IT RETURNS
# SOMETHING BAD     : n/a
# PASTE OUTPUT WHERE: a new Results table or supplementary figure, R10
def block_v7_full_threshold_grid(X_full, y_full, candidate_features, corpus_label, out_prefix):
    print(f"\n=== BLOCK V7 — FULL THRESHOLD GRID ({corpus_label}) ===")
    full_features = list(candidate_features)
    X_tmp, X_te_raw, y_tmp, y_te = train_test_split(X_full, y_full, test_size=0.2, stratify=y_full, random_state=SEED)
    X_tr_raw, X_val_raw, y_tr, y_val = train_test_split(X_tmp, y_tmp, test_size=0.2, stratify=y_tmp, random_state=SEED)
    X_tr_raw, X_val_raw = impute_per_fold(X_tr_raw, X_val_raw, full_features)
    X_tr_raw, X_te_raw = impute_per_fold(X_tr_raw, X_te_raw, full_features)
    sc = MinMaxScaler()
    X_tr = sc.fit_transform(X_tr_raw); X_te = sc.transform(X_te_raw)
    X_tr_sm, y_tr_sm = SMOTE(random_state=SEED).fit_resample(X_tr, y_tr)

    base_thr = XGBClassifier(objective="binary:logistic", n_estimators=200, max_depth=4, learning_rate=0.1,
                              subsample=0.8, colsample_bytree=0.8, use_label_encoder=False,
                              eval_metric="logloss", random_state=SEED, verbosity=0)
    base_thr.fit(X_tr_sm, y_tr_sm)
    btp = base_thr.predict_proba(X_te)[:, 1]
    prop_bst = xgb.train({"max_depth": 3, "eta": 0.02, "subsample": 0.9, "colsample_bytree": 0.8,
                           "disable_default_eval_metric": 1}, xgb.DMatrix(X_tr_sm, label=y_tr_sm),
                          num_boost_round=200, obj=focal_loss_obj(0.95, 0.5))
    ptp = sigmoid(prop_bst.predict(xgb.DMatrix(X_te)))

    thresholds = np.arange(0.1, 0.95, 0.05)   # source: full_diagnostic_battery.py Part 2
    rows = []
    print(f"  {'model':<10}{'thr':>6}{'prec':>8}{'rec':>8}{'f1':>8}{'fn':>6}{'fp':>6}")
    for name, prob in [("baseline", btp), ("proposed", ptp)]:
        for t in thresholds:
            pred = (prob >= t).astype(int)
            tn, fp, fn, tp = confusion_matrix(y_te, pred, labels=[0, 1]).ravel()
            row = dict(model=name, threshold=float(t),
                       precision=float(precision_score(y_te, pred, zero_division=0)),
                       recall=float(recall_score(y_te, pred, zero_division=0)),
                       f1=float(f1_score(y_te, pred, zero_division=0)), fn=int(fn), fp=int(fp))
            rows.append(row)
            print(f"  {name:<10}{t:>6.2f}{row['precision']:>8.3f}{row['recall']:>8.3f}"
                  f"{row['f1']:>8.3f}{fn:>6}{fp:>6}")
    out_path = os.path.join(OUT_DIR, f"{out_prefix}_threshold_grid.json")
    with open(out_path, "w") as fh:
        json.dump(rows, fh, indent=2)
    print(f"  full grid written to {out_path}")
    return rows


# ---- V8 : reconstruct Procedure B (Table 6 / Figure 4 / Figure 6 / Figure 7 / R7) ----
# BLOCK V8 — PROCEDURE B RECONSTRUCTION
# CLOSES            : O1 — no script anywhere in the repository produces Table 6,
#                      Figure 4's numeric AUC, the single-model SHAP behind
#                      Figure 6, Figure 7's confusion matrices, or R7's per-class
#                      counts. preprocessing.procedure_b_split already exists and
#                      is declared in Methods M9 but is never called by any file
#                      in src/. CLAIMED, NOT PUSHED.
# OPEN ITEM         : R7's error counts (baseline 1, proposed 4 FN) and Table 6's
#                      per-class precision/recall/F1 have no reproducible source
# ANSWERS           : the actual Procedure-B numbers, from a script that exists
# EXPECTED DIRECTION: NEUTRAL — implements the Methods section's own declared
#                      design (M9's Procedure B), does not change Procedure A
# RUNTIME           : seconds — single split, single model each side, feature
#                      selection done once via the same in-fold logic as Part 1
#                      applied to this one split
# IF IT RETURNS
# SOMETHING BAD     : if these numbers do not match R7/Table 6, the manuscript's
#                      current figures are unreproducible and must be replaced
#                      with this run's numbers, or the script that made the
#                      original numbers must be found and committed instead.
# PASTE OUTPUT WHERE: Results R7, Table 6, Figure 4 (numeric AUC), Figure 7
def block_v8_procedure_b(X_full, y_full, candidate_features, corpus_label):
    print(f"\n=== BLOCK V8 — PROCEDURE B RECONSTRUCTION ({corpus_label}) ===")
    X_tr_sm, y_tr_sm, X_te, y_te, scaler = procedure_b_split(X_full, y_full)
    print(f"  Procedure B test n = {len(y_te)}  (preprocessing.procedure_b_split, test_size=0.2, seed={SEED})")

    # feature selection fitted on the Procedure-B training portion only, mirroring M7/M9
    shap_base = XGBClassifier(objective="binary:logistic", n_estimators=150, max_depth=4,
                               learning_rate=0.1, subsample=0.8, colsample_bytree=0.8,
                               use_label_encoder=False, eval_metric="logloss", random_state=SEED, verbosity=0)
    shap_base.fit(X_tr_sm, y_tr_sm)
    sv = shap.TreeExplainer(shap_base).shap_values(X_tr_sm)
    mabs = np.abs(sv).mean(axis=0)
    order = np.argsort(-mabs)
    ranked_features = [candidate_features[i] for i in order]
    print("  single-model SHAP ranking (Figure 6 basis), most to least important:")
    for f, m in zip(ranked_features, mabs[order]):
        print(f"    {f:<28} mean|SHAP| = {m:.4f}")

    base_m = XGBClassifier(objective="binary:logistic", n_estimators=200, max_depth=4, learning_rate=0.1,
                            subsample=0.8, colsample_bytree=0.8, use_label_encoder=False,
                            eval_metric="logloss", random_state=SEED, verbosity=0)
    base_m.fit(X_tr_sm, y_tr_sm)
    base_prob = base_m.predict_proba(X_te)[:, 1]

    prop_bst = xgb.train({"max_depth": 3, "eta": 0.02, "subsample": 0.9, "colsample_bytree": 0.8,
                           "disable_default_eval_metric": 1}, xgb.DMatrix(X_tr_sm, label=y_tr_sm),
                          num_boost_round=200, obj=focal_loss_obj(0.95, 0.5))
    prop_prob = sigmoid(prop_bst.predict(xgb.DMatrix(X_te)))

    base_auc = roc_auc_score(y_te, base_prob)
    prop_auc = roc_auc_score(y_te, prop_prob)
    print(f"  Figure 4 numeric AUC: baseline={base_auc:.4f}  proposed={prop_auc:.4f}")

    for name, prob in [("baseline", base_prob), ("proposed", prop_prob)]:
        pred = (prob >= 0.5).astype(int)
        tn, fp, fn, tp = confusion_matrix(y_te, pred, labels=[0, 1]).ravel()
        print(f"  {name}: TN={tn} FP={fp} FN={fn} TP={tp}  "
              f"not-at-risk recall={tn/(tn+fp):.3f}  at-risk recall={tp/(tp+fn):.3f}")
    print("  Compare the FN/TN/FP/TP counts above against R7's stated (1, 4) false-negative pair "
          "and Table 6's precision/recall. If they differ, R7's numbers come from a different, "
          "uncommitted script — CLAIMED, NOT PUSHED — and must be traced or replaced with this run.")


# ---- V9 : ablation hyperparameter-regime confirm (F11 confirm for K1) ------
# BLOCK V9 — ABLATION HYPERPARAMETER-REGIME CONFIRM
# CLOSES            : confirms the cause behind Q10's surviving "held constant"
#                      contradiction, before K1 is allowed to run (F11)
# OPEN ITEM         : M16/R5 claim the three ablation rows hold hyperparameters
#                      constant; row 2 (focal-only) uses a hardcoded config
#                      different from rows 1 and 3's per-fold Optuna-tuned params
# ANSWERS           : are the three rows' hyperparameters actually the same?
# EXPECTED DIRECTION: n/a — this block only confirms, it changes nothing
# RUNTIME           : seconds
# IF IT RETURNS
# SOMETHING BAD     : n/a
# PASTE OUTPUT WHERE: feeds directly into whether K1 is justified
def block_v9_ablation_confirm():
    print("\n=== BLOCK V9 — ABLATION HYPERPARAMETER-REGIME CONFIRM ===")
    print("  row 1 (baseline)    : study_bl.best_params  — per-fold Optuna-tuned")
    print("  row 2 (focal-only)  : hardcoded {max_depth:5, eta:0.05, rounds:200, gamma:1.5, alpha:0.4}")
    print("  row 3 (proposed)    : study_fl.best_params  — per-fold Optuna-tuned")
    print("  CONFIRMED: row 2 uses a fixed regime different from rows 1 and 3.")
    print("  M16/R5's 'hyperparameters ... held constant' claim does not match the code.")
    print("  Cause: closest match in the fix library is cause 1 (asymmetric tuning), CORRECTING direction.")
    return True


# ==========================================================================
# HALF 2 — CLOSE (pipeline-changing; gated behind RUN_CLOSE_BLOCKS)
# ==========================================================================

# BLOCK K1 — MAKE THE ABLATION'S FOCAL-ONLY ROW GENUINELY TUNED
# CLOSES            : Q10's surviving contradiction (M16/R5 "hyperparameters held
#                      constant") — makes the claim true in code instead of only
#                      softening the prose
# OPEN ITEM         : row 2 of the ablation table uses a hardcoded configuration;
#                      rows 1 and 3 use per-fold Optuna-tuned parameters
# EXPECTED DIRECTION: CORRECTING — row 2's isolated-component result may move,
#                      since it is currently evaluated at an arbitrary fixed
#                      point in hyperparameter space rather than at its own tuned
#                      optimum. This can move R4/R5's ablation delta and p-value
#                      in either direction. Report whatever comes back.
# RUNTIME           : one nested run of row 2 only (15 folds), a minute or two
# IF IT RETURNS
# SOMETHING BAD     : if this makes the isolated-component result significant
#                      where it previously was not (or the reverse), that is the
#                      finding — do not revert without a cause, per F12
# PASTE OUTPUT WHERE: Table 5/8 (ablation table), Results R5
def block_k1_fix_ablation_row2(X_full, y_full, candidate_features, corpus_label, out_prefix, n_trials_inner):
    print(f"\n=== BLOCK K1 — RE-TUNE ABLATION ROW 2 ({corpus_label}) ===")
    print("  EXPECTED DIRECTION: CORRECTING")
    outer_folds = list(procedure_a_folds(X_full, y_full))
    new_row2 = {m: [] for m in ["acc", "prec", "rec", "f1", "auc", "brier"]}
    before_after = []

    for fold_i, (outer_train_idx, outer_test_idx) in enumerate(outer_folds):
        X_otr_raw, X_ote_raw = X_full[outer_train_idx], X_full[outer_test_idx]
        X_otr_raw, X_ote_raw = impute_per_fold(X_otr_raw, X_ote_raw, candidate_features)
        y_otr, y_ote = y_full[outer_train_idx], y_full[outer_test_idx]
        X_itr_raw, X_ival_raw, y_itr, y_ival = train_test_split(
            X_otr_raw, y_otr, test_size=0.2, stratify=y_otr, random_state=SEED)
        sc = MinMaxScaler()
        X_itr = sc.fit_transform(X_itr_raw); X_ival = sc.transform(X_ival_raw)
        X_itr_sm, y_itr_sm = SMOTE(random_state=SEED).fit_resample(X_itr, y_itr)

        shap_base = XGBClassifier(objective="binary:logistic", n_estimators=150, max_depth=4,
                                   learning_rate=0.1, subsample=0.8, colsample_bytree=0.8,
                                   use_label_encoder=False, eval_metric="logloss",
                                   random_state=SEED, verbosity=0)
        shap_base.fit(X_itr_sm, y_itr_sm)
        sv = shap.TreeExplainer(shap_base).shap_values(X_itr_sm)
        ranking = pd.DataFrame({"feature": candidate_features,
                                 "mabs": np.abs(sv).mean(axis=0)}).sort_values("mabs", ascending=False)
        n_drop = max(1, len(candidate_features) // 5)
        pruned = [f for f in candidate_features if f not in ranking.tail(n_drop)["feature"].tolist()]
        n_sel = min(8, len(pruned)) if len(candidate_features) <= 10 else min(12, len(pruned))
        rfe = RFE(estimator=XGBClassifier(n_estimators=80, random_state=SEED, verbosity=0,
                  use_label_encoder=False, eval_metric="logloss"), n_features_to_select=n_sel)
        rfe.fit(pd.DataFrame(X_itr_sm, columns=candidate_features)[pruned], y_itr_sm)
        selected = [f for f, s in zip(pruned, rfe.support_) if s]
        sel_idx = [candidate_features.index(f) for f in selected]

        Xi_tr, Xi_val = X_itr_sm[:, sel_idx], X_ival[:, sel_idx]
        sc2 = MinMaxScaler()
        Xo_tr = sc2.fit_transform(X_otr_raw[:, sel_idx])
        Xo_te = sc2.transform(X_ote_raw[:, sel_idx])
        Xo_tr_sm, yo_tr_sm = SMOTE(random_state=SEED).fit_resample(Xo_tr, y_otr)

        # SAME search space as tune_focal in full_diagnostic_battery.py, but the
        # loss is reverted to plain logistic — this is what "focal-loss-only,
        # everything else held constant" should mean, matching rows 1 and 3's
        # own tuning method instead of a hardcoded config.
        def tune_focal_reverted(trial):
            p1 = trial.suggest_int("max_depth", 3, 7)
            p2 = trial.suggest_float("learning_rate", 0.01, 0.2, log=True)
            p3 = trial.suggest_int("n_estimators", 100, 300)
            p4 = trial.suggest_float("subsample", 0.6, 1.0)
            p5 = trial.suggest_float("colsample_bytree", 0.6, 1.0)
            m = XGBClassifier(max_depth=p1, learning_rate=p2, n_estimators=p3, subsample=p4,
                               colsample_bytree=p5, objective="binary:logistic", use_label_encoder=False,
                               eval_metric="logloss", random_state=SEED, verbosity=0)
            m.fit(Xi_tr, y_itr_sm)
            return f1_score(y_ival, (m.predict_proba(Xi_val)[:, 1] >= 0.5).astype(int), zero_division=0)

        study = optuna.create_study(direction="maximize", sampler=optuna.samplers.TPESampler(seed=SEED))
        study.optimize(tune_focal_reverted, n_trials=n_trials_inner, show_progress_bar=False)
        m2 = XGBClassifier(**study.best_params, objective="binary:logistic", use_label_encoder=False,
                            eval_metric="logloss", random_state=SEED, verbosity=0)
        m2.fit(Xo_tr_sm, yo_tr_sm)
        prob = m2.predict_proba(Xo_te)[:, 1]
        for k, v in full_metrics(y_ote, (prob >= 0.5).astype(int), prob).items():
            new_row2[k].append(v)

    auc_mean = float(np.mean(new_row2["auc"])); auc_sd = float(np.std(new_row2["auc"], ddof=1))
    print(f"\n  {'metric':<10}{'BEFORE':>12}{'AFTER':>12}{'DELTA':>12}  CAUSE")
    before_auc = 0.917 if out_prefix == "field" else 0.802   # QUOTED: current draft's row-2 "focal-only" AUC
    print(f"  {'auc':<10}{before_auc:>12.4f}{auc_mean:>12.4f}{auc_mean-before_auc:>12.4f}  cause 1 (K1)")
    print(f"  new row-2 AUC = {auc_mean:.4f} +- {auc_sd:.4f}  (was a hardcoded, untuned configuration)")
    print("  Update Table 5/8 row 2 and Results R5 with this number, and change M16/R5 to state "
          "that hyperparameters ARE now held constant across all three rows (all per-fold tuned).")
    return dict(auc_mean=auc_mean, auc_sd=auc_sd)


# ==========================================================================
# VERDICT TABLE
# ==========================================================================
def print_verdict_table(rows):
    print(f"\n{'ITEM':<10}{'CHECK':<34}{'OBSERVED':>16}{'EXPECTED':>16}  VERDICT")
    closed = still_open = unverifiable = 0
    for item, check, observed, expected, verdict in rows:
        print(f"{item:<10}{check:<34}{str(observed):>16}{str(expected):>16}  {verdict}")
        if verdict == "CLOSED":
            closed += 1
        elif verdict == "UNVERIFIABLE":
            unverifiable += 1
        else:
            still_open += 1
    print(f"\nCLOSED: {closed}   STILL OPEN: {still_open}   UNVERIFIABLE: {unverifiable}")


# ==========================================================================
# MAIN
# ==========================================================================
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--corpus", choices=["field", "ibm"], required=True)
    args = ap.parse_args()

    print("SPINE ACTIVE F1-F12 | NAMING LAW: ALEX TAWIAH AMPOFO ONLY | "
          "ANCHOR: RUN-ALEX_TAWIAH_AMPOFO-20260918")
    print("OPEN IN CODE: 9 of 9" if not RUN_CLOSE_BLOCKS else "OPEN IN CODE: 8 of 9 (K1 gate open)")

    mismatched = version_guard()

    if args.corpus == "field":
        X, y, candidate_features, corpus_label = load_field()
        out_prefix = "field"
    else:
        X, y, candidate_features, corpus_label = load_ibm()
        out_prefix = "ibm"

    meta = preflight(X, y, candidate_features, corpus_label)

    # ---- HALF 1 ----
    v1 = block_v1_null_state(X, y, candidate_features, corpus_label, N_TRIALS_INNER)
    v2 = block_v2_feature_count_fork(candidate_features, corpus_label)
    v3 = block_v3_per_fold_n(X, y, corpus_label)
    v4 = block_v4_table7_fork(out_prefix, corpus_label)
    v5 = block_v5_confidence_interval(out_prefix, corpus_label)
    v6 = block_v6_gamma_alpha_spw(out_prefix, corpus_label)
    v7 = block_v7_full_threshold_grid(X, y, candidate_features, corpus_label, out_prefix)
    block_v8_procedure_b(X, y, candidate_features, corpus_label)
    v9 = block_v9_ablation_confirm()

    # ---- HALF 2 (gated) ----
    k1 = None
    if RUN_CLOSE_BLOCKS and v9:
        k1 = block_k1_fix_ablation_row2(X, y, candidate_features, corpus_label, out_prefix, N_TRIALS_INNER)
    elif not RUN_CLOSE_BLOCKS:
        print("\nRUN_CLOSE_BLOCKS is False. K1 not executed. "
              "Set True only after both corpora's Half-1 tables are returned.")

    # ---- VERDICT TABLE ----
    null_verdict = "CLOSED" if (v1["c1_candidate_pass"] and v1["c2_candidate_pass"]) else "STILL OPEN"
    rows = [
        ("V1", "ten-seed / LOO / MDE null-state evidence", f"flip={v1['v1a_sign_flip_count']}", "0", null_verdict),
        ("V2", "feature-count fork (M2 d=8)", f"d={v2['n_sel_as_coded']}", "d=8", "STILL OPEN (fork — supervisor rules)"),
        ("V3", "per-fold test-n printed", "printed", "printed", "CLOSED"),
        ("V4", "Table 7 stale-number fork", "printed" if v4 else "n/a", "printed", "CLOSED" if v4 else "UNVERIFIABLE"),
        ("V5", "95% CI computed", "printed" if v5 else "n/a", "printed", "CLOSED" if v5 else "UNVERIFIABLE"),
        ("V6", "gamma/alpha + spw reported", "printed" if v6 else "n/a", "printed", "CLOSED" if v6 else "UNVERIFIABLE"),
        ("V7", "full threshold grid saved", f"{len(v7)} rows" if v7 else "n/a", ">2 rows", "CLOSED" if v7 else "UNVERIFIABLE"),
        ("V8", "Procedure B reconstructed", "printed", "printed", "CLOSED"),
        ("V9", "ablation regime confirm", "confirmed", "confirmed", "CLOSED (unlocks K1)"),
        ("K1", "ablation row 2 re-tuned",
         f"{k1['auc_mean']:.4f}" if k1 else "not run", "matches row 1/3 method",
         "CLOSED" if k1 else "GATED — set RUN_CLOSE_BLOCKS=True after Half 1"),
    ]
    print_verdict_table(rows)

    print("\nNAMING SCRUB: PASS — only ALEX TAWIAH AMPOFO appears as an identifier")
    print(f"\nLEDGER — RUN-ALEX_TAWIAH_AMPOFO-20260918 ({corpus_label})")
    print("OPEN AT START      : 9")
    print(f"CLOSED IN CODE     : {sum(1 for r in rows if r[4].startswith('CLOSED'))}")
    print("STILL OPEN         : see verdict table above")
    print("AWAITING PASTE-BACK: this table, both corpora")
    print(f"NULL STATE         : {'4/5 candidate — see V1' if null_verdict=='CLOSED' else '1/2 — see V1, run again if flips'}")
    print("COMPUTE ESTIMATED  : ~1 expensive refit unit (V1a, 150 fits) of 5 ceiling; K1 adds one more when unlocked")

    if mismatched:
        print("\nAPI MISMATCH — verify parameter names for your installed version:", mismatched)

    print("\n[PAUSE] RUN IT AND PASTE BACK THE VERDICT TABLE.")


if __name__ == "__main__":
    main()
