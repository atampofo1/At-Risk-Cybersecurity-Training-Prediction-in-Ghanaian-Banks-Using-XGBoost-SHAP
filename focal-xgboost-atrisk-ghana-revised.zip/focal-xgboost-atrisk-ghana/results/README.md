# Results

Output JSON summaries from `src/field_pipeline.py`, `src/ibm_pipeline.py`,
and `src/full_diagnostic_battery.py` are written here at runtime.

This folder is tracked in version control (via `.gitkeep`) but its
generated contents are excluded — see `.gitignore`.
