# Data

## Primary corpus (FIELD) — restricted

The primary field dataset (Ghana Banking Cybersecurity Survey, n = 533)
is **not distributed** in this repository, per Methods M5 and M21.
Access may be requested from the corresponding author subject to a
data-use agreement and institutional approval.

**Known data-quality issue (Methods M6, corrected in this revision):**
the training-session-count item has 33.2% non-response, with no genuine
"zero sessions" response category existing in the raw data at all.
`src/field_pipeline.py` handles this correctly (see its module
docstring); do not re-derive a `training_sessions_enc` column that
silently fills non-response with zero.

## Validation corpus (IBM HR Analytics) — public

Openly licensed and freely redistributable. `src/ibm_pipeline.py`
downloads it automatically on first run and caches it at
`data/ibm_hr_attrition.csv`. Confirmed on audit to have zero missing
values (Results R10).

## This folder

Downloaded/cached data files are written here at runtime and are
excluded from version control via `.gitignore`.
