"""
full_diagnostic_battery.py

Runs the COMPLETE corrected simulation battery on a single corpus:
  1. Nested CV (GATE-1: inner tuning partition + feature selection in-fold)
  2. Matched-budget tuned baseline, Random Forest, Logistic Regression, SVM (GATE-2)
  3. Threshold sweep (val-selected, test scored once) (Q8/GATE-4/Q20)
  4. SMOTE x focal-loss 2x2 interaction decomposition (Q20)
  5. scale_pos_weight comparator (Q1/Q20)
  6. Seed-variance vs fold-variance decomposition (Q6)
  7. Two re-engineering attempts: interaction feature, class-weighted loss (Q21 Step 3/4)
  8. Corrected 3-row ablation table under the new methodology
  9. Full Wilcoxon significance package on every comparison

Usage: called as a function so it can be run identically on the field
corpus and the IBM corpus, producing directly comparable JSON output.
"""

import warnings; warnings.filterwarnings("ignore")
import numpy as np
import pandas as pd
import json
import time
from sklearn.model_selection import RepeatedStratifiedKFold, train_test_split
from sklearn.preprocessing import MinMaxScaler
from sklearn.feature_selection import RFE
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score,
                              roc_auc_score, brier_score_loss, confusion_matrix)
from imblearn.over_sampling import SMOTE
from xgboost import XGBClassifier
import xgboost as xgb
import shap
import optuna
from scipy.stats import wilcoxon, shapiro
optuna.logging.set_verbosity(optuna.logging.WARNING)

SEED = 42
np.random.seed(SEED)


def impute_per_fold(X_train_raw, X_test_raw, feature_names):
    """
    Per-fold median imputation for any feature containing NaN (e.g. informative
    missingness in training_sessions_raw), fitted on the training portion only
    and applied unchanged to the test portion. Closes the Q11 gap: the median
    is never computed on the full corpus or on data the fold will later score.
    """
    X_train = X_train_raw.copy()
    X_test = X_test_raw.copy()
    for j, fname in enumerate(feature_names):
        col_train = X_train[:, j]
        if np.isnan(col_train).any():
            med = np.nanmedian(col_train)
            X_train[np.isnan(X_train[:, j]), j] = med
            X_test[np.isnan(X_test[:, j]), j] = med
    return X_train, X_test


def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))


def focal_obj(gamma, alpha):
    def obj(y_pred, dtrain):
        y_true = dtrain.get_label()
        p = np.clip(sigmoid(y_pred), 1e-7, 1 - 1e-7)
        w = np.where(y_true == 1, alpha * (1 - p) ** gamma, (1 - alpha) * p ** gamma)
        return w * (p - y_true), w * p * (1 - p)
    return obj


def full_metrics(y_true, y_pred, y_prob):
    return dict(
        acc=accuracy_score(y_true, y_pred),
        prec=precision_score(y_true, y_pred, zero_division=0),
        rec=recall_score(y_true, y_pred, zero_division=0),
        f1=f1_score(y_true, y_pred, zero_division=0),
        auc=roc_auc_score(y_true, y_prob),
        brier=brier_score_loss(y_true, y_prob),
    )


def run_battery(X_full, y_full, candidate_features, corpus_name, n_trials_inner=10, out_prefix="field"):
    t_start = time.time()
    log = []

    def p(msg):
        print(msg)
        log.append(msg)

    p(f"\n{'='*70}\nDIAGNOSTIC BATTERY: {corpus_name}\n{'='*70}")
    p(f"n={len(y_full)}, positive rate={y_full.mean()*100:.1f}%, features={len(candidate_features)}")

    outer_folds = list(RepeatedStratifiedKFold(n_splits=5, n_repeats=3, random_state=SEED).split(X_full, y_full))

    # ========================================================================
    # PART 1 — NESTED CV: GATE-1 (inner tuning partition, feature selection
    # in-fold) + GATE-2 (matched-budget baseline, RF, LR, SVM)
    # ========================================================================
    p("\n--- PART 1: Nested CV (GATE-1 + GATE-2) ---")
    results = {k: {m: [] for m in ["acc", "prec", "rec", "f1", "auc", "brier"]}
               for k in ["baseline", "proposed", "rf_tuned", "lr", "svm"]}
    feature_retention = {f: 0 for f in candidate_features}
    ablation_focal_only = {m: [] for m in ["acc", "prec", "rec", "f1", "auc", "brier"]}

    n_est_range = (100, 300)

    for fold_i, (outer_train_idx, outer_test_idx) in enumerate(outer_folds):
        X_outer_train_raw, X_outer_test_raw = X_full[outer_train_idx], X_full[outer_test_idx]
        X_outer_train_raw, X_outer_test_raw = impute_per_fold(X_outer_train_raw, X_outer_test_raw, candidate_features)
        y_outer_train, y_outer_test = y_full[outer_train_idx], y_full[outer_test_idx]

        X_inner_train_raw, X_inner_val_raw, y_inner_train, y_inner_val = train_test_split(
            X_outer_train_raw, y_outer_train, test_size=0.2, stratify=y_outer_train, random_state=SEED
        )
        scaler = MinMaxScaler()
        X_inner_train = scaler.fit_transform(X_inner_train_raw)
        X_inner_val = scaler.transform(X_inner_val_raw)
        X_inner_train_sm, y_inner_train_sm = SMOTE(random_state=SEED).fit_resample(X_inner_train, y_inner_train)

        # Feature selection in-fold
        base_for_shap = XGBClassifier(objective="binary:logistic", n_estimators=150, max_depth=4,
            learning_rate=0.1, subsample=0.8, colsample_bytree=0.8, use_label_encoder=False,
            eval_metric="logloss", random_state=SEED, verbosity=0)
        base_for_shap.fit(X_inner_train_sm, y_inner_train_sm)
        explainer = shap.TreeExplainer(base_for_shap)
        shap_vals = explainer.shap_values(X_inner_train_sm)
        ranking = pd.DataFrame({"feature": candidate_features,
                                 "mean_abs_shap": np.abs(shap_vals).mean(axis=0)}).sort_values("mean_abs_shap", ascending=False)
        n_drop = max(1, len(candidate_features) // 5)
        pruned = [f for f in candidate_features if f not in ranking.tail(n_drop)["feature"].tolist()]
        n_select = min(8, len(pruned)) if len(candidate_features) <= 10 else min(12, len(pruned))
        rfe = RFE(estimator=XGBClassifier(n_estimators=80, random_state=SEED, verbosity=0,
                  use_label_encoder=False, eval_metric="logloss"), n_features_to_select=n_select)
        rfe.fit(pd.DataFrame(X_inner_train_sm, columns=candidate_features)[pruned], y_inner_train_sm)
        selected = [f for f, s in zip(pruned, rfe.support_) if s]
        for f in selected:
            feature_retention[f] += 1

        sel_idx = [candidate_features.index(f) for f in selected]
        Xi_tr = X_inner_train_sm[:, sel_idx]
        Xi_val = X_inner_val[:, sel_idx]

        Xo_train_raw_sel = X_outer_train_raw[:, sel_idx]
        scaler2 = MinMaxScaler()
        Xo_train = scaler2.fit_transform(Xo_train_raw_sel)
        Xo_test_final = scaler2.transform(X_outer_test_raw[:, sel_idx])
        Xo_train_sm, yo_train_sm = SMOTE(random_state=SEED).fit_resample(Xo_train, y_outer_train)

        # --- Baseline (tuned) ---
        def tune_xgb_default(trial):
            params = dict(max_depth=trial.suggest_int("max_depth", 3, 7),
                          learning_rate=trial.suggest_float("learning_rate", 0.01, 0.2, log=True),
                          n_estimators=trial.suggest_int("n_estimators", *n_est_range),
                          subsample=trial.suggest_float("subsample", 0.6, 1.0),
                          colsample_bytree=trial.suggest_float("colsample_bytree", 0.6, 1.0))
            m = XGBClassifier(**params, objective="binary:logistic", use_label_encoder=False,
                              eval_metric="logloss", random_state=SEED, verbosity=0)
            m.fit(Xi_tr, y_inner_train_sm)
            pr = m.predict_proba(Xi_val)[:, 1]
            return f1_score(y_inner_val, (pr >= 0.5).astype(int), zero_division=0)
        study_bl = optuna.create_study(direction="maximize", sampler=optuna.samplers.TPESampler(seed=SEED))
        study_bl.optimize(tune_xgb_default, n_trials=n_trials_inner, show_progress_bar=False)
        bl_final = XGBClassifier(**study_bl.best_params, objective="binary:logistic", use_label_encoder=False,
                                 eval_metric="logloss", random_state=SEED, verbosity=0)
        bl_final.fit(Xo_train_sm, yo_train_sm)
        pr = bl_final.predict_proba(Xo_test_final)[:, 1]; pred = (pr >= 0.5).astype(int)
        for k, v in full_metrics(y_outer_test, pred, pr).items(): results["baseline"][k].append(v)

        # --- Proposed (focal loss, tuned) ---
        def tune_focal(trial):
            params = dict(max_depth=trial.suggest_int("max_depth", 3, 7),
                          eta=trial.suggest_float("eta", 0.01, 0.2, log=True),
                          subsample=trial.suggest_float("subsample", 0.6, 1.0),
                          colsample_bytree=trial.suggest_float("colsample_bytree", 0.6, 1.0),
                          reg_alpha=trial.suggest_float("reg_alpha", 0.0, 2.0),
                          reg_lambda=trial.suggest_float("reg_lambda", 0.5, 3.0),
                          min_child_weight=trial.suggest_int("min_child_weight", 1, 10),
                          disable_default_eval_metric=1)
            n_est = trial.suggest_int("n_estimators", *n_est_range)
            gamma = trial.suggest_float("gamma", 0.3, 4.0); alpha = trial.suggest_float("alpha_fl", 0.1, 0.7)
            dtr = xgb.DMatrix(Xi_tr, label=y_inner_train_sm); dv = xgb.DMatrix(Xi_val)
            booster = xgb.train(params, dtr, num_boost_round=n_est, obj=focal_obj(gamma, alpha))
            pr = sigmoid(booster.predict(dv))
            return f1_score(y_inner_val, (pr >= 0.5).astype(int), zero_division=0)
        study_fl = optuna.create_study(direction="maximize", sampler=optuna.samplers.TPESampler(seed=SEED))
        study_fl.optimize(tune_focal, n_trials=n_trials_inner + 3, show_progress_bar=False)
        bp = study_fl.best_params.copy(); gamma = bp.pop("gamma"); alpha = bp.pop("alpha_fl"); n_est = bp.pop("n_estimators")
        dtr_f = xgb.DMatrix(Xo_train_sm, label=yo_train_sm)
        final_booster = xgb.train({**bp, "disable_default_eval_metric": 1}, dtr_f, num_boost_round=n_est, obj=focal_obj(gamma, alpha))
        pr = sigmoid(final_booster.predict(xgb.DMatrix(Xo_test_final))); pred = (pr >= 0.5).astype(int)
        for k, v in full_metrics(y_outer_test, pred, pr).items(): results["proposed"][k].append(v)

        # Ablation intermediate: focal-loss-only, no independent tuning, same features
        focal_only_booster = xgb.train({"max_depth": 5, "eta": 0.05, "disable_default_eval_metric": 1},
                                       dtr_f, num_boost_round=200, obj=focal_obj(1.5, 0.4))
        pr = sigmoid(focal_only_booster.predict(xgb.DMatrix(Xo_test_final))); pred = (pr >= 0.5).astype(int)
        for k, v in full_metrics(y_outer_test, pred, pr).items(): ablation_focal_only[k].append(v)

        # --- Random Forest (tuned) ---
        def tune_rf(trial):
            params = dict(n_estimators=trial.suggest_int("n_estimators", 100, 400),
                          max_depth=trial.suggest_int("max_depth", 3, 20),
                          min_samples_split=trial.suggest_int("min_samples_split", 2, 20),
                          min_samples_leaf=trial.suggest_int("min_samples_leaf", 1, 10),
                          max_features=trial.suggest_categorical("max_features", ["sqrt", "log2", None]))
            m = RandomForestClassifier(**params, random_state=SEED)
            m.fit(Xi_tr, y_inner_train_sm)
            pr = m.predict_proba(Xi_val)[:, 1]
            return f1_score(y_inner_val, (pr >= 0.5).astype(int), zero_division=0)
        study_rf = optuna.create_study(direction="maximize", sampler=optuna.samplers.TPESampler(seed=SEED))
        study_rf.optimize(tune_rf, n_trials=n_trials_inner, show_progress_bar=False)
        rf_final = RandomForestClassifier(**study_rf.best_params, random_state=SEED)
        rf_final.fit(Xo_train_sm, yo_train_sm)
        pr = rf_final.predict_proba(Xo_test_final)[:, 1]; pred = (pr >= 0.5).astype(int)
        for k, v in full_metrics(y_outer_test, pred, pr).items(): results["rf_tuned"][k].append(v)

        # --- Logistic Regression, SVM (defaults are their natural form; small param sweep for parity) ---
        lr = LogisticRegression(max_iter=1000, random_state=SEED, C=1.0)
        lr.fit(Xo_train_sm, yo_train_sm)
        pr = lr.predict_proba(Xo_test_final)[:, 1]; pred = (pr >= 0.5).astype(int)
        for k, v in full_metrics(y_outer_test, pred, pr).items(): results["lr"][k].append(v)

        svm = SVC(probability=True, random_state=SEED)
        svm.fit(Xo_train_sm, yo_train_sm)
        pr = svm.predict_proba(Xo_test_final)[:, 1]; pred = (pr >= 0.5).astype(int)
        for k, v in full_metrics(y_outer_test, pred, pr).items(): results["svm"][k].append(v)

        if (fold_i + 1) % 5 == 0:
            p(f"  fold {fold_i+1}/15 done ({time.time()-t_start:.0f}s elapsed)")

    summary_p1 = {model: {m: (float(np.mean(v)), float(np.std(v, ddof=1))) for m, v in metrics.items()}
                  for model, metrics in results.items()}
    ablation_summary = {m: (float(np.mean(v)), float(np.std(v, ddof=1))) for m, v in ablation_focal_only.items()}

    for model, metrics in summary_p1.items():
        p(f"  {model}: AUC={metrics['auc'][0]:.4f}±{metrics['auc'][1]:.4f}  F1={metrics['f1'][0]:.4f}±{metrics['f1'][1]:.4f}  Brier={metrics['brier'][0]:.4f}±{metrics['brier'][1]:.4f}")
    p(f"  ablation (focal-only, no tuning): AUC={ablation_summary['auc'][0]:.4f}±{ablation_summary['auc'][1]:.4f}  F1={ablation_summary['f1'][0]:.4f}±{ablation_summary['f1'][1]:.4f}")

    def checkpoint(extra):
        ckpt = dict(corpus=corpus_name, n=len(y_full), positive_rate=float(y_full.mean()), log=log, **extra)
        with open(f"{out_prefix}_full_battery.json", "w") as f:
            json.dump(ckpt, f, indent=2)

    checkpoint(dict(part1_nested_cv=summary_p1, part1_ablation_focal_only=ablation_summary,
                     part1_feature_retention=feature_retention, part1_significance={},
                     part1_raw_folds={k: v for k, v in results.items()}))

    p(f"\n  Feature retention (out of 15 folds):")
    for f, c in sorted(feature_retention.items(), key=lambda x: -x[1]):
        p(f"    {f}: {c}/15")

    # Significance package for Part 1
    sig_p1 = {}
    for comp_name, comp_key in [("proposed_vs_baseline", "baseline"), ("proposed_vs_rf", "rf_tuned"),
                                  ("proposed_vs_lr", "lr"), ("proposed_vs_svm", "svm")]:
        auc_p = np.array(results["proposed"]["auc"]); auc_c = np.array(results[comp_key]["auc"])
        f1_p = np.array(results["proposed"]["f1"]); f1_c = np.array(results[comp_key]["f1"])
        diff_auc = auc_p - auc_c
        try:
            _, sh_p = shapiro(diff_auc)
        except Exception:
            sh_p = float("nan")
        _, w_auc = wilcoxon(auc_p, auc_c, alternative="greater") if not np.allclose(diff_auc, 0) else (None, 1.0)
        _, w_f1 = wilcoxon(f1_p, f1_c, alternative="greater") if not np.allclose(f1_p - f1_c, 0) else (None, 1.0)
        cohens_d = diff_auc.mean() / diff_auc.std(ddof=1) if diff_auc.std(ddof=1) > 0 else float("nan")
        sig_p1[comp_name] = dict(auc_delta=float(diff_auc.mean()), auc_p=float(w_auc), f1_p=float(w_f1),
                                  cohens_d=float(cohens_d), shapiro_p=float(sh_p))
        p(f"  SIG {comp_name}: ΔAUC={diff_auc.mean():+.4f}, p={w_auc:.4f}, d={cohens_d:.3f}, F1 p={w_f1:.4f}")

    diff_ablation = np.array(results["proposed"]["auc"]) - np.array(ablation_focal_only["auc"])
    _, w_ab = wilcoxon(results["proposed"]["auc"], ablation_focal_only["auc"], alternative="greater")
    p(f"  SIG proposed_vs_ablation_focal_only: ΔAUC={diff_ablation.mean():+.4f}, p={w_ab:.4f}")
    sig_p1["proposed_vs_ablation_focal_only"] = dict(auc_delta=float(diff_ablation.mean()), auc_p=float(w_ab))

    checkpoint(dict(part1_nested_cv=summary_p1, part1_ablation_focal_only=ablation_summary,
                     part1_feature_retention=feature_retention, part1_significance=sig_p1))

    # ========================================================================
    # PART 2 — Threshold sweep (val-selected, test scored once)
    # ========================================================================
    p("\n--- PART 2: Threshold sweep ---")
    # Use the most frequently retained features (matching Part 1's typical selection)
    top_feats = sorted(feature_retention.items(), key=lambda x: -x[1])[:min(8, len(candidate_features))]
    stable_features = [f for f, c in top_feats if c >= len(outer_folds) * 0.5]
    if len(stable_features) < 3:
        stable_features = [f for f, c in top_feats]
    sel_idx_stable = [candidate_features.index(f) for f in stable_features]

    X_temp, X_test_raw, y_temp, y_test = train_test_split(X_full[:, sel_idx_stable], y_full, test_size=0.2, stratify=y_full, random_state=SEED)
    X_train_raw, X_val_raw, y_train, y_val = train_test_split(X_temp, y_temp, test_size=0.2, stratify=y_temp, random_state=SEED)
    X_train_raw, X_val_raw = impute_per_fold(X_train_raw, X_val_raw, stable_features)
    X_train_raw, X_test_raw = impute_per_fold(X_train_raw, X_test_raw, stable_features)
    scaler = MinMaxScaler()
    X_train = scaler.fit_transform(X_train_raw); X_val = scaler.transform(X_val_raw); X_test = scaler.transform(X_test_raw)
    X_train_sm, y_train_sm = SMOTE(random_state=SEED).fit_resample(X_train, y_train)

    base_thr = XGBClassifier(objective="binary:logistic", n_estimators=200, max_depth=4, learning_rate=0.1,
                             subsample=0.8, colsample_bytree=0.8, use_label_encoder=False, eval_metric="logloss",
                             random_state=SEED, verbosity=0)
    base_thr.fit(X_train_sm, y_train_sm)
    base_val_prob = base_thr.predict_proba(X_val)[:, 1]; base_test_prob = base_thr.predict_proba(X_test)[:, 1]

    dtr = xgb.DMatrix(X_train_sm, label=y_train_sm)
    prop_booster = xgb.train({"max_depth": 3, "eta": 0.02, "subsample": 0.9, "colsample_bytree": 0.8,
                              "disable_default_eval_metric": 1}, dtr, num_boost_round=200, obj=focal_obj(0.95, 0.5))
    prop_val_prob = sigmoid(prop_booster.predict(xgb.DMatrix(X_val))); prop_test_prob = sigmoid(prop_booster.predict(xgb.DMatrix(X_test)))

    thresholds = np.arange(0.1, 0.95, 0.05)
    def best_f1_threshold(y_true, prob):
        best_t, best_f1 = 0.5, -1
        for t in thresholds:
            f = f1_score(y_true, (prob >= t).astype(int), zero_division=0)
            if f > best_f1: best_f1, best_t = f, t
        return best_t, best_f1

    base_t, base_val_f1 = best_f1_threshold(y_val, base_val_prob)
    prop_t, prop_val_f1 = best_f1_threshold(y_val, prop_val_prob)

    threshold_results = {}
    for name, prob, default_t, sel_t in [("baseline", base_test_prob, 0.5, base_t), ("proposed", prop_test_prob, 0.5, prop_t)]:
        row = {}
        for t, label in [(default_t, "default"), (sel_t, "selected")]:
            pred = (prob >= t).astype(int)
            cm = confusion_matrix(y_test, pred, labels=[0, 1]); tn, fp, fn, tp = cm.ravel()
            row[label] = dict(threshold=float(t), f1=float(f1_score(y_test, pred, zero_division=0)),
                              recall=float(recall_score(y_test, pred, zero_division=0)),
                              precision=float(precision_score(y_test, pred, zero_division=0)),
                              fn=int(fn), fp=int(fp))
        row["brier"] = float(brier_score_loss(y_test, prob))
        threshold_results[name] = row
        p(f"  {name}: default(0.5) F1={row['default']['f1']:.4f} FN={row['default']['fn']} | selected({sel_t:.2f}) F1={row['selected']['f1']:.4f} FN={row['selected']['fn']} | Brier={row['brier']:.4f}")

    checkpoint(dict(part1_nested_cv=summary_p1, part1_ablation_focal_only=ablation_summary,
                     part1_feature_retention=feature_retention, part1_significance=sig_p1,
                     part2_threshold_sweep=threshold_results, stable_features_used=stable_features))

    # ========================================================================
    # PART 3 — SMOTE x focal 2x2 + scale_pos_weight
    # ========================================================================
    p("\n--- PART 3: SMOTE x focal-loss interaction + scale_pos_weight ---")
    pos_ratio = (y_full == 0).sum() / (y_full == 1).sum()
    X_stable = X_full[:, sel_idx_stable]
    configs = {"no_smote_logistic": dict(smote=False, focal=False, spw=False),
               "no_smote_focal": dict(smote=False, focal=True, spw=False),
               "smote_logistic": dict(smote=True, focal=False, spw=False),
               "smote_focal": dict(smote=True, focal=True, spw=False),
               "spw_only_logistic": dict(smote=False, focal=False, spw=True)}
    interaction_results = {k: {"auc": [], "f1": [], "brier": []} for k in configs}

    for tr_idx, te_idx in outer_folds:
        X_tr_raw, X_te_raw = X_stable[tr_idx], X_stable[te_idx]
        X_tr_raw, X_te_raw = impute_per_fold(X_tr_raw, X_te_raw, stable_features)
        y_tr, y_te = y_full[tr_idx], y_full[te_idx]
        scaler = MinMaxScaler(); X_tr = scaler.fit_transform(X_tr_raw); X_te = scaler.transform(X_te_raw)
        for name, cfg in configs.items():
            X_use, y_use = (SMOTE(random_state=SEED).fit_resample(X_tr, y_tr) if cfg["smote"] else (X_tr, y_tr))
            if cfg["focal"]:
                dtr2 = xgb.DMatrix(X_use, label=y_use)
                booster = xgb.train({"max_depth": 3, "eta": 0.03, "subsample": 0.85, "colsample_bytree": 0.8,
                                     "disable_default_eval_metric": 1}, dtr2, num_boost_round=200, obj=focal_obj(0.95, 0.5))
                prob = sigmoid(booster.predict(xgb.DMatrix(X_te)))
            else:
                spw = pos_ratio if cfg["spw"] else 1.0
                m = XGBClassifier(objective="binary:logistic", n_estimators=200, max_depth=3, learning_rate=0.03,
                                  subsample=0.85, colsample_bytree=0.8, scale_pos_weight=spw, use_label_encoder=False,
                                  eval_metric="logloss", random_state=SEED, verbosity=0)
                m.fit(X_use, y_use); prob = m.predict_proba(X_te)[:, 1]
            pred = (prob >= 0.5).astype(int)
            interaction_results[name]["auc"].append(roc_auc_score(y_te, prob))
            interaction_results[name]["f1"].append(f1_score(y_te, pred, zero_division=0))
            interaction_results[name]["brier"].append(brier_score_loss(y_te, prob))

    interaction_summary = {k: {m: (float(np.mean(v)), float(np.std(v, ddof=1))) for m, v in metrics.items()}
                            for k, metrics in interaction_results.items()}
    for name, m in interaction_summary.items():
        p(f"  {name}: AUC={m['auc'][0]:.4f}±{m['auc'][1]:.4f}  F1={m['f1'][0]:.4f}±{m['f1'][1]:.4f}  Brier={m['brier'][0]:.4f}±{m['brier'][1]:.4f}")

    auc_nl = np.array(interaction_results["no_smote_logistic"]["auc"]); auc_nf = np.array(interaction_results["no_smote_focal"]["auc"])
    auc_sl = np.array(interaction_results["smote_logistic"]["auc"]); auc_sf = np.array(interaction_results["smote_focal"]["auc"])
    interaction_decomp = dict(
        smote_effect_under_logistic=float(auc_sl.mean() - auc_nl.mean()),
        smote_effect_under_focal=float(auc_sf.mean() - auc_nf.mean()),
        focal_effect_without_smote=float(auc_nf.mean() - auc_nl.mean()),
        focal_effect_with_smote=float(auc_sf.mean() - auc_sl.mean()),
    )
    p(f"  Interaction decomposition: {interaction_decomp}")

    checkpoint(dict(part1_nested_cv=summary_p1, part1_ablation_focal_only=ablation_summary,
                     part1_feature_retention=feature_retention, part1_significance=sig_p1,
                     part2_threshold_sweep=threshold_results, stable_features_used=stable_features,
                     part3_interaction=interaction_summary, part3_decomposition=interaction_decomp))

    # ========================================================================
    # PART 4 — Seed-variance vs fold-variance decomposition
    # ========================================================================
    p("\n--- PART 4: Seed-variance vs fold-variance decomposition ---")
    model_seeds = [42, 123, 456]
    auc_grid = np.zeros((len(model_seeds), len(outer_folds)))
    for s_i, model_seed in enumerate(model_seeds):
        for f_i, (tr_idx, te_idx) in enumerate(outer_folds):
            X_tr_raw, X_te_raw = X_stable[tr_idx], X_stable[te_idx]
            X_tr_raw, X_te_raw = impute_per_fold(X_tr_raw, X_te_raw, stable_features)
            y_tr, y_te = y_full[tr_idx], y_full[te_idx]
            scaler = MinMaxScaler(); X_tr = scaler.fit_transform(X_tr_raw); X_te = scaler.transform(X_te_raw)
            X_sm, y_sm = SMOTE(random_state=model_seed).fit_resample(X_tr, y_tr)
            dtr2 = xgb.DMatrix(X_sm, label=y_sm)
            booster = xgb.train({"max_depth": 3, "eta": 0.03, "subsample": 0.85, "colsample_bytree": 0.8,
                                 "seed": model_seed, "disable_default_eval_metric": 1}, dtr2, num_boost_round=200, obj=focal_obj(0.95, 0.5))
            prob = sigmoid(booster.predict(xgb.DMatrix(X_te)))
            auc_grid[s_i, f_i] = roc_auc_score(y_te, prob)
    fold_means = auc_grid.mean(axis=0); seed_means = auc_grid.mean(axis=1)
    var_fold = float(fold_means.var(ddof=1)); var_seed = float(seed_means.var(ddof=1)); var_total = float(auc_grid.var(ddof=1))
    p(f"  Var(fold)={var_fold:.6f}  Var(seed)={var_seed:.6f}  ratio={var_fold/var_seed if var_seed>0 else float('inf'):.1f}x")

    checkpoint(dict(part1_nested_cv=summary_p1, part1_ablation_focal_only=ablation_summary,
                     part1_feature_retention=feature_retention, part1_significance=sig_p1,
                     part2_threshold_sweep=threshold_results, stable_features_used=stable_features,
                     part3_interaction=interaction_summary, part3_decomposition=interaction_decomp,
                     part4_variance=dict(var_fold=var_fold, var_seed=var_seed, var_total=var_total)))

    # ========================================================================
    # PART 5 — Re-engineering attempts: interaction feature + class-weighted loss
    # ========================================================================
    p("\n--- PART 5: Re-engineering attempts (Step 3/4) ---")
    reeng_results = {}

    # Attempt A: pairwise interaction of the two top-SHAP features (generic, corpus-agnostic)
    top2 = [f for f, c in sorted(feature_retention.items(), key=lambda x: -x[1])][:2]
    idx1, idx2 = candidate_features.index(top2[0]), candidate_features.index(top2[1])
    interaction_feature_names = stable_features + [f"{top2[0]}_x_{top2[1]}"]

    def run_variant(X_base, y, folds, extra_interaction_idx=None):
        """extra_interaction_idx, if given, is (idx1, idx2) into X_full used to
        build a per-fold-imputed interaction term (NaN-safe: imputation happens
        on the raw base columns before multiplying, never on a pre-computed
        globally-built interaction column)."""
        aucs, f1s, briers = [], [], []
        for tr_idx, te_idx in folds:
            X_tr_raw, X_te_raw = X_base[tr_idx], X_base[te_idx]
            feat_names_here = stable_features
            X_tr_raw, X_te_raw = impute_per_fold(X_tr_raw, X_te_raw, feat_names_here)
            if extra_interaction_idx is not None:
                i1, i2 = extra_interaction_idx
                raw_pair_tr = X_full[tr_idx][:, [i1, i2]].copy()
                raw_pair_te = X_full[te_idx][:, [i1, i2]].copy()
                raw_pair_tr, raw_pair_te = impute_per_fold(raw_pair_tr, raw_pair_te, [top2[0], top2[1]])
                inter_tr = (raw_pair_tr[:, 0] * raw_pair_tr[:, 1]).reshape(-1, 1)
                inter_te = (raw_pair_te[:, 0] * raw_pair_te[:, 1]).reshape(-1, 1)
                X_tr_raw = np.hstack([X_tr_raw, inter_tr])
                X_te_raw = np.hstack([X_te_raw, inter_te])
            y_tr, y_te = y[tr_idx], y[te_idx]
            scaler = MinMaxScaler(); X_tr = scaler.fit_transform(X_tr_raw); X_te = scaler.transform(X_te_raw)
            X_sm, y_sm = SMOTE(random_state=SEED).fit_resample(X_tr, y_tr)
            m = XGBClassifier(objective="binary:logistic", n_estimators=200, max_depth=3, learning_rate=0.03,
                              subsample=0.85, colsample_bytree=0.8, use_label_encoder=False, eval_metric="logloss",
                              random_state=SEED, verbosity=0)
            m.fit(X_sm, y_sm); prob = m.predict_proba(X_te)[:, 1]; pred = (prob >= 0.5).astype(int)
            aucs.append(roc_auc_score(y_te, prob)); f1s.append(f1_score(y_te, pred, zero_division=0)); briers.append(brier_score_loss(y_te, prob))
        return np.array(aucs), np.array(f1s), np.array(briers)

    auc_base_r, f1_base_r, brier_base_r = run_variant(X_stable, y_full, outer_folds)
    auc_int_r, f1_int_r, brier_int_r = run_variant(X_stable, y_full, outer_folds, extra_interaction_idx=(idx1, idx2))
    _, p_int = wilcoxon(auc_int_r, auc_base_r, alternative="greater")
    reeng_results["interaction_feature"] = dict(
        base_auc=float(auc_base_r.mean()), int_auc=float(auc_int_r.mean()),
        delta=float(auc_int_r.mean() - auc_base_r.mean()), wilcoxon_p=float(p_int),
        interaction_features=top2,
    )
    p(f"  Interaction feature ({top2[0]} x {top2[1]}): ΔAUC={reeng_results['interaction_feature']['delta']:+.4f}, p={p_int:.4f}")

    # Attempt B: class-weighted logistic loss, weight calibrated to observed imbalance ratio.
    # pos_ratio can be <1 (if positives are the majority, as in the field corpus) or
    # >1 (if positives are the minority, as in IBM), so the search range must cover
    # both directions rather than assuming ratio > 1.
    w_lo = min(0.2, pos_ratio * 0.5)
    w_hi = max(5.0, pos_ratio * 2)

    def tune_weighted(trial):
        w = trial.suggest_float("weight", w_lo, w_hi)
        aucs = []
        for tr_idx, te_idx in outer_folds[:5]:  # quick calibration subset
            X_tr_raw, X_te_raw = X_stable[tr_idx], X_stable[te_idx]; y_tr, y_te = y_full[tr_idx], y_full[te_idx]
            X_tr_raw, X_te_raw = impute_per_fold(X_tr_raw, X_te_raw, stable_features)
            scaler = MinMaxScaler(); X_tr = scaler.fit_transform(X_tr_raw); X_te = scaler.transform(X_te_raw)
            m = XGBClassifier(objective="binary:logistic", n_estimators=200, max_depth=3, learning_rate=0.03,
                              subsample=0.85, colsample_bytree=0.8, scale_pos_weight=w, use_label_encoder=False,
                              eval_metric="logloss", random_state=SEED, verbosity=0)
            m.fit(X_tr, y_tr); prob = m.predict_proba(X_te)[:, 1]
            aucs.append(roc_auc_score(y_te, prob))
        return np.mean(aucs)
    study_w = optuna.create_study(direction="maximize", sampler=optuna.samplers.TPESampler(seed=SEED))
    study_w.optimize(tune_weighted, n_trials=10, show_progress_bar=False)
    best_w = study_w.best_params["weight"]

    auc_w, f1_w, brier_w = [], [], []
    for tr_idx, te_idx in outer_folds:
        X_tr_raw, X_te_raw = X_stable[tr_idx], X_stable[te_idx]; y_tr, y_te = y_full[tr_idx], y_full[te_idx]
        X_tr_raw, X_te_raw = impute_per_fold(X_tr_raw, X_te_raw, stable_features)
        scaler = MinMaxScaler(); X_tr = scaler.fit_transform(X_tr_raw); X_te = scaler.transform(X_te_raw)
        m = XGBClassifier(objective="binary:logistic", n_estimators=200, max_depth=3, learning_rate=0.03,
                          subsample=0.85, colsample_bytree=0.8, scale_pos_weight=best_w, use_label_encoder=False,
                          eval_metric="logloss", random_state=SEED, verbosity=0)
        m.fit(X_tr, y_tr); prob = m.predict_proba(X_te)[:, 1]; pred = (prob >= 0.5).astype(int)
        auc_w.append(roc_auc_score(y_te, prob)); f1_w.append(f1_score(y_te, pred, zero_division=0)); brier_w.append(brier_score_loss(y_te, prob))
    auc_w = np.array(auc_w); f1_w = np.array(f1_w); brier_w = np.array(brier_w)
    _, p_w = wilcoxon(auc_w, auc_base_r, alternative="greater")
    reeng_results["class_weighted_loss"] = dict(
        best_weight=float(best_w), base_auc=float(auc_base_r.mean()), weighted_auc=float(auc_w.mean()),
        delta=float(auc_w.mean() - auc_base_r.mean()), wilcoxon_p=float(p_w),
    )
    p(f"  Class-weighted loss (w={best_w:.3f}): ΔAUC={reeng_results['class_weighted_loss']['delta']:+.4f}, p={p_w:.4f}")

    # ========================================================================
    # Final save (all parts complete)
    # ========================================================================
    output = dict(
        corpus=corpus_name, n=len(y_full), positive_rate=float(y_full.mean()),
        part1_nested_cv=summary_p1, part1_ablation_focal_only=ablation_summary,
        part1_feature_retention=feature_retention, part1_significance=sig_p1,
        part1_raw_folds={k: v for k, v in results.items()},
        part2_threshold_sweep=threshold_results,
        part3_interaction=interaction_summary, part3_decomposition=interaction_decomp,
        part4_variance=dict(var_fold=var_fold, var_seed=var_seed, var_total=var_total),
        part5_reengineering=reeng_results,
        stable_features_used=stable_features,
        runtime_seconds=time.time() - t_start,
        log=log,
    )
    with open(f"{out_prefix}_full_battery.json", "w") as f:
        json.dump(output, f, indent=2)
    p(f"\nTotal runtime: {time.time()-t_start:.0f}s. Saved to {out_prefix}_full_battery.json")
    return output
