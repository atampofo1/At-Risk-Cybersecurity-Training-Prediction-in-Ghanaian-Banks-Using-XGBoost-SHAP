"""
preprocessing.py

Shared preprocessing utilities used identically by field_pipeline.py and
ibm_pipeline.py, per Methods M6-M9 and M10 (CROSS-DATASET strategy: the
identical pipeline logic is applied independently to each corpus; no data,
fitted transform, or trained weight is ever shared between corpora).

REVISION NOTE: adds impute_per_fold(), which closes two leakage patterns
identified in this revision's diagnostic audit (Methods M6, M9; Results
R10): (1) feature selection and hyperparameter tuning are now fitted on
an inner-training partition within each outer fold, never on data that
fold will later score, and (2) any NaN-containing feature (specifically
training_sessions_raw, see field_pipeline.py) is median-imputed using
the training portion's own statistics only, never the full corpus.
"""

import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import RepeatedStratifiedKFold, train_test_split
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, brier_score_loss,
)
from imblearn.over_sampling import SMOTE

SEED = 42
np.random.seed(SEED)


def full_metrics(y_true, y_pred, y_prob) -> dict:
    """Six metrics reported per Methods M15."""
    return dict(
        acc=accuracy_score(y_true, y_pred),
        prec=precision_score(y_true, y_pred, zero_division=0),
        rec=recall_score(y_true, y_pred, zero_division=0),
        f1=f1_score(y_true, y_pred, zero_division=0),
        auc=roc_auc_score(y_true, y_prob),
        brier=brier_score_loss(y_true, y_prob),
    )


def impute_per_fold(X_train_raw: np.ndarray, X_test_raw: np.ndarray, feature_names: list):
    """
    Per-fold median imputation for any feature containing NaN (e.g.
    informative missingness in training_sessions_raw, Methods M6), fitted
    on the training portion only and applied unchanged to the test
    portion. The median is never computed on the full corpus or on data
    the fold will later score (Methods M9; closes the Q11 finding).
    """
    X_train = X_train_raw.copy()
    X_test = X_test_raw.copy()
    for j in range(len(feature_names)):
        col_train = X_train[:, j]
        if np.isnan(col_train).any():
            med = np.nanmedian(col_train)
            X_train[np.isnan(X_train[:, j]), j] = med
            X_test[np.isnan(X_test[:, j]), j] = med
    return X_train, X_test


def procedure_a_folds(X: np.ndarray, y: np.ndarray, n_splits=5, n_repeats=3, seed=SEED):
    """
    Procedure A outer folds (Methods M9): repeated stratified k-fold
    cross-validation applied directly to the full corpus. Produces the
    headline mean +/- SD results (Results Tables 4, 5, 7). Feature
    selection and hyperparameter tuning are performed on a further
    inner split of each outer-training portion -- see field_pipeline.py
    / ibm_pipeline.py / full_diagnostic_battery.py for the nested logic.
    """
    return list(RepeatedStratifiedKFold(
        n_splits=n_splits, n_repeats=n_repeats, random_state=seed
    ).split(X, y))


def procedure_b_split(X: np.ndarray, y: np.ndarray, test_size=0.2, seed=SEED):
    """
    Procedure B (Methods M9): a single stratified train:test split drawn
    once, independently of Procedure A. Used only to produce the
    single-model illustrative diagnostics (Results Figure 4, Figure 6,
    Figure 7, Table 6). Never used to compute the Procedure A headline
    metrics.
    """
    X_train_raw, X_test_raw, y_train, y_test = train_test_split(
        X, y, test_size=test_size, stratify=y, random_state=seed
    )
    X_train_raw, X_test_raw = impute_per_fold(X_train_raw, X_test_raw,
                                               feature_names=list(range(X.shape[1])))
    scaler = MinMaxScaler()
    X_train = scaler.fit_transform(X_train_raw)
    X_test = scaler.transform(X_test_raw)
    X_train_sm, y_train_sm = SMOTE(random_state=seed).fit_resample(X_train, y_train)
    return X_train_sm, y_train_sm, X_test, y_test, scaler


def leakage_audit(feature_cols: list, label_derived_cols: list) -> None:
    """
    Programmatic leakage audit (Methods M7): raises if any column used to
    construct the target label has leaked into the predictor set.
    """
    leaks = [f for f in feature_cols if f in label_derived_cols]
    if leaks:
        raise ValueError(f"LEAKAGE DETECTED — label-derived features in predictors: {leaks}")
