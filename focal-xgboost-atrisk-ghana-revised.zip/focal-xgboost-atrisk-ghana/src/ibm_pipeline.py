"""
ibm_pipeline.py

Validation corpus (PUBLIC) pipeline, referenced by name in Methods M10.

Runs Procedure A (Methods M9) on the public IBM HR Analytics Employee
Attrition dataset (IBM, 2017; n = 1,470), independently of
field_pipeline.py -- per the CROSS-DATASET strategy (Methods M10), no
row, feature value, or fitted transformation is ever shared between the
two corpora, and no trained model weight is transferred between them.

This corpus had zero missing values on audit (confirmed in this
revision; see Results R10), so the training_sessions-style correction
in field_pipeline.py has no IBM equivalent and this script's numbers
are unchanged from the previous submission round.

For the full corrected diagnostic battery (nested CV + matched-budget
comparators + threshold sweep + SMOTE x focal interaction + seed-variance
decomposition + re-engineering attempts), see full_diagnostic_battery.py.

Usage
-----
    python src/ibm_pipeline.py
"""

import argparse
import json
import os
import urllib.request
import warnings

import numpy as np
import pandas as pd
import shap
import xgboost as xgb
from sklearn.preprocessing import LabelEncoder
from sklearn.feature_selection import RFE
from sklearn.metrics import f1_score, roc_auc_score
from xgboost import XGBClassifier

from focal_loss import focal_loss_obj, sigmoid
from preprocessing import SEED, procedure_a_folds, impute_per_fold

warnings.filterwarnings("ignore")
np.random.seed(SEED)

IBM_URL = (
    "https://github.com/nelson-wu/employee-attrition-ml/raw/refs/heads/master/"
    "WA_Fn-UseC_-HR-Employee-Attrition.csv"
)
N_ESTIMATORS_RANGE = (100, 300)
N_INNER_TRIALS = 8

# All sixteen native employee-record columns are candidates (Methods M7);
# eight are selected per outer fold following the same nested procedure
# as the primary corpus.
FEATURES = [
    "age", "tenure", "total_years", "job_role", "job_level", "job_involve",
    "job_sat", "env_sat", "income", "overtime", "stock", "wlb", "distance",
    "training", "num_comp", "promo",
]


def download_data(cache_path: str = "data/ibm_hr_attrition.csv") -> str:
    """Download the public IBM HR dataset if not already cached locally."""
    os.makedirs(os.path.dirname(cache_path), exist_ok=True)
    if not os.path.exists(cache_path):
        urllib.request.urlretrieve(IBM_URL, cache_path)
    return cache_path


def load_and_prepare(path: str) -> pd.DataFrame:
    """Load the IBM HR CSV, in its released, unmodified form (Methods M4),
    and encode the sixteen native predictors."""
    ibm = pd.read_csv(path)
    ibm["at_risk"] = (ibm["Attrition"].astype(str).str.strip() == "Yes").astype(int)

    feat = pd.DataFrame(index=ibm.index)
    feat["age"] = ibm["Age"]
    feat["tenure"] = ibm["YearsAtCompany"]
    feat["total_years"] = ibm["TotalWorkingYears"]
    feat["job_role"] = LabelEncoder().fit_transform(ibm["JobRole"])
    feat["job_level"] = ibm["JobLevel"]
    feat["job_involve"] = ibm["JobInvolvement"]
    feat["job_sat"] = ibm["JobSatisfaction"]
    feat["env_sat"] = ibm["EnvironmentSatisfaction"]
    feat["income"] = ibm["MonthlyIncome"]
    feat["overtime"] = (ibm["OverTime"] == "Yes").astype(int)
    feat["stock"] = ibm["StockOptionLevel"]
    feat["wlb"] = ibm["WorkLifeBalance"]
    feat["distance"] = ibm["DistanceFromHome"]
    feat["training"] = ibm["TrainingTimesLastYear"]
    feat["num_comp"] = ibm["NumCompaniesWorked"]
    feat["promo"] = ibm["YearsSinceLastPromotion"]
    feat["at_risk"] = ibm["at_risk"].values

    assert feat.isna().sum().sum() == 0, "Unexpected missing values found in IBM corpus"
    return feat


def run_procedure_a(df: pd.DataFrame, n_trials: int = N_INNER_TRIALS) -> dict:
    """Procedure A: nested repeated-CV headline metrics (Methods M9, M11;
    Results Tables 4, 7). See field_pipeline.py for detailed inline
    comments; the logic is identical, applied to this corpus's own
    sixteen native candidate features."""
    import optuna
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import MinMaxScaler
    from imblearn.over_sampling import SMOTE

    optuna.logging.set_verbosity(optuna.logging.WARNING)

    X = df[FEATURES].values.astype(float)
    y = df["at_risk"].values
    folds = procedure_a_folds(X, y)

    results = {"baseline": {"auc": [], "f1": []}, "proposed": {"auc": [], "f1": []}}

    for outer_train_idx, outer_test_idx in folds:
        X_outer_train_raw, X_outer_test_raw = X[outer_train_idx], X[outer_test_idx]
        y_outer_train, y_outer_test = y[outer_train_idx], y[outer_test_idx]

        X_inner_train_raw, X_inner_val_raw, y_inner_train, y_inner_val = train_test_split(
            X_outer_train_raw, y_outer_train, test_size=0.2, stratify=y_outer_train, random_state=SEED
        )
        scaler = MinMaxScaler()
        X_inner_train = scaler.fit_transform(X_inner_train_raw)
        X_inner_val = scaler.transform(X_inner_val_raw)
        X_inner_train_sm, y_inner_train_sm = SMOTE(random_state=SEED).fit_resample(X_inner_train, y_inner_train)

        base_for_shap = XGBClassifier(objective="binary:logistic", n_estimators=150, max_depth=4,
            learning_rate=0.1, subsample=0.8, colsample_bytree=0.8, use_label_encoder=False,
            eval_metric="logloss", random_state=SEED, verbosity=0)
        base_for_shap.fit(X_inner_train_sm, y_inner_train_sm)
        explainer = shap.TreeExplainer(base_for_shap)
        shap_vals = explainer.shap_values(X_inner_train_sm)
        ranking = pd.DataFrame({"feature": FEATURES,
                                 "mean_abs_shap": np.abs(shap_vals).mean(axis=0)}).sort_values("mean_abs_shap", ascending=False)
        n_drop = max(1, len(FEATURES) // 5)
        pruned = [f for f in FEATURES if f not in ranking.tail(n_drop)["feature"].tolist()]
        rfe = RFE(estimator=XGBClassifier(n_estimators=80, random_state=SEED, verbosity=0,
                  use_label_encoder=False, eval_metric="logloss"), n_features_to_select=min(8, len(pruned)))
        rfe.fit(pd.DataFrame(X_inner_train_sm, columns=FEATURES)[pruned], y_inner_train_sm)
        selected = [f for f, s in zip(pruned, rfe.support_) if s]
        sel_idx = [FEATURES.index(f) for f in selected]

        Xi_tr = X_inner_train_sm[:, sel_idx]
        Xi_val = X_inner_val[:, sel_idx]

        scaler2 = MinMaxScaler()
        Xo_train = scaler2.fit_transform(X_outer_train_raw[:, sel_idx])
        Xo_test = scaler2.transform(X_outer_test_raw[:, sel_idx])
        Xo_train_sm, yo_train_sm = SMOTE(random_state=SEED).fit_resample(Xo_train, y_outer_train)

        def tune_xgb(trial):
            params = dict(max_depth=trial.suggest_int("max_depth", 3, 7),
                          learning_rate=trial.suggest_float("learning_rate", 0.01, 0.2, log=True),
                          n_estimators=trial.suggest_int("n_estimators", *N_ESTIMATORS_RANGE),
                          subsample=trial.suggest_float("subsample", 0.6, 1.0),
                          colsample_bytree=trial.suggest_float("colsample_bytree", 0.6, 1.0))
            m = XGBClassifier(**params, objective="binary:logistic", use_label_encoder=False,
                              eval_metric="logloss", random_state=SEED, verbosity=0)
            m.fit(Xi_tr, y_inner_train_sm)
            p = m.predict_proba(Xi_val)[:, 1]
            return f1_score(y_inner_val, (p >= 0.5).astype(int), zero_division=0)
        study_bl = optuna.create_study(direction="maximize", sampler=optuna.samplers.TPESampler(seed=SEED))
        study_bl.optimize(tune_xgb, n_trials=n_trials, show_progress_bar=False)
        bl_final = XGBClassifier(**study_bl.best_params, objective="binary:logistic", use_label_encoder=False,
                                 eval_metric="logloss", random_state=SEED, verbosity=0)
        bl_final.fit(Xo_train_sm, yo_train_sm)
        p = bl_final.predict_proba(Xo_test)[:, 1]
        results["baseline"]["auc"].append(roc_auc_score(y_outer_test, p))
        results["baseline"]["f1"].append(f1_score(y_outer_test, (p >= 0.5).astype(int), zero_division=0))

        def tune_focal(trial):
            params = dict(max_depth=trial.suggest_int("max_depth", 3, 7),
                          eta=trial.suggest_float("eta", 0.01, 0.2, log=True),
                          subsample=trial.suggest_float("subsample", 0.6, 1.0),
                          colsample_bytree=trial.suggest_float("colsample_bytree", 0.6, 1.0),
                          reg_alpha=trial.suggest_float("reg_alpha", 0.0, 2.0),
                          reg_lambda=trial.suggest_float("reg_lambda", 0.5, 3.0),
                          min_child_weight=trial.suggest_int("min_child_weight", 1, 10),
                          disable_default_eval_metric=1)
            n_est = trial.suggest_int("n_estimators", *N_ESTIMATORS_RANGE)
            gamma = trial.suggest_float("gamma", 0.3, 4.0)
            alpha = trial.suggest_float("alpha_fl", 0.1, 0.7)
            dtr = xgb.DMatrix(Xi_tr, label=y_inner_train_sm)
            dv = xgb.DMatrix(Xi_val)
            booster = xgb.train(params, dtr, num_boost_round=n_est, obj=focal_loss_obj(gamma, alpha))
            p = sigmoid(booster.predict(dv))
            return f1_score(y_inner_val, (p >= 0.5).astype(int), zero_division=0)
        study_fl = optuna.create_study(direction="maximize", sampler=optuna.samplers.TPESampler(seed=SEED))
        study_fl.optimize(tune_focal, n_trials=n_trials + 3, show_progress_bar=False)
        bp = study_fl.best_params.copy()
        gamma = bp.pop("gamma"); alpha = bp.pop("alpha_fl"); n_est = bp.pop("n_estimators")
        dtr_f = xgb.DMatrix(Xo_train_sm, label=yo_train_sm)
        final_booster = xgb.train({**bp, "disable_default_eval_metric": 1}, dtr_f,
                                  num_boost_round=n_est, obj=focal_loss_obj(gamma, alpha))
        p = sigmoid(final_booster.predict(xgb.DMatrix(Xo_test)))
        results["proposed"]["auc"].append(roc_auc_score(y_outer_test, p))
        results["proposed"]["f1"].append(f1_score(y_outer_test, (p >= 0.5).astype(int), zero_division=0))

    return {model: {m: (float(np.mean(v)), float(np.std(v, ddof=1))) for m, v in metrics.items()}
            for model, metrics in results.items()}


def main():
    parser = argparse.ArgumentParser(description="Validation (IBM HR) corpus pipeline")
    parser.add_argument("--data", default=None, help="Path to a local copy of the IBM HR CSV (optional; auto-downloads if omitted)")
    parser.add_argument("--out", default="results/ibm_results.json", help="Output JSON path")
    args = parser.parse_args()

    path = args.data or download_data()
    df = load_and_prepare(path)
    print(f"Loaded {len(df)} records; attrition prevalence {df['at_risk'].mean()*100:.1f}%")

    print("Running Procedure A (nested repeated CV)...")
    proc_a = run_procedure_a(df)
    for model, metrics in proc_a.items():
        print(f"  {model}: AUC={metrics['auc'][0]:.4f}+/-{metrics['auc'][1]:.4f}  "
              f"F1={metrics['f1'][0]:.4f}+/-{metrics['f1'][1]:.4f}")

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w") as f:
        json.dump(proc_a, f, indent=2)
    print(f"Saved summary to {args.out}")


if __name__ == "__main__":
    main()
