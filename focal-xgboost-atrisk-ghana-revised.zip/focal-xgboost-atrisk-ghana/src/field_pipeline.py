"""
field_pipeline.py

Primary corpus (FIELD) pipeline, referenced by name in Methods M10.

REVISION NOTE (this version): fixes a data-quality bug found and disclosed
in Methods M6 / Results R10. The training-session-count item had 33.2%
non-response (177 of 533 records), and no respondent selected a genuine
"zero sessions" category at all. An earlier version of this pipeline
silently coded every non-response as 0, wrongly conflating "did not
answer" with "attended zero sessions". This version instead:
  - keeps genuine responses on their natural ordinal scale (NaN where
    the respondent did not answer -- never coded to zero),
  - adds an explicit training_sessions_missing indicator feature, and
  - imputes the genuine-response NaNs using the training-fold median
    only, inside the nested cross-validation loop (never globally),
    closing a leakage pattern Q11 also flagged.

Runs both evaluation procedures declared in Methods M9:
  Procedure A - repeated stratified 5-fold CV, 3 repeats (15 outer folds),
                with an inner train/validation split per outer fold used
                for BOTH feature selection and hyperparameter tuning
                (closing the GATE-1 finding that this partition was
                previously undefined). Produces the headline mean +/- SD
                results (Results Tables 4, 5, 7).
  Procedure B - a single stratified 80:20 train:test split, drawn once,
                independently of Procedure A. Produces the illustrative
                diagnostics (Results Figure 4, Figure 6, Figure 7, Table 6).

For the full corrected diagnostic battery (nested CV + matched-budget
comparators + threshold sweep + SMOTE x focal interaction + seed-variance
decomposition + re-engineering attempts), see full_diagnostic_battery.py,
which this script's logic is a focused subset of.

Usage
-----
    python src/field_pipeline.py --data path/to/field_survey.xlsx

The raw field dataset is not distributed with this repository (Methods
M5, M21); provide your own de-identified copy locally to reproduce the
primary-corpus results. See data/README.md.
"""

import argparse
import json
import os
import warnings

import numpy as np
import pandas as pd
import shap
import xgboost as xgb
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_selection import RFE
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.metrics import f1_score, roc_auc_score
from sklearn.preprocessing import LabelEncoder
from xgboost import XGBClassifier

from focal_loss import focal_loss_obj, sigmoid
from preprocessing import (
    SEED, full_metrics, leakage_audit, impute_per_fold,
    procedure_a_folds, procedure_b_split,
)

warnings.filterwarnings("ignore")
np.random.seed(SEED)

# ---------------------------------------------------------------------------
# Proposed model configuration (Methods M13): search space used for the
# per-outer-fold Optuna search. Under the corrected nested design, the
# selected hyperparameter VALUES vary per fold; there is no longer a single
# global "winning" configuration to hard-code (this differs from an earlier
# version of this file, which hard-coded one FIELD_CFG for all folds --
# see Methods M13 and full_diagnostic_battery.py for the corrected search).
# ---------------------------------------------------------------------------
N_ESTIMATORS_RANGE = (100, 300)
N_INNER_TRIALS = 8  # reduced from a nominal 50-trial budget for tractability; see Methods M13

# Eleven raw candidate predictors after the M6 correction (was ten before
# the training_sessions fix added the explicit missingness indicator).
CANDIDATE_FEATURES = [
    "gender_enc", "age_group_enc", "job_role_enc", "banking_tenure_enc",
    "training_provided_enc", "training_sessions_raw", "training_sessions_missing",
    "phishing_sim_enc", "training_quality_enc", "E1_enc", "E2_enc",
]

LABEL_DERIVED_COLUMNS = [
    "C1_score", "C2_score", "C3_score", "C4_score", "C_total", "C_pct",
    "D1_num", "D2_num", "D3_num", "D4_num", "D5_num", "D_total", "at_risk",
]


def load_and_prepare(path: str) -> pd.DataFrame:
    """Load the raw questionnaire export and construct the at-risk label
    and encoded predictors (Methods M6, M7, M8), with the corrected
    training-session encoding described in the module docstring."""
    df_raw = pd.read_excel(path)

    rename = {}
    for c in df_raw.columns:
        for prefix, name in [
            ("A1", "gender"), ("A2", "age_group"), ("A3", "job_role"),
            ("A4", "banking_tenure"), ("B1", "training_provided"),
            ("B2", "training_sessions"), ("B3", "phishing_sim"),
            ("B4", "training_quality"), ("C1", "C1"), ("C2", "C2"),
            ("C3", "C3"), ("C4", "C4"), ("D1", "D1"), ("D2", "D2"),
            ("D3", "D3"), ("D4", "D4"), ("D5", "D5"),
            ("E1", "E1_topic"), ("E2", "E2_format"),
        ]:
            if c.startswith(prefix):
                rename[c] = name
                break
    df = df_raw.rename(columns=rename)

    # Knowledge-assessment scoring (Section C) -- used ONLY to build the label.
    correct = {
        "C1": "Phishing email",
        "C2": "Verify with the IT department through a separate, trusted channel before clicking",
        "C3": "Using a unique password of 12+ characters combining letters, numbers, and symbols",
        "C4": "Report it to IT security without plugging it in",
    }
    for col, ans in correct.items():
        df[f"{col}_score"] = df[col].apply(
            lambda x, a=ans: 1 if isinstance(x, str) and a.lower() in x.lower() else 0
        )
    df["C_total"] = df[["C1_score", "C2_score", "C3_score", "C4_score"]].sum(axis=1)
    df["C_pct"] = df["C_total"] / 4

    # Self-assessment scoring (Section D) -- used ONLY to build the label.
    # Zero missing values found in this item on audit (Methods M6); the
    # fillna below is a no-op safety net, not an active correction.
    def parse_likert(v):
        if pd.isna(v):
            return np.nan
        v = str(v).strip()
        if "," in v:
            v = v.split(",")[0].strip()
        for part in v.split("."):
            try:
                n = int(part.strip())
                if 1 <= n <= 5:
                    return n
            except ValueError:
                pass
        try:
            return int(v)
        except ValueError:
            return np.nan

    d_cols = ["D1", "D2", "D3", "D4", "D5"]
    for col in d_cols:
        df[f"{col}_num"] = df[col].apply(parse_likert)
    d_num_cols = [f"{c}_num" for c in d_cols]
    for col in d_num_cols:
        df[col] = df[col].fillna(df[col].median())
    df["D_total"] = df[d_num_cols].sum(axis=1)

    df["at_risk"] = ((df["C_pct"] < 0.60) | (df["D_total"] < 15)).astype(int)

    # Predictor encoding (Methods M7). gender/age_group/banking_tenure have
    # at most one missing record each (Methods M6); job_role's single
    # missing record falls into the "Other" category via map_job_role below.
    df["gender_enc"] = df["gender"].map({"Male": 1, "Female": 0}).fillna(0).astype(int)
    df["age_group_enc"] = df["age_group"].map({
        "18–25 years": 1, "26–35 years": 2, "36–45 years": 3,
        "46–55 years": 4, "56 years and above": 5,
    }).fillna(0).astype(int)
    df["banking_tenure_enc"] = df["banking_tenure"].map({
        "Less than 1 year": 0, "1–3 years": 1, "4–7 years": 2,
        "8–12 years": 3, "More than 12 years": 4,
    }).fillna(0).astype(int)
    df["training_provided_enc"] = df["training_provided"].map(
        {"Yes": 2, "I am not aware": 1, "No": 0}
    ).fillna(0).astype(int)

    # ---- CORRECTED: training_sessions ----
    # No genuine "None/0" response category exists in the raw data at all;
    # 33.2% of respondents simply did not answer, and non-response is
    # strongly informative (96.0% at-risk among non-responders vs. 74.2%
    # among responders -- see Results R10). Keep genuine responses on
    # their natural ordinal scale, leave non-response as NaN (imputed
    # per-fold downstream via impute_per_fold, never globally), and add
    # an explicit missingness indicator.
    ts_map = {"1 session": 1, "2–3 sessions": 2, "4–5 sessions": 3, "More than 5 sessions": 4}
    df["training_sessions_raw"] = df["training_sessions"].map(ts_map)  # NaN where non-response
    df["training_sessions_missing"] = df["training_sessions"].isna().astype(int)

    df["phishing_sim_enc"] = df["phishing_sim"].map({
        "Yes — and I identified the phishing attempt correctly": 2,
        "Yes — but I did not identify the phishing attempt": 1,
        "No — my bank has not conducted phishing simulations": 0,
        "I do not know what a phishing simulation is": 0,
    }).fillna(0).astype(int)
    df["training_quality_enc"] = df["training_quality"].map({
        "I have not received training": 0, "Very poor": 1, "Poor": 2,
        "Average": 3, "Good": 4, "Excellent": 5,
    }).fillna(0).astype(int)

    def map_job_role(role):
        if pd.isna(role):
            return "Other"
        role = str(role).strip()
        mapping = {
            "Teller": "Teller", "IT": "IT", "Technology": "IT",
            "Cybersecurity": "IT", "Operations": "Operations",
            "Finance": "Finance", "Accounts": "Finance",
            "Management": "Management", "Senior Leadership": "Management",
            "Compliance": "Compliance", "Risk": "Compliance", "Legal": "Compliance",
            "Human Resources": "HR", "Audit": "Audit", "Credit": "Credit",
            "Mobile": "IT",
        }
        for key, val in mapping.items():
            if key.lower() in role.lower():
                return val
        return "Other"

    df["job_role_enc"] = LabelEncoder().fit_transform(df["job_role"].apply(map_job_role))
    df["E1_enc"] = LabelEncoder().fit_transform(
        df["E1_topic"].fillna("Unknown").apply(
            lambda x: x.split(",")[0].strip() if isinstance(x, str) else "Unknown"
        )
    )
    df["E2_enc"] = LabelEncoder().fit_transform(
        df["E2_format"].fillna("Unknown").apply(
            lambda x: x.split(",")[0].strip() if isinstance(x, str) else "Unknown"
        )
    )

    leakage_audit(CANDIDATE_FEATURES, LABEL_DERIVED_COLUMNS)
    return df


def run_procedure_a(df: pd.DataFrame, n_trials: int = N_INNER_TRIALS) -> dict:
    """
    Procedure A: nested repeated-CV headline metrics (Methods M9, M11, M16;
    Results Tables 4, 5). Feature selection AND hyperparameter tuning are
    both fitted on the inner-training partition only, within each outer
    fold -- see full_diagnostic_battery.py for the complete implementation
    including matched-budget Random Forest / Logistic Regression / SVM
    comparators, which are omitted here for brevity.
    """
    import optuna
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import MinMaxScaler
    from imblearn.over_sampling import SMOTE

    optuna.logging.set_verbosity(optuna.logging.WARNING)

    X = df[CANDIDATE_FEATURES].values.astype(float)
    y = df["at_risk"].values
    folds = procedure_a_folds(X, y)

    results = {"baseline": {"auc": [], "f1": []}, "proposed": {"auc": [], "f1": []}}

    for outer_train_idx, outer_test_idx in folds:
        X_outer_train_raw, X_outer_test_raw = X[outer_train_idx], X[outer_test_idx]
        X_outer_train_raw, X_outer_test_raw = impute_per_fold(
            X_outer_train_raw, X_outer_test_raw, CANDIDATE_FEATURES
        )
        y_outer_train, y_outer_test = y[outer_train_idx], y[outer_test_idx]

        X_inner_train_raw, X_inner_val_raw, y_inner_train, y_inner_val = train_test_split(
            X_outer_train_raw, y_outer_train, test_size=0.2, stratify=y_outer_train, random_state=SEED
        )
        scaler = MinMaxScaler()
        X_inner_train = scaler.fit_transform(X_inner_train_raw)
        X_inner_val = scaler.transform(X_inner_val_raw)
        X_inner_train_sm, y_inner_train_sm = SMOTE(random_state=SEED).fit_resample(X_inner_train, y_inner_train)

        # Feature selection in-fold (Methods M7)
        base_for_shap = XGBClassifier(objective="binary:logistic", n_estimators=150, max_depth=4,
            learning_rate=0.1, subsample=0.8, colsample_bytree=0.8, use_label_encoder=False,
            eval_metric="logloss", random_state=SEED, verbosity=0)
        base_for_shap.fit(X_inner_train_sm, y_inner_train_sm)
        explainer = shap.TreeExplainer(base_for_shap)
        shap_vals = explainer.shap_values(X_inner_train_sm)
        ranking = pd.DataFrame({"feature": CANDIDATE_FEATURES,
                                 "mean_abs_shap": np.abs(shap_vals).mean(axis=0)}).sort_values("mean_abs_shap", ascending=False)
        pruned = [f for f in CANDIDATE_FEATURES if f not in ranking.tail(2)["feature"].tolist()]
        rfe = RFE(estimator=XGBClassifier(n_estimators=80, random_state=SEED, verbosity=0,
                  use_label_encoder=False, eval_metric="logloss"), n_features_to_select=min(8, len(pruned)))
        rfe.fit(pd.DataFrame(X_inner_train_sm, columns=CANDIDATE_FEATURES)[pruned], y_inner_train_sm)
        selected = [f for f, s in zip(pruned, rfe.support_) if s]
        sel_idx = [CANDIDATE_FEATURES.index(f) for f in selected]

        Xi_tr = X_inner_train_sm[:, sel_idx]
        Xi_val = X_inner_val[:, sel_idx]

        scaler2 = MinMaxScaler()
        Xo_train = scaler2.fit_transform(X_outer_train_raw[:, sel_idx])
        Xo_test = scaler2.transform(X_outer_test_raw[:, sel_idx])
        Xo_train_sm, yo_train_sm = SMOTE(random_state=SEED).fit_resample(Xo_train, y_outer_train)

        # Baseline (tuned)
        def tune_xgb(trial):
            params = dict(max_depth=trial.suggest_int("max_depth", 3, 7),
                          learning_rate=trial.suggest_float("learning_rate", 0.01, 0.2, log=True),
                          n_estimators=trial.suggest_int("n_estimators", *N_ESTIMATORS_RANGE),
                          subsample=trial.suggest_float("subsample", 0.6, 1.0),
                          colsample_bytree=trial.suggest_float("colsample_bytree", 0.6, 1.0))
            m = XGBClassifier(**params, objective="binary:logistic", use_label_encoder=False,
                              eval_metric="logloss", random_state=SEED, verbosity=0)
            m.fit(Xi_tr, y_inner_train_sm)
            p = m.predict_proba(Xi_val)[:, 1]
            return f1_score(y_inner_val, (p >= 0.5).astype(int), zero_division=0)
        study_bl = optuna.create_study(direction="maximize", sampler=optuna.samplers.TPESampler(seed=SEED))
        study_bl.optimize(tune_xgb, n_trials=n_trials, show_progress_bar=False)
        bl_final = XGBClassifier(**study_bl.best_params, objective="binary:logistic", use_label_encoder=False,
                                 eval_metric="logloss", random_state=SEED, verbosity=0)
        bl_final.fit(Xo_train_sm, yo_train_sm)
        p = bl_final.predict_proba(Xo_test)[:, 1]
        results["baseline"]["auc"].append(roc_auc_score(y_outer_test, p))
        results["baseline"]["f1"].append(f1_score(y_outer_test, (p >= 0.5).astype(int), zero_division=0))

        # Proposed (focal loss, tuned)
        def tune_focal(trial):
            params = dict(max_depth=trial.suggest_int("max_depth", 3, 7),
                          eta=trial.suggest_float("eta", 0.01, 0.2, log=True),
                          subsample=trial.suggest_float("subsample", 0.6, 1.0),
                          colsample_bytree=trial.suggest_float("colsample_bytree", 0.6, 1.0),
                          reg_alpha=trial.suggest_float("reg_alpha", 0.0, 2.0),
                          reg_lambda=trial.suggest_float("reg_lambda", 0.5, 3.0),
                          min_child_weight=trial.suggest_int("min_child_weight", 1, 10),
                          disable_default_eval_metric=1)
            n_est = trial.suggest_int("n_estimators", *N_ESTIMATORS_RANGE)
            gamma = trial.suggest_float("gamma", 0.3, 4.0)
            alpha = trial.suggest_float("alpha_fl", 0.1, 0.7)
            dtr = xgb.DMatrix(Xi_tr, label=y_inner_train_sm)
            dv = xgb.DMatrix(Xi_val)
            booster = xgb.train(params, dtr, num_boost_round=n_est, obj=focal_loss_obj(gamma, alpha))
            p = sigmoid(booster.predict(dv))
            return f1_score(y_inner_val, (p >= 0.5).astype(int), zero_division=0)
        study_fl = optuna.create_study(direction="maximize", sampler=optuna.samplers.TPESampler(seed=SEED))
        study_fl.optimize(tune_focal, n_trials=n_trials + 3, show_progress_bar=False)
        bp = study_fl.best_params.copy()
        gamma = bp.pop("gamma"); alpha = bp.pop("alpha_fl"); n_est = bp.pop("n_estimators")
        dtr_f = xgb.DMatrix(Xo_train_sm, label=yo_train_sm)
        final_booster = xgb.train({**bp, "disable_default_eval_metric": 1}, dtr_f,
                                  num_boost_round=n_est, obj=focal_loss_obj(gamma, alpha))
        p = sigmoid(final_booster.predict(xgb.DMatrix(Xo_test)))
        results["proposed"]["auc"].append(roc_auc_score(y_outer_test, p))
        results["proposed"]["f1"].append(f1_score(y_outer_test, (p >= 0.5).astype(int), zero_division=0))

    return {model: {m: (float(np.mean(v)), float(np.std(v, ddof=1))) for m, v in metrics.items()}
            for model, metrics in results.items()}


def main():
    parser = argparse.ArgumentParser(description="Primary (field) corpus pipeline (corrected)")
    parser.add_argument("--data", required=True, help="Path to the field questionnaire export (.xlsx)")
    parser.add_argument("--out", default="results/field_results.json", help="Output JSON path")
    args = parser.parse_args()

    df = load_and_prepare(args.data)
    print(f"Loaded {len(df)} records; at-risk prevalence {df['at_risk'].mean()*100:.1f}%")
    print(f"training_sessions non-response: {df['training_sessions_missing'].sum()} "
          f"({df['training_sessions_missing'].mean()*100:.1f}%)")

    print("Running Procedure A (nested repeated CV)...")
    proc_a = run_procedure_a(df)
    for model, metrics in proc_a.items():
        print(f"  {model}: AUC={metrics['auc'][0]:.4f}+/-{metrics['auc'][1]:.4f}  "
              f"F1={metrics['f1'][0]:.4f}+/-{metrics['f1'][1]:.4f}")
    print("\nFor the full diagnostic battery (matched-budget RF/LR/SVM, threshold sweep,")
    print("SMOTE x focal interaction, seed-variance decomposition, re-engineering attempts),")
    print("run full_diagnostic_battery.py instead -- see Results Section R10.")

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w") as f:
        json.dump(proc_a, f, indent=2)
    print(f"Saved summary to {args.out}")


if __name__ == "__main__":
    main()
