"""
focal_loss.py

Implements the focal-loss training objective described in Methods M12
(the single REPLACE engineering operation of this study) and Algorithm 1.

NOTE (R10, this revision): a full corrected diagnostic re-run found this
substitution does NOT produce a statistically significant AUC-ROC
improvement over a properly tuned, matched-budget baseline on either
corpus once feature-selection leakage is closed (see
src/full_diagnostic_battery.py and Results Section R10). It is retained
here as the declared engineering operation for reproducibility of that
finding, not as a claim of a validated improvement.

The standard XGBoost binary-logistic loss (Methods M11):

    L_log = -y_i * log(p_i) - (1 - y_i) * log(1 - p_i)

is substituted with a focal-loss objective (Lin et al., 2017), Methods M12:

    L_focal = -alpha * (1-p_i)^gamma * y_i * log(p_i)
              - (1-alpha) * p_i^gamma * (1-y_i) * log(1-p_i)

implemented here as a custom gradient-Hessian pair for XGBoost's native
training loop (xgb.train(obj=...)), matching Algorithm 1.
"""

import numpy as np


def sigmoid(x: np.ndarray) -> np.ndarray:
    """Numerically stable sigmoid, sigma(x) = 1 / (1 + e^-x)."""
    return 1.0 / (1.0 + np.exp(-x))


def focal_loss_obj(gamma: float = 2.0, alpha: float = 0.25):
    """
    Return a focal-loss objective function compatible with
    xgboost.train(obj=...).

    Parameters
    ----------
    gamma : float
        Focusing parameter. Independently selected per outer fold under
        the nested design (Methods M9, M13), not fixed to one global value.
    alpha : float
        Balance parameter. Independently selected per outer fold.

    Returns
    -------
    callable
        A function (y_pred, dtrain) -> (grad, hess), where y_pred are the
        raw (pre-sigmoid) margin scores XGBoost passes at each boosting
        round (Algorithm 1, line 3).
    """
    def obj(y_pred: np.ndarray, dtrain) -> tuple:
        y_true = dtrain.get_label()
        p = np.clip(sigmoid(y_pred), 1e-7, 1 - 1e-7)

        # Algorithm 1, line 4 (substituted step, REPLACE operation):
        # per-instance focal weight, higher for hard / minority-class cases.
        w = np.where(
            y_true == 1,
            alpha * (1 - p) ** gamma,
            (1 - alpha) * p ** gamma,
        )
        grad = w * (p - y_true)
        hess = w * p * (1 - p)
        return grad, hess

    return obj


def log_loss_value(y_true: np.ndarray, p: np.ndarray) -> np.ndarray:
    """Standard binary logistic loss (Methods M11), for reference."""
    p = np.clip(p, 1e-7, 1 - 1e-7)
    return -y_true * np.log(p) - (1 - y_true) * np.log(1 - p)
