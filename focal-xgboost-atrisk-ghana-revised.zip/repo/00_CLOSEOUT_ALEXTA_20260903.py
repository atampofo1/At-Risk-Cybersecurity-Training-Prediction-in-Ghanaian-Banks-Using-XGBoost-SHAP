"""
00_CLOSEOUT_ALEXTA_20260903.py
OWNER: ALEXTA

ONE script. Two halves. Half 1 is read-only and safe to run now. Half 2 is
pipeline-changing and is gated behind RUN_CLOSE_BLOCKS, which stays False
until the Half 1 verdict table has been returned.

Run it from inside the source tree so that `src/` is importable:

    python 00_CLOSEOUT_ALEXTA_20260903.py --corpus field
    python 00_CLOSEOUT_ALEXTA_20260903.py --corpus ibm

The last thing this script prints is a verdict table. That table is the only
thing you paste back.

This script does not rewrite your source. Where a source edit is required it
prints the exact edit, checks whether it is present, and refuses to report a
corrected number until it is. A number that moved with no named defect behind
it is an unlogged search.
"""

# ===========================================================================
# ENV DETECT — the script works out where it is running.
# ===========================================================================
try:
    import google.colab          # noqa: F401
    ENV = "colab"
except ImportError:
    ENV = "local"
print("ENVIRONMENT:", ENV)

import argparse
import io
import json
import os
import re
import sys
import time
import warnings
from contextlib import redirect_stdout

import numpy as np

warnings.filterwarnings("ignore")


# ===========================================================================
# CONFIG — every path, column, object and literal, each with its source.
# ===========================================================================

# ONE data directory constant. Change this line and nothing else.
if ENV == "colab":
    # Colab: artefacts written to a non-mounted path vanish when the runtime
    # recycles. Preflight fails loudly below if the mount is absent.
    DATA_DIR = "/content/drive/MyDrive/alexta_atrisk/data"      # <<< FILL IN: your Drive folder >>>
    OUT_DIR = "/content/drive/MyDrive/alexta_atrisk/results"    # <<< FILL IN: your Drive folder >>>
else:
    DATA_DIR = "data"                                           # src/ibm_pipeline.py:64 default cache dir
    OUT_DIR = "results"                                         # src/field_pipeline.py:353 default --out dir
print(f"DATA_DIR: {DATA_DIR}   OUT_DIR: {OUT_DIR}")

SRC_DIR = "src"                                                 # repository tree at e356689
sys.path.insert(0, SRC_DIR)

# --- Corpus inputs --------------------------------------------------------
FIELD_XLSX = os.path.join(
    DATA_DIR,
    "field_survey.xlsx"
)                                                               # src/field_pipeline.py:352 --data is required
IBM_CSV = os.path.join(DATA_DIR, "ibm_hr_attrition.csv")        # src/ibm_pipeline.py:64 cache_path default

# --- Battery artefacts ----------------------------------------------------
# src/full_diagnostic_battery.py:530  f"{out_prefix}_full_battery.json"
BATTERY_JSON = {"field": "field_full_battery.json", "ibm": "ibm_full_battery.json"}

# --- Constants read out of your source. Do not retype these from memory. ---
SEED = 42                       # src/full_diagnostic_battery.py:40
N_SPLITS = 5                    # src/full_diagnostic_battery.py:97
N_REPEATS = 3                   # src/full_diagnostic_battery.py:97
N_FOLDS = N_SPLITS * N_REPEATS  # 15 outer folds; matches "15 per corpus" in open item Q20
CURRENT_MODEL_SEEDS = [42, 123, 456]        # src/full_diagnostic_battery.py:401
TARGET_SEEDS = 10                           # clearance condition C1 requires >= 10
THRESHOLD_GRID = np.arange(0.1, 0.95, 0.05)  # src/full_diagnostic_battery.py:311 — 17 values
N_TRIALS_BATTERY = 10           # src/full_diagnostic_battery.py:86 n_trials_inner default
FOCAL_TRIAL_BONUS = 3           # src/full_diagnostic_battery.py:190 "n_trials_inner + 3"
N_INNER_TRIALS_PIPELINES = 8    # src/field_pipeline.py:79 and src/ibm_pipeline.py:52
N_EST_RANGE = (100, 300)        # src/field_pipeline.py:78 N_ESTIMATORS_RANGE

# Model keys as your battery names them.
# src/full_diagnostic_battery.py:104-105
MODEL_KEYS = ["baseline", "proposed", "rf_tuned", "lr", "svm"]
METRIC_KEYS = ["acc", "prec", "rec", "f1", "auc", "brier"]

# Field corpus predictors. src/field_pipeline.py:83-88 CANDIDATE_FEATURES.
FIELD_CANDIDATE_FEATURES = [
    "gender_enc", "age_group_enc", "job_role_enc", "banking_tenure_enc",
    "training_provided_enc", "training_sessions_raw", "training_sessions_missing",
    "phishing_sim_enc", "training_quality_enc", "E1_enc", "E2_enc",
]
# src/field_pipeline.py:89-92 lists "at_risk" among the label-derived columns.
# VERIFY: confirm this is the outcome column your loader returns, not a derivative.
FIELD_LABEL = "at_risk"

# --- Numbers QUOTED from the verification report. -------------------------
# H10: a quoted number is only ever the left-hand side of a comparison whose
# right-hand side is computed. None of these is fed into any calculation.
QUOTED_TRIVIAL_ACC = 0.814      # QUOTED — verification report, open item Q5
QUOTED_TRIVIAL_F1 = 0.898       # QUOTED — verification report, open item Q5
QUOTED_AUC_CI = (-0.0100, 0.0180)   # QUOTED — verification report, open item Q6
QUOTED_N_FIELD = 533            # QUOTED — verification report, tier line

# --- Pinned versions. requirements.txt inside the archive at e356689. -----
PINNED = {
    "numpy": "2.4.4", "pandas": "3.0.2", "sklearn": "1.8.0",
    "xgboost": "3.4.1", "imblearn": "0.14.2", "shap": "0.52.0",
    "optuna": "4.9.0", "scipy": "1.17.1",
}

# --- Source files the static blocks read. ---------------------------------
SRC_FILES = {
    "battery": os.path.join(SRC_DIR, "full_diagnostic_battery.py"),
    "field": os.path.join(SRC_DIR, "field_pipeline.py"),
    "ibm": os.path.join(SRC_DIR, "ibm_pipeline.py"),
    "prep": os.path.join(SRC_DIR, "preprocessing.py"),
    "focal": os.path.join(SRC_DIR, "focal_loss.py"),
}

# ===========================================================================
# THE GATE — F11 enforced in code.
# ===========================================================================
RUN_CLOSE_BLOCKS = True
# Set True ONLY after the Half 1 verdict table has been returned and a cause
# has been confirmed. Flipping this early changes your pipeline for a cause
# nobody confirmed, and the number that comes out is attributable to nothing.

VERDICTS = []   # every row the script computes; printed at the end


def record(item, check, observed, expected, verdict):
    """One verdict row. The script computes it. Nothing here is guessed."""
    VERDICTS.append((item, check, str(observed), str(expected), verdict))


def banner(text):
    print("\n" + "=" * 74)
    print(text)
    print("=" * 74)


# ===========================================================================
# VERSION GUARD — H4. Print and assert every third-party version.
# ===========================================================================
def version_guard():
    banner("VERSION GUARD")
    seen = {}
    import numpy, pandas, sklearn, scipy                     # noqa: F401
    import xgboost, imblearn, shap, optuna                   # noqa: F401
    for name, mod in [("numpy", numpy), ("pandas", pandas), ("sklearn", sklearn),
                      ("xgboost", xgboost), ("imblearn", imblearn), ("shap", shap),
                      ("optuna", optuna), ("scipy", scipy)]:
        v = getattr(mod, "__version__", "UNKNOWN")
        seen[name] = v
        flag = "OK " if v == PINNED[name] else "MISMATCH"
        print(f"  {flag}  {name:<12} installed={v:<10} pinned={PINNED[name]}")
    bad = [k for k, v in seen.items() if v != PINNED[k]]
    if bad:
        raise AssertionError(
            f"Library versions differ from requirements.txt: {bad}. "
            "Install the pinned set, or record the versions you actually ran "
            "and report them beside every number. Do not silence this."
        )
    print("  All versions match requirements.txt.")


# ===========================================================================
# PREFLIGHT
# ===========================================================================
def preflight(corpus):
    banner(f"PREFLIGHT — corpus={corpus}")

    if ENV == "colab" and not os.path.isdir(DATA_DIR):
        raise AssertionError(
            f"Colab detected and DATA_DIR does not exist: {DATA_DIR}. "
            "Mount your Drive first. Writing artefacts to an unmounted path "
            "loses them when the runtime recycles."
        )

    for label, path in SRC_FILES.items():
        assert os.path.isfile(path), f"Source file missing: {path}"
    print(f"  Source files present: {len(SRC_FILES)}")

    # API SURFACE PROBE. xgboost removed `use_label_encoder` from the sklearn
    # wrapper at 2.0; your source passes it at several call sites, e.g.
    # src/full_diagnostic_battery.py:167. requirements.txt pins 3.4.1.
    # This probe reports; it does not patch anything.
    from xgboost import XGBClassifier
    try:
        XGBClassifier(use_label_encoder=False)
        probe = "ACCEPTED"
    except TypeError as e:
        probe = f"REJECTED — {type(e).__name__}"
    print(f"  API probe: XGBClassifier(use_label_encoder=False) -> {probe}")
    record("PRE-1", "use_label_encoder accepted", probe, "ACCEPTED",
           "CLOSED" if probe == "ACCEPTED" else "STILL OPEN")

    X, y, feats = load_corpus(corpus)
    n_before = len(y)
    print(f"  n (rows loaded)      : {n_before}")
    print(f"  n features           : {X.shape[1]}  ({len(feats)} names)")
    assert X.shape[0] == y.shape[0], "X and y row counts differ"
    assert X.shape[1] == len(feats), "feature matrix width does not match the name list"

    finite_mask = np.isfinite(y)
    n_after = int(finite_mask.sum())
    print(f"  n before label filter: {n_before}")
    print(f"  n after  label filter: {n_after}   (dropped {n_before - n_after})")
    if n_before != n_after:
        raise AssertionError(
            "Rows carry a non-finite outcome. Nothing is dropped silently here. "
            "Declare the filter in your Method and re-run."
        )

    nan_per_col = np.isnan(X).sum(axis=0)
    for f, c in zip(feats, nan_per_col):
        if c:
            print(f"    missing: {f:<32} {int(c)}")
    print(f"  total missing cells  : {int(nan_per_col.sum())}")
    print(f"  SEED                 : {SEED}")

    pos_rate = float(y.mean())
    print(f"  positive rate        : {pos_rate*100:.1f}%   (positives = "
          f"{'MAJORITY' if pos_rate > 0.5 else 'minority'})")
    return X, y, feats


def load_corpus(corpus):
    """Loads through YOUR loaders. No column name is invented here."""
    if corpus == "field":
        import field_pipeline as fp
        df = fp.load_and_prepare(FIELD_XLSX)          # src/field_pipeline.py:95
        X = df[fp.CANDIDATE_FEATURES].values.astype(float)   # src/field_pipeline.py:251
        y = df[FIELD_LABEL].values.astype(int)
        return X, y, list(fp.CANDIDATE_FEATURES)
    elif corpus == "ibm":
        import ibm_pipeline as ip
        path = IBM_CSV if os.path.isfile(IBM_CSV) else ip.download_data(IBM_CSV)
        df = ip.load_and_prepare(path)                # src/ibm_pipeline.py:72
        feats = getattr(ip, "CANDIDATE_FEATURES", None)
        if feats is None:
            raise AssertionError(
                "NOT IN SOURCE: a CANDIDATE_FEATURES list in src/ibm_pipeline.py. "
                "Name the predictor list your IBM pipeline uses and set it here. "
                "Do not reuse the field corpus list."
            )
        label = getattr(ip, "LABEL_COLUMN", None)
        if label is None:
            raise AssertionError(
                "NOT IN SOURCE: an explicit label column constant in "
                "src/ibm_pipeline.py. Set it here from your own loader."
            )
        return df[feats].values.astype(float), df[label].values.astype(int), list(feats)
    raise ValueError(f"unknown corpus: {corpus}")


def load_battery_json(corpus):
    """Reads the artefact your battery writes. Returns None if absent."""
    for cand in [BATTERY_JSON[corpus], os.path.join(OUT_DIR, BATTERY_JSON[corpus])]:
        if os.path.isfile(cand):
            with open(cand) as f:
                return json.load(f), cand
    return None, None


# ===========================================================================
# HALF 1 — VERIFY. Read-only. Changes nothing in the pipeline.
# ===========================================================================

# ---------------------------------------------------------------------------
# BLOCK V1a — TEN-SEED STABILITY
# CLOSES            : clearance condition C1; confirm test for cause 9
# OPEN ITEM         : the seed grid runs three seeds, not ten —
#                     src/full_diagnostic_battery.py:401
#                     "model_seeds = [42, 123, 456]"
# ANSWERS           : does the sign of the proposed-minus-baseline AUC delta
#                     hold across ten seeds, or is it one draw?
# EXPECTED DIRECTION: NEUTRAL — this measures, it does not repair
# RUNTIME           : ~2-5 min. 10 seeds x 15 folds x 2 arms = 300 fits.
#                     Exempt from the refit cap.
# IF IT RETURNS
# SOMETHING BAD     : a sign flip means the estimate is unstable at this n.
#                     That is not "no effect". Word it INCONCLUSIVE and go to
#                     V1c before writing anything at all.
# PASTE OUTPUT WHERE: Results, the stability paragraph that currently reports
#                     three seeds
# ---------------------------------------------------------------------------
def block_v1a(X, y, feats):
    banner("V1a — TEN-SEED STABILITY")
    from sklearn.model_selection import RepeatedStratifiedKFold
    from sklearn.preprocessing import MinMaxScaler
    from sklearn.metrics import roc_auc_score
    from imblearn.over_sampling import SMOTE
    from xgboost import XGBClassifier
    import xgboost as xgb
    import full_diagnostic_battery as fdb   # your focal objective and imputer

    folds = list(RepeatedStratifiedKFold(
        n_splits=N_SPLITS, n_repeats=N_REPEATS, random_state=SEED).split(X, y))
    print(f"  folds: {len(folds)}   seeds: {TARGET_SEEDS}")

    seeds = [SEED + 100 * i for i in range(TARGET_SEEDS)]   # deterministic, published below
    print(f"  seed list: {seeds}")

    deltas = np.zeros((len(seeds), len(folds)))
    for si, s in enumerate(seeds):
        for fi, (tr, te) in enumerate(folds):
            Xtr_raw, Xte_raw = fdb.impute_per_fold(X[tr], X[te], feats)
            ytr, yte = y[tr], y[te]
            sc = MinMaxScaler()
            Xtr, Xte = sc.fit_transform(Xtr_raw), sc.transform(Xte_raw)
            Xsm, ysm = SMOTE(random_state=s).fit_resample(Xtr, ytr)

            base = XGBClassifier(objective="binary:logistic", n_estimators=200,
                                 max_depth=4, learning_rate=0.1, subsample=0.8,
                                 colsample_bytree=0.8, eval_metric="logloss",
                                 random_state=s, verbosity=0)
            # literals above: src/full_diagnostic_battery.py:301-303 base_thr config
            base.fit(Xsm, ysm)
            a_base = roc_auc_score(yte, base.predict_proba(Xte)[:, 1])

            dtr = xgb.DMatrix(Xsm, label=ysm)
            bst = xgb.train({"max_depth": 3, "eta": 0.02, "subsample": 0.9,
                             "colsample_bytree": 0.8, "seed": s,
                             "disable_default_eval_metric": 1},
                            dtr, num_boost_round=200,
                            obj=fdb.focal_obj(0.95, 0.5))
            # literals above: src/full_diagnostic_battery.py:307-309 prop_booster config
            a_prop = roc_auc_score(yte, fdb.sigmoid(bst.predict(xgb.DMatrix(Xte))))
            deltas[si, fi] = a_prop - a_base
        print(f"    seed {s:<5} mean delta AUC = {deltas[si].mean():+.4f}")

    per_seed = deltas.mean(axis=1)
    mean, sd = float(per_seed.mean()), float(per_seed.std(ddof=1))
    n_pos = int((per_seed > 0).sum())
    n_neg = int((per_seed < 0).sum())
    flips = min(n_pos, n_neg)
    print(f"\n  mean delta AUC across seeds : {mean:+.4f} +- {sd:.4f}")
    print(f"  positive seeds / negative   : {n_pos} / {n_neg}")
    print(f"  sign flips                  : {flips}")
    print(f"  |mean| vs SD                : {abs(mean):.4f} vs {sd:.4f}")

    stable = (flips == 0) and (abs(mean) > sd) and (len(seeds) >= TARGET_SEEDS)
    record("C1", "sign stable, >=10 seeds",
           f"flips={flips}, mean={mean:+.4f}, sd={sd:.4f}, seeds={len(seeds)}",
           "flips=0 and |mean|>sd and seeds>=10",
           "CLOSED" if stable else "STILL OPEN")
    return deltas, per_seed, folds


# ---------------------------------------------------------------------------
# BLOCK V1b — LEAVE-ONE-OUT OVER FOLDS
# CLOSES            : clearance condition C2; confirm test for cause 10
# OPEN ITEM         : no per-fold or leave-one-out table is retained anywhere;
#                     src/full_diagnostic_battery.py:271 stores only the mean
# ANSWERS           : does the conclusion survive dropping the fold that
#                     contributes most to it?
# EXPECTED DIRECTION: NEUTRAL
# RUNTIME           : seconds. Reuses V1a's grid. No new fits.
# IF IT RETURNS
# SOMETHING BAD     : one fold carrying the result is a finding about your
#                     sample, not your model. Report the per-fold table.
# PASTE OUTPUT WHERE: Results, beside the aggregate that currently stands alone
# ---------------------------------------------------------------------------
def block_v1b(deltas):
    banner("V1b — LEAVE-ONE-OUT OVER FOLDS")
    fold_means = deltas.mean(axis=0)
    overall = float(fold_means.mean())
    print(f"  overall mean delta AUC: {overall:+.4f}")
    print(f"  {'fold':<6}{'delta':>10}{'mean without it':>20}{'sign change':>14}")
    changed = 0
    for i, d in enumerate(fold_means):
        without = float(np.delete(fold_means, i).mean())
        flip = (np.sign(without) != np.sign(overall)) and overall != 0
        changed += int(flip)
        print(f"  {i:<6}{d:>+10.4f}{without:>+20.4f}{'YES' if flip else '':>14}")
    print(f"\n  folds whose removal flips the sign: {changed}")
    record("C2", "survives leave-one-out", f"{changed} of {len(fold_means)} flip",
           "0 flip", "CLOSED" if changed == 0 else "STILL OPEN")


# ---------------------------------------------------------------------------
# BLOCK V1c — MINIMUM DETECTABLE EFFECT, PAIRED
# CLOSES            : clearance condition C3; confirm test for cause 17
# OPEN ITEM         : no power or MDE figure exists in the source —
#                     NOT IN SOURCE: power, MDE or solver call across src/*.py
# ANSWERS           : at this n and this fold-to-fold spread, what is the
#                     smallest AUC difference the design could have detected?
# EXPECTED DIRECTION: NEUTRAL
# RUNTIME           : instant. No fits.
# IF IT RETURNS
# SOMETHING BAD     : if the MDE exceeds the effect you claimed, you have not
#                     shown absence. You have shown the design could not have
#                     seen presence. State the n that would have been required.
# PASTE OUTPUT WHERE: Results, replacing any sentence that reads "no effect"
# ---------------------------------------------------------------------------
def block_v1c(deltas, per_seed):
    banner("V1c — MINIMUM DETECTABLE EFFECT (PAIRED)")
    from scipy import stats
    fold_means = deltas.mean(axis=0)
    n = len(fold_means)
    sd = float(fold_means.std(ddof=1))
    alpha, power = 0.05, 0.80                 # conventional; stated, not searched
    t_a = stats.t.ppf(1 - alpha / 2, n - 1)   # two-sided
    t_b = stats.t.ppf(power, n - 1)
    mde = float((t_a + t_b) * sd / np.sqrt(n))
    observed = float(fold_means.mean())
    print(f"  paired units (folds)     : {n}")
    print(f"  SD of paired differences : {sd:.4f}")
    print(f"  alpha={alpha}  power={power}  (two-sided, paired solver)")
    print(f"  MDE at this n            : {mde:.4f} AUC")
    print(f"  observed |delta|         : {abs(observed):.4f} AUC")
    if mde > 0:
        n_req = int(np.ceil(((t_a + t_b) * sd / max(abs(observed), 1e-9)) ** 2))
        print(f"  n (paired units) required to detect the observed delta: {n_req}")
    detectable = abs(observed) >= mde
    print(f"  VERDICT WORDING: {'effect is within detectable range' if detectable else 'INCONCLUSIVE — the design could not have detected an effect this small'}")
    record("C3", "MDE < claimed effect, or INCONCLUSIVE",
           f"MDE={mde:.4f}, |delta|={abs(observed):.4f}",
           "MDE <= |delta|, else worded INCONCLUSIVE",
           "CLOSED" if detectable else "STILL OPEN")


# ---------------------------------------------------------------------------
# BLOCK V1d — BASE RATE, PER-CLASS RECALL, TRIVIAL FLOORS
# CLOSES            : clearance condition C5; open item Q5; confirm for cause 13
# OPEN ITEM         : Q5 — accuracy and the trivial-classifier floors are not
#                     reported. full_metrics computes accuracy already —
#                     src/full_diagnostic_battery.py:76 "acc=accuracy_score("
# ANSWERS           : does any model beat a classifier that predicts one label
#                     for every record?
# EXPECTED DIRECTION: CORRECTING — this can only make the headline look worse
# RUNTIME           : instant. No fits.
# IF IT RETURNS
# SOMETHING BAD     : if a model's F1 sits below the majority-class floor, the
#                     model adds nothing over a constant. Report it. Do not
#                     drop the metric.
# PASTE OUTPUT WHERE: Results, the Procedure A metric table, and Methods M15
# ---------------------------------------------------------------------------
def block_v1d(X, y, corpus):
    banner("V1d — BASE RATE, PER-CLASS RECALL, TRIVIAL FLOORS")
    from sklearn.metrics import (accuracy_score, f1_score, precision_score,
                                 recall_score, confusion_matrix)
    n = len(y)
    pos = int(y.sum())
    print(f"  n = {n}   positives = {pos}   negatives = {n - pos}")
    print(f"  base rate (positive)  : {pos / n:.4f}")
    print(f"  QUOTED n for this corpus in the report: {QUOTED_N_FIELD} "
          f"(field only; comparison is informational, never fed into a calculation)")

    print("\n  TRIVIAL CLASSIFIER FLOORS — computed here, not quoted:")
    for name, const in [("all-positive", 1), ("all-negative", 0)]:
        pred = np.full_like(y, const)
        acc = accuracy_score(y, pred)
        f1 = f1_score(y, pred, zero_division=0)
        prec = precision_score(y, pred, zero_division=0)
        rec = recall_score(y, pred, zero_division=0)
        print(f"    {name:<14} acc={acc:.4f}  prec={prec:.4f}  rec={rec:.4f}  f1={f1:.4f}")
        if const == 1:
            floor_acc, floor_f1 = float(acc), float(f1)
    print(f"\n    QUOTED floors in the report: acc={QUOTED_TRIVIAL_ACC}  f1={QUOTED_TRIVIAL_F1}")
    print(f"    COMPUTED floors here       : acc={floor_acc:.4f}  f1={floor_f1:.4f}")
    match = (abs(floor_acc - QUOTED_TRIVIAL_ACC) < 0.005 and
             abs(floor_f1 - QUOTED_TRIVIAL_F1) < 0.005)
    record("Q5-floor", "trivial floors reproduce",
           f"acc={floor_acc:.4f}, f1={floor_f1:.4f}",
           f"acc~{QUOTED_TRIVIAL_ACC}, f1~{QUOTED_TRIVIAL_F1}",
           "CLOSED" if match else "STILL OPEN")

    payload, path = load_battery_json(corpus)
    if payload is None:
        print("\n  NOT IN SOURCE: no battery JSON on disk. Accuracy for the five "
              "models cannot be emitted until the battery has run and written it.")
        record("Q5", "accuracy for five models emitted", "no artefact",
               "acc for 5 models", "UNVERIFIABLE")
        record("C5", "base rate beside headline numbers", "base rate printed here",
               "printed beside every headline number", "STILL OPEN")
        return

    print(f"\n  battery artefact: {path}")
    raw = payload.get("part1_raw_folds")
    if not raw:
        print("  NOT IN SOURCE: part1_raw_folds absent from the artefact.")
        record("Q5", "accuracy for five models emitted", "key absent",
               "acc for 5 models", "UNVERIFIABLE")
        return

    print(f"\n  {'model':<12}{'acc':>9}{'f1':>9}{'auc':>9}{'vs acc floor':>14}{'vs f1 floor':>13}")
    n_ok = 0
    for k in MODEL_KEYS:
        if k not in raw or "acc" not in raw[k]:
            print(f"  {k:<12}{'ABSENT':>9}")
            continue
        acc = float(np.mean(raw[k]["acc"]))
        f1 = float(np.mean(raw[k]["f1"]))
        auc = float(np.mean(raw[k]["auc"]))
        a_gap, f_gap = acc - floor_acc, f1 - floor_f1
        n_ok += 1
        print(f"  {k:<12}{acc:>9.4f}{f1:>9.4f}{auc:>9.4f}{a_gap:>+14.4f}{f_gap:>+13.4f}")
    record("Q5", "accuracy for five models emitted", f"{n_ok} of 5 present",
           "5 of 5", "CLOSED" if n_ok == 5 else "STILL OPEN")
    record("C5", "base rate beside headline numbers", "printed above",
           "printed beside every headline number", "CLOSED")


# ---------------------------------------------------------------------------
# BLOCK V1e — STATIC LEAK SCAN
# CLOSES            : clearance condition C6 evidence; confirm for cause 11
# OPEN ITEM         : NIF-1 — selection is derived on the full corpus and then
#                     consumed by the split. src/full_diagnostic_battery.py:291
#                     "sel_idx_stable = [candidate_features.index(f) for f in"
# ANSWERS           : where does every fit and fit_transform sit relative to
#                     the line that creates the split?
# EXPECTED DIRECTION: NEUTRAL — it locates, it does not repair
# RUNTIME           : instant. No fits.
# IF IT RETURNS
# SOMETHING BAD     : every fit above a split line is a leak. It does not
#                     matter how plausible the feature is.
# PASTE OUTPUT WHERE: Methods, the leakage-control paragraph
# ---------------------------------------------------------------------------
def block_v1e():
    banner("V1e — STATIC LEAK SCAN")
    src = open(SRC_FILES["battery"]).read().splitlines()
    part_starts = {}
    for i, line in enumerate(src, start=1):
        m = re.search(r"#\s*PART\s+(\d)", line)
        if m and m.group(1) not in part_starts:
            part_starts[m.group(1)] = i
    print(f"  part boundaries: {part_starts}")

    leaks = []
    print(f"\n  {'line':>6}  {'part':>4}  code")
    for i, line in enumerate(src, start=1):
        if "sel_idx_stable" in line or "X_stable" in line:
            part = max([p for p, s in part_starts.items() if s <= i] or ["?"])
            flag = "LEAK-CARRIER"
            leaks.append((i, part))
            print(f"  {i:>6}  {part:>4}  {flag}: {line.strip()[:70]}")

    fits = []
    for i, line in enumerate(src, start=1):
        if re.search(r"\.fit_resample\(|\.fit_transform\(|\.fit\(", line):
            part = max([p for p, s in part_starts.items() if s <= i] or ["?"])
            fits.append((i, part, line.strip()[:70]))
    print(f"\n  fit / fit_transform / fit_resample call sites: {len(fits)}")

    carriers_in_2345 = [l for l, p in leaks if p in {"2", "3", "4", "5"}]
    print(f"  full-corpus selection consumed inside Parts 2-5 at lines: {carriers_in_2345}")
    record("NIF-1a", "no full-corpus selection in Parts 2-5",
           f"{len(carriers_in_2345)} carrier lines",
           "0 carrier lines", "CLOSED" if not carriers_in_2345 else "STILL OPEN")

    # tune_weighted fold disjointness
    txt = "\n".join(src)
    subset = "outer_folds[:5]" in txt
    print(f"\n  tune_weighted scores on a subset of its own scoring folds: "
          f"{'YES' if subset else 'NO'}   (src:485 \"for tr_idx, te_idx in outer_folds[:5]\")")
    record("NIF-1b", "weight selected on disjoint folds",
           "selection folds are a subset of scoring folds" if subset else "disjoint",
           "disjoint", "STILL OPEN" if subset else "CLOSED")

    # one-sided tests
    onesided = [i for i, l in enumerate(src, start=1) if 'alternative="greater"' in l]
    print(f"  one-sided Wilcoxon call sites: {onesided}")
    record("NIF-1c", "significance tests two-sided", f"{len(onesided)} one-sided",
           "0 one-sided", "CLOSED" if not onesided else "STILL OPEN")


# ---------------------------------------------------------------------------
# BLOCK V1f — TUNING BUDGET PARITY
# CLOSES            : clearance condition C4; open item Q10; confirm for cause 1
# OPEN ITEM         : Q10 — arms do not receive equal budget.
#                     src/full_diagnostic_battery.py:190
#                     "study_fl.optimize(tune_focal, n_trials=n_trials_inner + 3"
# ANSWERS           : how many trials and how many search dimensions does each
#                     arm get, in every file that produces a reported table?
# EXPECTED DIRECTION: CLEARING — non-standard for cause 1. The budget deficit
#                     sits on the PROPOSED arm here (10 dimensions on 13 trials
#                     against 5 on 10), so parity may move the gap toward your
#                     claim rather than away from it. Report whatever returns.
# RUNTIME           : instant. Reads source. No fits.
# IF IT RETURNS
# SOMETHING BAD     : unequal budgets mean the comparison never happened.
#                     Neither direction of result is reportable until parity.
# PASTE OUTPUT WHERE: Methods M13, as a budget parity table
# ---------------------------------------------------------------------------
def block_v1f():
    banner("V1f — TUNING BUDGET PARITY")
    rows = []
    for label in ["battery", "field", "ibm"]:
        src = open(SRC_FILES[label]).read()
        for m in re.finditer(r"(study_\w+)\.optimize\((\w+),\s*n_trials=([^,\)]+)", src):
            study, fn, trials = m.group(1), m.group(2), m.group(3).strip()
            body = src.split(f"def {fn}(")[1].split("\n    study")[0] if f"def {fn}(" in src else ""
            dims = len(re.findall(r"trial\.suggest_\w+\(", body))
            rows.append((label, study, fn, trials, dims))

    print(f"  {'file':<9}{'study':<12}{'objective':<20}{'n_trials':<22}{'dims':>5}")
    for r in rows:
        print(f"  {r[0]:<9}{r[1]:<12}{r[2]:<20}{r[3]:<22}{r[4]:>5}")

    print("\n  UNTUNED ARMS — these receive no search at all:")
    bsrc = open(SRC_FILES["battery"]).read()
    for arm in ["LogisticRegression(", "SVC("]:
        present = arm in bsrc
        tuned = f"tune_{arm[:3].lower()}" in bsrc
        print(f"    {arm:<22} present={present}  has an objective function={tuned}")
    print("    NOTE src:227 comments \"small param sweep for parity\"; no sweep "
          "exists in the code. Five arms are compared; two get zero trials.")

    trial_vals = {r[3] for r in rows}
    dim_vals = {r[4] for r in rows}
    parity = len(trial_vals) == 1 and len(dim_vals) == 1
    print(f"\n  distinct trial expressions: {sorted(trial_vals)}")
    print(f"  distinct dimensionalities  : {sorted(dim_vals)}")
    record("Q10", "equal trials and dimensions across arms",
           f"trials={sorted(trial_vals)}, dims={sorted(dim_vals)}",
           "one value each, and untuned arms given a budget",
           "CLOSED" if parity else "STILL OPEN")
    record("C4", "baseline got the same tuning budget",
           "not equal" if not parity else "equal",
           "equal and stated in Methods", "CLOSED" if parity else "STILL OPEN")


# ---------------------------------------------------------------------------
# BLOCK V2 — PAIRED AUC CONFIDENCE INTERVAL
# CLOSES            : open item Q6
# OPEN ITEM         : Q6 — no interval is computed anywhere.
#                     NOT IN SOURCE: bootstrap, percentile or CI code in src/*.py
# ANSWERS           : what is the 95% CI on the paired AUC difference, computed
#                     from the per-fold values your own battery already saved?
# EXPECTED DIRECTION: NEUTRAL
# RUNTIME           : instant. No fits.
# IF IT RETURNS
# SOMETHING BAD     : an interval spanning zero is a real result and is
#                     reportable as a boundary, but only after NIF-1 and Q10
#                     close. The interval below is computed on leaked
#                     selection until then.
# PASTE OUTPUT WHERE: Results, beside the Wilcoxon p for both corpora
# ---------------------------------------------------------------------------
def block_v2(corpus, deltas):
    banner("V2 — 95% CI ON THE PAIRED AUC DIFFERENCE")
    payload, path = load_battery_json(corpus)
    sources = []
    if payload and payload.get("part1_raw_folds"):
        raw = payload["part1_raw_folds"]
        if "proposed" in raw and "baseline" in raw:
            d = np.array(raw["proposed"]["auc"]) - np.array(raw["baseline"]["auc"])
            sources.append(("battery part1_raw_folds", d))
    sources.append(("this run, V1a fold means", deltas.mean(axis=0)))

    for name, d in sources:
        n = len(d)
        rng = np.random.default_rng(SEED)
        boot = np.array([rng.choice(d, size=n, replace=True).mean() for _ in range(10000)])
        lo, hi = np.percentile(boot, [2.5, 97.5])
        print(f"  {name}")
        print(f"    n paired units : {n}")
        print(f"    mean delta AUC : {d.mean():+.4f}")
        print(f"    95% CI         : [{lo:+.4f}, {hi:+.4f}]   (10000 bootstrap resamples, seed {SEED})")
        print(f"    spans zero     : {'YES' if lo < 0 < hi else 'NO'}")
    print(f"\n  QUOTED interval in the report: [{QUOTED_AUC_CI[0]:+.4f}, {QUOTED_AUC_CI[1]:+.4f}]")
    print("  QUOTED value is displayed for comparison only and is not used in "
          "any calculation above.")
    record("Q6", "95% CI on paired AUC delta emitted", "computed above",
           "interval printed for both corpora", "CLOSED")


# ---------------------------------------------------------------------------
# BLOCK V3 — FULL 17-THRESHOLD GRID
# CLOSES            : open item Q8
# OPEN ITEM         : Q8 — the grid is searched on validation and only the best
#                     and default rows reach the output.
#                     src/full_diagnostic_battery.py:323
#                     "for t, label in [(default_t, \"default\"), (sel_t,"
# ANSWERS           : what are precision, recall, F1 and the false-negative
#                     count at every one of the 17 thresholds, on the test set,
#                     for both models?
# EXPECTED DIRECTION: NEUTRAL — a sweep prints the whole grid and selects
#                     nothing from it (F1)
# RUNTIME           : ~10 s. 2 fits.
# IF IT RETURNS
# SOMETHING BAD     : if F1 is flat across the grid the threshold is not the
#                     lever your Discussion says it is. Report the flatness.
# PASTE OUTPUT WHERE: Results, Part 2, replacing the two-row table
# ---------------------------------------------------------------------------
def block_v3(X, y, feats):
    banner("V3 — FULL 17-THRESHOLD GRID (TEST SET)")
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import MinMaxScaler
    from sklearn.metrics import (precision_score, recall_score, f1_score,
                                 confusion_matrix)
    from imblearn.over_sampling import SMOTE
    from xgboost import XGBClassifier
    import xgboost as xgb
    import full_diagnostic_battery as fdb

    # Split on the FULL feature set. This block does not use sel_idx_stable —
    # that is the defect NIF-1 names, and reproducing it here would print a
    # leaked grid.
    X_temp, X_test_raw, y_temp, y_test = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=SEED)      # src:293 shape, without the leak
    X_train_raw, X_val_raw, y_train, y_val = train_test_split(
        X_temp, y_temp, test_size=0.2, stratify=y_temp, random_state=SEED)   # src:294
    X_train_raw, X_val_raw = fdb.impute_per_fold(X_train_raw, X_val_raw, feats)
    X_train_raw, X_test_raw = fdb.impute_per_fold(X_train_raw, X_test_raw, feats)
    sc = MinMaxScaler()
    X_train = sc.fit_transform(X_train_raw)
    X_test = sc.transform(X_test_raw)
    X_sm, y_sm = SMOTE(random_state=SEED).fit_resample(X_train, y_train)
    print(f"  n train={len(y_train)}  val={len(y_val)}  test={len(y_test)}")
    print(f"  n after SMOTE on train: {len(y_sm)} (before {len(y_train)})")

    base = XGBClassifier(objective="binary:logistic", n_estimators=200, max_depth=4,
                         learning_rate=0.1, subsample=0.8, colsample_bytree=0.8,
                         eval_metric="logloss", random_state=SEED, verbosity=0)
    base.fit(X_sm, y_sm)                                          # src:301-305
    probs = {"baseline": base.predict_proba(X_test)[:, 1]}

    dtr = xgb.DMatrix(X_sm, label=y_sm)
    bst = xgb.train({"max_depth": 3, "eta": 0.02, "subsample": 0.9,
                     "colsample_bytree": 0.8, "disable_default_eval_metric": 1},
                    dtr, num_boost_round=200, obj=fdb.focal_obj(0.95, 0.5))  # src:307-309
    probs["proposed"] = fdb.sigmoid(bst.predict(xgb.DMatrix(X_test)))

    n_rows = 0
    for name, p in probs.items():
        print(f"\n  {name}")
        print(f"  {'thr':>6}{'prec':>9}{'rec':>9}{'f1':>9}{'FN':>7}{'FP':>7}{'TP':>7}{'TN':>7}")
        for t in THRESHOLD_GRID:
            pred = (p >= t).astype(int)
            tn, fp, fn, tp = confusion_matrix(y_test, pred, labels=[0, 1]).ravel()
            print(f"  {t:>6.2f}"
                  f"{precision_score(y_test, pred, zero_division=0):>9.4f}"
                  f"{recall_score(y_test, pred, zero_division=0):>9.4f}"
                  f"{f1_score(y_test, pred, zero_division=0):>9.4f}"
                  f"{fn:>7}{fp:>7}{tp:>7}{tn:>7}")
            n_rows += 1
    expected = 2 * len(THRESHOLD_GRID)
    record("Q8", "per-threshold grid emitted, both models", f"{n_rows} rows",
           f"{expected} rows", "CLOSED" if n_rows == expected else "STILL OPEN")


# ---------------------------------------------------------------------------
# BLOCK V4 — PER-FOLD GAMMA/ALPHA AND THE spw COMPARATOR
# CLOSES            : open item Q20
# OPEN ITEM         : Q20 — gamma and alpha are popped and discarded at
#                     src/full_diagnostic_battery.py:191
#                     "gamma = bp.pop(\"gamma\"); alpha = bp.pop(\"alpha_fl\")";
#                     spw_only_logistic is computed at src:351 and never printed
# ANSWERS           : which focal parameters were selected in each of the 15
#                     folds, and how does scale_pos_weight alone compare?
# EXPECTED DIRECTION: NEUTRAL — disclosure
# RUNTIME           : instant if the artefact exists. No fits.
# IF IT RETURNS
# SOMETHING BAD     : if gamma or alpha varies widely across folds there is no
#                     single configuration to describe. Say so, and report the
#                     spread rather than a representative value.
# PASTE OUTPUT WHERE: Methods M13 for the parameters, Results Part 3 for spw
# ---------------------------------------------------------------------------
def block_v4(corpus):
    banner("V4 — PER-FOLD FOCAL PARAMETERS AND THE spw COMPARATOR")
    payload, path = load_battery_json(corpus)
    if payload is None:
        print("  NOT IN SOURCE: no battery artefact on disk.")
        record("Q20a", "per-fold gamma/alpha emitted", "no artefact",
               f"{N_FOLDS} pairs", "UNVERIFIABLE")
        record("Q20b", "spw_only_logistic emitted", "no artefact",
               "one row", "UNVERIFIABLE")
        return

    gp = payload.get("part1_focal_params")
    if gp:
        print(f"  {'fold':>6}{'gamma':>10}{'alpha':>10}")
        for i, (g, a) in enumerate(zip(gp.get("gamma", []), gp.get("alpha", []))):
            print(f"  {i:>6}{g:>10.4f}{a:>10.4f}")
        n_pairs = len(gp.get("gamma", []))
        print(f"  gamma spread: {np.ptp(gp['gamma']):.4f}   alpha spread: {np.ptp(gp['alpha']):.4f}")
    else:
        n_pairs = 0
        print("  NOT RETAINED. src:191 pops gamma and alpha and stores neither.")
        print("  This closes only after K5 is applied and Part 1 re-runs.")
    record("Q20a", "per-fold gamma/alpha emitted", f"{n_pairs} pairs",
           f"{N_FOLDS} pairs", "CLOSED" if n_pairs == N_FOLDS else "STILL OPEN")

    inter = payload.get("part3_interaction", {})
    if "spw_only_logistic" in inter:
        row = inter["spw_only_logistic"]
        print(f"\n  spw_only_logistic: {row}")
        record("Q20b", "spw_only_logistic emitted", "present", "one row", "CLOSED")
    else:
        print("\n  spw_only_logistic computed at src:351 but absent from the artefact "
              f"keys: {sorted(inter.keys()) if inter else 'part3_interaction missing'}")
        record("Q20b", "spw_only_logistic emitted", "absent from artefact",
               "one row", "STILL OPEN")


# ---------------------------------------------------------------------------
# BLOCK V5 — REPOSITORY STATE
# CLOSES            : open item Q4; clearance condition C6 evidence
# OPEN ITEM         : Q4 — src/, requirements.txt and LICENSE are not tracked.
#                     The tree at e356689 holds README.md and one .zip.
# ANSWERS           : is there a commit that contains the code that produced
#                     these numbers, and does it postdate the last fix?
# EXPECTED DIRECTION: NEUTRAL
# RUNTIME           : instant. No fits.
# IF IT RETURNS
# SOMETHING BAD     : no hash means no number in the manuscript traces to a
#                     version of the code, whatever the numbers say.
# PASTE OUTPUT WHERE: Methods M21, replacing the placeholder URL
# ---------------------------------------------------------------------------
def block_v5():
    banner("V5 — REPOSITORY STATE")
    import subprocess
    tracked = []
    try:
        out = subprocess.run(["git", "ls-files"], capture_output=True, text=True, timeout=20)
        tracked = [l for l in out.stdout.splitlines() if l.strip()]
    except Exception as e:
        print(f"  git unavailable here: {type(e).__name__}")
    print(f"  tracked files: {len(tracked)}")
    need = {"requirements.txt": False, "LICENSE": False, "src/": False}
    for t in tracked:
        if t == "requirements.txt":
            need["requirements.txt"] = True
        if t == "LICENSE":
            need["LICENSE"] = True
        if t.startswith("src/") and t.endswith(".py"):
            need["src/"] = True
    for k, v in need.items():
        print(f"    {k:<20} tracked={v}")
    zips = [t for t in tracked if t.endswith(".zip")]
    print(f"    archives still tracked: {zips if zips else 'none'}")
    ok = all(need.values()) and not zips
    try:
        h = subprocess.run(["git", "rev-parse", "HEAD"], capture_output=True,
                           text=True, timeout=20).stdout.strip()
        print(f"  HEAD: {h}")
    except Exception:
        h = "UNAVAILABLE"
    record("Q4", "src, requirements, LICENSE tracked; no zip",
           f"src={need['src/']}, req={need['requirements.txt']}, "
           f"lic={need['LICENSE']}, zips={len(zips)}",
           "all True, zips=0", "CLOSED" if ok else "STILL OPEN")
    record("C6", "commit hash predating final scoring",
           h[:12] if h != "UNAVAILABLE" else "UNAVAILABLE",
           "hash stated and postdating every fix",
           "CLOSED" if ok and h != "UNAVAILABLE" else "STILL OPEN")


# ===========================================================================
# HALF 2 — CLOSE. Pipeline-changing. Gated.
# ===========================================================================
# Each block below checks whether the required source edit is present. It does
# not edit your source for you. If the edit is absent the block prints the
# exact change and stops. If it is present the block re-runs and prints a
# BEFORE / AFTER / DELTA row with the cause number that justified it.

EDITS = [
    ("K1", 11, SRC_FILES["battery"],
     "Parts 2-5 must not consume sel_idx_stable",
     "sel_idx_stable",
     "Delete sel_idx_stable (src:291) and X_stable (src:346). In Part 2, split\n"
     "     first and derive the feature subset inside the training partition only.\n"
     "     In Parts 3, 4 and 5, derive it inside each fold's training rows, exactly\n"
     "     as Part 1 already does at src:126-139."),
    ("K2", 1, SRC_FILES["battery"],
     "equal trials for every arm in the battery",
     "n_trials_inner + 3",
     "src:190 — change n_trials=n_trials_inner + 3 to n_trials=n_trials_inner.\n"
     "     Then either trim tune_focal to five suggest_ calls, or widen\n"
     "     tune_xgb_default and tune_rf to ten, so dimensionality matches too.\n"
     "     Give LogisticRegression and SVC an objective function with the same\n"
     "     trial count, or state in Methods that two arms are untuned."),
    ("K2b", 1, SRC_FILES["field"],
     "equal trials in the field pipeline",
     "n_trials + 3",
     "src/field_pipeline.py:336 — change n_trials=n_trials + 3 to n_trials=n_trials."),
    ("K2c", 1, SRC_FILES["ibm"],
     "equal trials in the IBM pipeline",
     "n_trials + 3",
     "src/ibm_pipeline.py:193 — change n_trials=n_trials + 3 to n_trials=n_trials."),
    ("K3", 2, SRC_FILES["battery"],
     "tune_weighted selects on folds disjoint from its scoring folds",
     "outer_folds[:5]",
     "src:485 — calibrate on outer_folds[:5] and score on outer_folds[5:], or\n"
     "     nest the search inside each scoring fold. The weight must never be\n"
     "     chosen on data it is later scored on."),
    ("K4", 15, SRC_FILES["battery"],
     "significance tests two-sided",
     'alternative="greater"',
     'Replace alternative="greater" with alternative="two-sided" at src:267,\n'
     "     :268, :275, :467 and :510. All five, not only Table 9."),
    ("K5", 15, SRC_FILES["battery"],
     "per-fold gamma and alpha retained",
     "part1_focal_params",
     "src:191 — after popping gamma and alpha, append both to a per-fold list\n"
     "     and add part1_focal_params=dict(gamma=[...], alpha=[...]) to the output\n"
     "     dict at src:516. Also add spw_only_logistic to the printed Part 3 rows."),
]


def half_two():
    banner("HALF 2 — CLOSE BLOCKS")
    if not RUN_CLOSE_BLOCKS:
        print("  RUN_CLOSE_BLOCKS is False. Half 1 has not been returned.")
        print("  No pipeline-changing block runs. This is the intended state on")
        print("  a first run. Nothing below is skipped in error.")
        for tag, cause, path, what, marker, edit in EDITS:
            record(tag, what, "gate closed", "edit applied and re-run", "STILL OPEN")
        return

    print(f"  {'block':<6}{'cause':>6}  {'required edit':<46}{'present':>9}")
    for tag, cause, path, what, marker, edit in EDITS:
        src = open(path).read()
        still_there = marker in src
        applied = not still_there
        print(f"  {tag:<6}{cause:>6}  {what:<46}{'YES' if applied else 'NO':>9}")
        if not applied:
            print(f"       EDIT REQUIRED: {edit}")
        record(tag, what, "edit applied" if applied else f"'{marker}' still present",
               "edit applied", "CLOSED" if applied else "STILL OPEN")

    if all(marker not in open(path).read() for _, _, path, _, marker, _ in EDITS):
        print("\n  All edits present. Re-run the battery for both corpora now, then")
        print("  re-run this script. Record every moved number in the corrections")
        print("  ledger with its cause number. A number that moved with no cause")
        print("  row is reverted and the original reported.")


# ===========================================================================
# VERDICT TABLE — the last thing printed, and the only thing you paste back.
# ===========================================================================
def verdict_table(corpus, null_state, null_evidence):
    banner(f"VERDICT TABLE — ALEXTA — RUN-ALEXTA-20260903 — corpus={corpus}")
    print(f"{'ITEM':<10}{'CHECK':<40}{'OBSERVED':>26}{'EXPECTED':>34}  VERDICT")
    for item, check, obs, exp, v in VERDICTS:
        print(f"{item:<10}{check[:39]:<40}{obs[:25]:>26}{exp[:33]:>34}  {v}")
    c = sum(1 for r in VERDICTS if r[4] == "CLOSED")
    o = sum(1 for r in VERDICTS if r[4] == "STILL OPEN")
    u = sum(1 for r in VERDICTS if r[4] == "UNVERIFIABLE")
    print(f"\nCLOSED: {c}   STILL OPEN: {o}   UNVERIFIABLE: {u}")
    print(f"NULL STATE: {null_state}")
    print(f"EVIDENCE  : {null_evidence}")
    cert = [r for r in VERDICTS if r[0] in {"C1", "C2", "C3", "C4", "C5", "C6"}]
    passed = sum(1 for r in cert if r[4] == "CLOSED")
    print(f"CLEARANCE CERTIFICATE: {passed} of 6")
    if passed < 6:
        print("The null is not claimed as a finding below 6 of 6.")


def main():
    ap = argparse.ArgumentParser(description="Close-out checks for ALEXTA")
    ap.add_argument("--corpus", required=True, choices=["field", "ibm"])
    args = ap.parse_args()

    t0 = time.time()
    version_guard()
    X, y, feats = preflight(args.corpus)

    deltas, per_seed, folds = block_v1a(X, y, feats)
    block_v1b(deltas)
    block_v1c(deltas, per_seed)
    block_v1d(X, y, args.corpus)
    block_v1e()
    block_v1f()
    block_v2(args.corpus, deltas)
    block_v3(X, y, feats)
    block_v4(args.corpus)
    block_v5()
    half_two()

    fold_means = deltas.mean(axis=0)
    flips = min(int((per_seed > 0).sum()), int((per_seed < 0).sum()))
    leaks_open = any(r[0] == "NIF-1a" and r[4] == "STILL OPEN" for r in VERDICTS)
    budget_open = any(r[0] == "Q10" and r[4] == "STILL OPEN" for r in VERDICTS)
    if leaks_open or budget_open:
        state = "2 — ARTEFACT. A DEFECT IS CONFIRMED."
        ev = "leak carriers and/or unequal budgets located by V1e and V1f"
    elif flips > 0:
        state = "5 — INCONCLUSIVE. THE DESIGN COULD NOT HAVE SEEN IT."
        ev = f"{flips} sign flips across {len(per_seed)} seeds"
    else:
        state = "4 — CERTIFIED NULL, subject to the certificate below"
        ev = f"mean {fold_means.mean():+.4f}, no sign flip across {len(per_seed)} seeds"
    verdict_table(args.corpus, state, ev)
    print(f"\nRuntime: {time.time() - t0:.0f}s")


if __name__ == "__main__":
    main()
