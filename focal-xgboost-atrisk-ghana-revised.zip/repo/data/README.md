# Data
Field corpus is restricted (Methods M5/M21); IBM auto-downloads. See repo README.
