# Results
Battery JSON outputs land here at runtime; excluded from version control.
