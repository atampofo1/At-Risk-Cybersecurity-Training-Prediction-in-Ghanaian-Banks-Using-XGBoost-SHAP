"""
preprocessing.py

Shared utilities used identically by field_pipeline.py and ibm_pipeline.py
(CROSS-DATASET strategy, Methods M10). impute_per_fold closes the Q11 /
NIF-1 leakage pattern: any NaN feature is median-imputed on the training
portion of each fold only.
"""

import numpy as np
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import RepeatedStratifiedKFold, train_test_split
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, brier_score_loss,
)
from imblearn.over_sampling import SMOTE

SEED = 42
np.random.seed(SEED)


def full_metrics(y_true, y_pred, y_prob) -> dict:
    return dict(
        acc=accuracy_score(y_true, y_pred),
        prec=precision_score(y_true, y_pred, zero_division=0),
        rec=recall_score(y_true, y_pred, zero_division=0),
        f1=f1_score(y_true, y_pred, zero_division=0),
        auc=roc_auc_score(y_true, y_prob),
        brier=brier_score_loss(y_true, y_prob),
    )


def impute_per_fold(X_train_raw, X_test_raw, feature_names):
    """Median-impute NaN features using training-portion statistics only
    (Methods M6, M9; closes Q11). Applied unchanged to the test portion."""
    X_train = X_train_raw.copy()
    X_test = X_test_raw.copy()
    for j in range(len(feature_names)):
        if np.isnan(X_train[:, j]).any():
            med = np.nanmedian(X_train[:, j])
            X_train[np.isnan(X_train[:, j]), j] = med
            X_test[np.isnan(X_test[:, j]), j] = med
    return X_train, X_test


def procedure_a_folds(X, y, n_splits=5, n_repeats=3, seed=SEED):
    """Procedure A outer folds (Methods M9)."""
    return list(RepeatedStratifiedKFold(
        n_splits=n_splits, n_repeats=n_repeats, random_state=seed
    ).split(X, y))


def procedure_b_split(X, y, test_size=0.2, seed=SEED):
    """Procedure B single split (Methods M9); diagnostics only."""
    X_train_raw, X_test_raw, y_train, y_test = train_test_split(
        X, y, test_size=test_size, stratify=y, random_state=seed
    )
    X_train_raw, X_test_raw = impute_per_fold(
        X_train_raw, X_test_raw, list(range(X.shape[1]))
    )
    scaler = MinMaxScaler()
    X_train = scaler.fit_transform(X_train_raw)
    X_test = scaler.transform(X_test_raw)
    X_train_sm, y_train_sm = SMOTE(random_state=seed).fit_resample(X_train, y_train)
    return X_train_sm, y_train_sm, X_test, y_test, scaler


def leakage_audit(feature_cols, label_derived_cols):
    leaks = [f for f in feature_cols if f in label_derived_cols]
    if leaks:
        raise ValueError(f"LEAKAGE DETECTED — label-derived features in predictors: {leaks}")
