"""
field_pipeline.py — Primary corpus (FIELD), Methods M10.

Fixes the training-session data-quality bug (Methods M6): 33.2% of B2
responses were non-responses with no genuine "zero" category; they are no
longer coded as 0. Split into a genuine-response ordinal (NaN where absent,
imputed per-fold) + an explicit missingness indicator.

Runs the full corrected diagnostic battery via full_diagnostic_battery.py.
Usage: python src/field_pipeline.py --data data/field_survey.xlsx
"""

import argparse
import warnings
import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder

from preprocessing import leakage_audit
from full_diagnostic_battery import run_battery

warnings.filterwarnings("ignore")

CANDIDATE_FEATURES = [
    "gender_enc", "age_group_enc", "job_role_enc", "banking_tenure_enc",
    "training_provided_enc", "training_sessions_raw", "training_sessions_missing",
    "phishing_sim_enc", "training_quality_enc", "E1_enc", "E2_enc",
]
LABEL_COLUMN = "at_risk"
LABEL_DERIVED_COLUMNS = [
    "C1_score", "C2_score", "C3_score", "C4_score", "C_total", "C_pct",
    "D1_num", "D2_num", "D3_num", "D4_num", "D5_num", "D_total", "at_risk",
]


def load_and_prepare(path: str) -> pd.DataFrame:
    df_raw = pd.read_excel(path)
    rename = {}
    for c in df_raw.columns:
        for prefix, name in [
            ("A1", "gender"), ("A2", "age_group"), ("A3", "job_role"),
            ("A4", "banking_tenure"), ("B1", "training_provided"),
            ("B2", "training_sessions"), ("B3", "phishing_sim"),
            ("B4", "training_quality"), ("C1", "C1"), ("C2", "C2"),
            ("C3", "C3"), ("C4", "C4"), ("D1", "D1"), ("D2", "D2"),
            ("D3", "D3"), ("D4", "D4"), ("D5", "D5"),
            ("E1", "E1_topic"), ("E2", "E2_format"),
        ]:
            if c.startswith(prefix):
                rename[c] = name
                break
    df = df_raw.rename(columns=rename)

    correct = {
        "C1": "Phishing email",
        "C2": "Verify with the IT department through a separate, trusted channel before clicking",
        "C3": "Using a unique password of 12+ characters combining letters, numbers, and symbols",
        "C4": "Report it to IT security without plugging it in",
    }
    for col, ans in correct.items():
        df[f"{col}_score"] = df[col].apply(
            lambda x, a=ans: 1 if isinstance(x, str) and a.lower() in x.lower() else 0)
    df["C_total"] = df[["C1_score", "C2_score", "C3_score", "C4_score"]].sum(axis=1)
    df["C_pct"] = df["C_total"] / 4

    def parse_likert(v):
        if pd.isna(v):
            return np.nan
        v = str(v).strip()
        if "," in v:
            v = v.split(",")[0].strip()
        for part in v.split("."):
            try:
                n = int(part.strip())
                if 1 <= n <= 5:
                    return n
            except ValueError:
                pass
        try:
            return int(v)
        except ValueError:
            return np.nan

    for col in ["D1", "D2", "D3", "D4", "D5"]:
        df[f"{col}_num"] = df[col].apply(parse_likert)
    d_num = [f"{c}_num" for c in ["D1", "D2", "D3", "D4", "D5"]]
    for col in d_num:
        df[col] = df[col].fillna(df[col].median())
    df["D_total"] = df[d_num].sum(axis=1)
    df["at_risk"] = ((df["C_pct"] < 0.60) | (df["D_total"] < 15)).astype(int)

    df["gender_enc"] = df["gender"].map({"Male": 1, "Female": 0}).fillna(0).astype(int)
    df["age_group_enc"] = df["age_group"].map({
        "18–25 years": 1, "26–35 years": 2, "36–45 years": 3,
        "46–55 years": 4, "56 years and above": 5}).fillna(0).astype(int)
    df["banking_tenure_enc"] = df["banking_tenure"].map({
        "Less than 1 year": 0, "1–3 years": 1, "4–7 years": 2,
        "8–12 years": 3, "More than 12 years": 4}).fillna(0).astype(int)
    df["training_provided_enc"] = df["training_provided"].map(
        {"Yes": 2, "I am not aware": 1, "No": 0}).fillna(0).astype(int)

    # CORRECTED training_sessions: genuine responses only (NaN where absent),
    # plus explicit missingness indicator. Never coded to zero. (Methods M6)
    ts_map = {"1 session": 1, "2–3 sessions": 2, "4–5 sessions": 3, "More than 5 sessions": 4}
    df["training_sessions_raw"] = df["training_sessions"].map(ts_map)
    df["training_sessions_missing"] = df["training_sessions"].isna().astype(int)

    df["phishing_sim_enc"] = df["phishing_sim"].map({
        "Yes — and I identified the phishing attempt correctly": 2,
        "Yes — but I did not identify the phishing attempt": 1,
        "No — my bank has not conducted phishing simulations": 0,
        "I do not know what a phishing simulation is": 0}).fillna(0).astype(int)
    df["training_quality_enc"] = df["training_quality"].map({
        "I have not received training": 0, "Very poor": 1, "Poor": 2,
        "Average": 3, "Good": 4, "Excellent": 5}).fillna(0).astype(int)

    def map_job_role(role):
        if pd.isna(role):
            return "Other"
        role = str(role).strip()
        mapping = {"Teller": "Teller", "IT": "IT", "Technology": "IT", "Cybersecurity": "IT",
                   "Operations": "Operations", "Finance": "Finance", "Accounts": "Finance",
                   "Management": "Management", "Senior Leadership": "Management",
                   "Compliance": "Compliance", "Risk": "Compliance", "Legal": "Compliance",
                   "Human Resources": "HR", "Audit": "Audit", "Credit": "Credit", "Mobile": "IT"}
        for k, v in mapping.items():
            if k.lower() in role.lower():
                return v
        return "Other"

    df["job_role_enc"] = LabelEncoder().fit_transform(df["job_role"].apply(map_job_role))
    df["E1_enc"] = LabelEncoder().fit_transform(df["E1_topic"].fillna("Unknown").apply(
        lambda x: x.split(",")[0].strip() if isinstance(x, str) else "Unknown"))
    df["E2_enc"] = LabelEncoder().fit_transform(df["E2_format"].fillna("Unknown").apply(
        lambda x: x.split(",")[0].strip() if isinstance(x, str) else "Unknown"))

    leakage_audit(CANDIDATE_FEATURES, LABEL_DERIVED_COLUMNS)
    return df


def main():
    ap = argparse.ArgumentParser(description="Primary (field) corpus pipeline (corrected)")
    ap.add_argument("--data", required=True)
    ap.add_argument("--out-prefix", default="field")
    ap.add_argument("--trials", type=int, default=8)
    args = ap.parse_args()

    df = load_and_prepare(args.data)
    print(f"Loaded {len(df)} records; at-risk {df['at_risk'].mean()*100:.1f}%; "
          f"training_sessions non-response {df['training_sessions_missing'].sum()} "
          f"({df['training_sessions_missing'].mean()*100:.1f}%)")
    X = df[CANDIDATE_FEATURES].values.astype(float)
    y = df[LABEL_COLUMN].values
    run_battery(X, y, CANDIDATE_FEATURES, "FIELD (Ghana Banking Survey)",
                n_trials_inner=args.trials, out_prefix=args.out_prefix)


if __name__ == "__main__":
    main()
