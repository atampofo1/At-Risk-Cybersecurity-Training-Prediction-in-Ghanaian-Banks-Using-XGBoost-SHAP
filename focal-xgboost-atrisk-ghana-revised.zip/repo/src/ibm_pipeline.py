"""
ibm_pipeline.py — Validation corpus (PUBLIC, IBM HR Attrition), Methods M10.

Zero missing values on audit (Results R10), so no training_sessions-style
correction applies here. Runs the full corrected diagnostic battery.
Usage: python src/ibm_pipeline.py    (auto-downloads the public dataset)
"""

import argparse
import os
import urllib.request
import warnings
import pandas as pd
from sklearn.preprocessing import LabelEncoder

from full_diagnostic_battery import run_battery

warnings.filterwarnings("ignore")

IBM_URL = ("https://github.com/nelson-wu/employee-attrition-ml/raw/refs/heads/master/"
           "WA_Fn-UseC_-HR-Employee-Attrition.csv")

FEATURES = ["age", "tenure", "total_years", "job_role", "job_level", "job_involve",
            "job_sat", "env_sat", "income", "overtime", "stock", "wlb", "distance",
            "training", "num_comp", "promo"]
# Aliases so external tooling can address either pipeline identically.
CANDIDATE_FEATURES = FEATURES
LABEL_COLUMN = "at_risk"


def download_data(cache="data/ibm_hr_attrition.csv") -> str:
    os.makedirs(os.path.dirname(cache), exist_ok=True)
    if not os.path.exists(cache):
        urllib.request.urlretrieve(IBM_URL, cache)
    return cache


def load_and_prepare(path: str) -> pd.DataFrame:
    ibm = pd.read_csv(path)
    ibm["at_risk"] = (ibm["Attrition"].astype(str).str.strip() == "Yes").astype(int)
    f = pd.DataFrame(index=ibm.index)
    f["age"] = ibm["Age"]; f["tenure"] = ibm["YearsAtCompany"]; f["total_years"] = ibm["TotalWorkingYears"]
    f["job_role"] = LabelEncoder().fit_transform(ibm["JobRole"]); f["job_level"] = ibm["JobLevel"]
    f["job_involve"] = ibm["JobInvolvement"]; f["job_sat"] = ibm["JobSatisfaction"]
    f["env_sat"] = ibm["EnvironmentSatisfaction"]; f["income"] = ibm["MonthlyIncome"]
    f["overtime"] = (ibm["OverTime"] == "Yes").astype(int); f["stock"] = ibm["StockOptionLevel"]
    f["wlb"] = ibm["WorkLifeBalance"]; f["distance"] = ibm["DistanceFromHome"]
    f["training"] = ibm["TrainingTimesLastYear"]; f["num_comp"] = ibm["NumCompaniesWorked"]
    f["promo"] = ibm["YearsSinceLastPromotion"]; f["at_risk"] = ibm["at_risk"].values
    assert f.isna().sum().sum() == 0, "Unexpected missing values in IBM corpus"
    return f


def main():
    ap = argparse.ArgumentParser(description="Validation (IBM HR) corpus pipeline")
    ap.add_argument("--data", default=None)
    ap.add_argument("--out-prefix", default="ibm")
    ap.add_argument("--trials", type=int, default=8)
    args = ap.parse_args()
    path = args.data or download_data()
    df = load_and_prepare(path)
    print(f"Loaded {len(df)} records; attrition {df['at_risk'].mean()*100:.1f}%")
    X = df[FEATURES].values.astype(float)
    y = df[LABEL_COLUMN].values
    run_battery(X, y, FEATURES, "IBM HR Analytics (Validation Corpus)",
                n_trials_inner=args.trials, out_prefix=args.out_prefix)


if __name__ == "__main__":
    main()
