"""
focal_loss.py

Focal-loss training objective (Methods M12 REPLACE operation, Algorithm 1).

NOTE (Results R10): once feature-selection leakage is closed and comparators
receive a matched tuning budget, this substitution does NOT produce a
statistically significant improvement over baseline on either corpus. It is
retained here for reproducibility of that finding, not as a validated gain.

Baseline (Methods M11):   L_log = -y*log(p) - (1-y)*log(1-p)
Proposed (Methods M12):   L_focal = -alpha*(1-p)^gamma*y*log(p)
                                    -(1-alpha)*p^gamma*(1-y)*log(1-p)
"""

import numpy as np


def sigmoid(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-x))


def focal_loss_obj(gamma: float = 2.0, alpha: float = 0.25):
    """Custom focal-loss objective for xgb.train(obj=...). gamma and alpha are
    selected independently per outer fold under the nested design (M9, M13)."""
    def obj(y_pred: np.ndarray, dtrain):
        y_true = dtrain.get_label()
        p = np.clip(sigmoid(y_pred), 1e-7, 1 - 1e-7)
        w = np.where(y_true == 1, alpha * (1 - p) ** gamma, (1 - alpha) * p ** gamma)
        grad = w * (p - y_true)
        hess = w * p * (1 - p)
        return grad, hess
    return obj


def log_loss_value(y_true: np.ndarray, p: np.ndarray) -> np.ndarray:
    p = np.clip(p, 1e-7, 1 - 1e-7)
    return -y_true * np.log(p) - (1 - y_true) * np.log(1 - p)
