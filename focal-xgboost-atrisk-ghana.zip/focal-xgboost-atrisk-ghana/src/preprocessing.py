"""
preprocessing.py

Shared preprocessing utilities used identically by field_pipeline.py and
ibm_pipeline.py, per Methods M6-M9 and M10 (CROSS-DATASET strategy: the
identical pipeline logic is applied independently to each corpus; no data,
fitted transform, or trained weight is ever shared between corpora).
"""

import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import RepeatedStratifiedKFold, train_test_split
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, brier_score_loss,
)
from imblearn.over_sampling import SMOTE

SEED = 42
np.random.seed(SEED)


def full_metrics(y_true, y_pred, y_prob) -> dict:
    """Six metrics reported per Methods M15."""
    return dict(
        acc=accuracy_score(y_true, y_pred),
        prec=precision_score(y_true, y_pred, zero_division=0),
        rec=recall_score(y_true, y_pred, zero_division=0),
        f1=f1_score(y_true, y_pred, zero_division=0),
        auc=roc_auc_score(y_true, y_prob),
        brier=brier_score_loss(y_true, y_prob),
    )


def procedure_a_folds(X: np.ndarray, y: np.ndarray, n_splits=5, n_repeats=3, seed=SEED):
    """
    Procedure A (Methods M9): repeated stratified k-fold cross-validation
    applied directly to the full corpus. Produces the headline mean +/- SD
    results (Results Tables 4, 5, 7). Each fold's scaler and oversampler
    are fit on that fold's training portion only (Methods M6, M8).
    """
    return list(RepeatedStratifiedKFold(
        n_splits=n_splits, n_repeats=n_repeats, random_state=seed
    ).split(X, y))


def procedure_a_fit_fold(X_train_raw, X_test_raw, y_train_raw):
    """
    Fit the scaler and SMOTE oversampler on one Procedure A fold's
    training portion only, and apply the fitted scaler unchanged to the
    test portion (Methods M6, M8 -- leakage-free by construction).
    """
    scaler = MinMaxScaler()
    X_train = scaler.fit_transform(X_train_raw)
    X_test = scaler.transform(X_test_raw)
    X_train_sm, y_train_sm = SMOTE(random_state=SEED).fit_resample(X_train, y_train_raw)
    return X_train_sm, y_train_sm, X_test, scaler


def procedure_b_split(X: np.ndarray, y: np.ndarray, test_size=0.2, seed=SEED):
    """
    Procedure B (Methods M9): a single stratified train:test split drawn
    once, independently of Procedure A. Used only to produce the
    single-model illustrative diagnostics (Results Figure 4, Figure 6,
    Figure 7, Table 6). Never used to compute the Procedure A headline
    metrics.
    """
    X_train_raw, X_test_raw, y_train, y_test = train_test_split(
        X, y, test_size=test_size, stratify=y, random_state=seed
    )
    scaler = MinMaxScaler()
    X_train = scaler.fit_transform(X_train_raw)
    X_test = scaler.transform(X_test_raw)
    X_train_sm, y_train_sm = SMOTE(random_state=seed).fit_resample(X_train, y_train)
    return X_train_sm, y_train_sm, X_test, y_test, scaler


def leakage_audit(feature_cols: list, label_derived_cols: list) -> None:
    """
    Programmatic leakage audit (Methods M7): raises if any column used to
    construct the target label has leaked into the predictor set.
    """
    leaks = [f for f in feature_cols if f in label_derived_cols]
    if leaks:
        raise ValueError(f"LEAKAGE DETECTED — label-derived features in predictors: {leaks}")
