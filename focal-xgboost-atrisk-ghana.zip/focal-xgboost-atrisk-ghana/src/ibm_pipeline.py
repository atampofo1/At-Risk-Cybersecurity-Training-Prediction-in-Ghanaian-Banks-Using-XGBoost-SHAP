"""
ibm_pipeline.py

Validation corpus (PUBLIC) pipeline, referenced by name in Methods M10.

Runs both evaluation procedures declared in Methods M9 on the public
IBM HR Analytics Employee Attrition dataset (IBM, 2017; n = 1,470),
independently of field_pipeline.py -- per the CROSS-DATASET strategy
(Methods M10), no row, feature value, or fitted transformation is ever
shared between the two corpora, and no trained model weight is
transferred between them.

Usage
-----
    python src/ibm_pipeline.py

The dataset is downloaded automatically from its public mirror; no
manual download or ethical clearance is required (Methods M4, M5).
"""

import argparse
import json
import os
import urllib.request
import warnings

import numpy as np
import pandas as pd
import shap
import xgboost as xgb
from sklearn.preprocessing import LabelEncoder
from xgboost import XGBClassifier

from focal_loss import focal_loss_obj, sigmoid
from preprocessing import (
    SEED, full_metrics, procedure_a_folds, procedure_a_fit_fold, procedure_b_split,
)

warnings.filterwarnings("ignore")
np.random.seed(SEED)

IBM_URL = (
    "https://github.com/nelson-wu/employee-attrition-ml/raw/refs/heads/master/"
    "WA_Fn-UseC_-HR-Employee-Attrition.csv"
)

# Proposed model configuration (Methods M13): the specific hyperparameter
# values selected by the Optuna search for the validation corpus.
IBM_CFG = {
    "params": {
        "max_depth": 3, "eta": 0.0189, "subsample": 0.9341,
        "colsample_bytree": 0.6812, "reg_alpha": 0.2889, "reg_lambda": 1.4859,
        "min_child_weight": 3, "n_estimators": 446,
    },
    "gamma": 1.0025,
    "alpha": 0.4443,
}

# All sixteen native employee-record columns are retained directly as
# predictors (Methods M7); no SHAP-based reduction was applied to this
# corpus, since its smaller native schema did not require pruning.
FEATURES = [
    "age", "tenure", "total_years", "job_role", "job_level", "job_involve",
    "job_sat", "env_sat", "income", "overtime", "stock", "wlb", "distance",
    "training", "num_comp", "promo",
]


def download_data(cache_path: str = "data/ibm_hr_attrition.csv") -> str:
    """Download the public IBM HR dataset if not already cached locally."""
    os.makedirs(os.path.dirname(cache_path), exist_ok=True)
    if not os.path.exists(cache_path):
        urllib.request.urlretrieve(IBM_URL, cache_path)
    return cache_path


def load_and_prepare(path: str) -> pd.DataFrame:
    """Load the IBM HR CSV, in its released, unmodified form (Methods M4),
    and encode the sixteen native predictors."""
    ibm = pd.read_csv(path)
    ibm["at_risk"] = (ibm["Attrition"].astype(str).str.strip() == "Yes").astype(int)

    feat = pd.DataFrame(index=ibm.index)
    feat["age"] = ibm["Age"]
    feat["tenure"] = ibm["YearsAtCompany"]
    feat["total_years"] = ibm["TotalWorkingYears"]
    feat["job_role"] = LabelEncoder().fit_transform(ibm["JobRole"])
    feat["job_level"] = ibm["JobLevel"]
    feat["job_involve"] = ibm["JobInvolvement"]
    feat["job_sat"] = ibm["JobSatisfaction"]
    feat["env_sat"] = ibm["EnvironmentSatisfaction"]
    feat["income"] = ibm["MonthlyIncome"]
    feat["overtime"] = (ibm["OverTime"] == "Yes").astype(int)
    feat["stock"] = ibm["StockOptionLevel"]
    feat["wlb"] = ibm["WorkLifeBalance"]
    feat["distance"] = ibm["DistanceFromHome"]
    feat["training"] = ibm["TrainingTimesLastYear"]
    feat["num_comp"] = ibm["NumCompaniesWorked"]
    feat["promo"] = ibm["YearsSinceLastPromotion"]
    feat["at_risk"] = ibm["at_risk"].values
    return feat


def run_procedure_a(df: pd.DataFrame) -> dict:
    """Procedure A: repeated CV headline metrics (Methods M9, M11;
    Results Tables 4, 7)."""
    X = df[FEATURES].values.astype(float)
    y = df["at_risk"].values
    folds = procedure_a_folds(X, y)

    bp, gamma, alpha = IBM_CFG["params"], IBM_CFG["gamma"], IBM_CFG["alpha"]
    results = {k: {m: [] for m in ["acc", "prec", "rec", "f1", "auc", "brier"]}
               for k in ["baseline", "proposed"]}

    for train_idx, test_idx in folds:
        X_train_sm, y_train_sm, X_test, _ = procedure_a_fit_fold(
            X[train_idx], X[test_idx], y[train_idx]
        )
        y_test = y[test_idx]

        base_model = XGBClassifier(
            objective="binary:logistic", n_estimators=200, max_depth=4,
            learning_rate=0.1, subsample=0.8, colsample_bytree=0.8,
            use_label_encoder=False, eval_metric="logloss",
            random_state=SEED, verbosity=0,
        )
        base_model.fit(X_train_sm, y_train_sm)
        p = base_model.predict_proba(X_test)[:, 1]
        pr = (p >= 0.5).astype(int)
        for k, v in full_metrics(y_test, pr, p).items():
            results["baseline"][k].append(v)

        dtr = xgb.DMatrix(X_train_sm, label=y_train_sm)
        dte = xgb.DMatrix(X_test)
        booster = xgb.train(
            {**bp, "disable_default_eval_metric": 1}, dtr,
            num_boost_round=bp["n_estimators"], obj=focal_loss_obj(gamma, alpha),
        )
        p = sigmoid(booster.predict(dte))
        pr = (p >= 0.5).astype(int)
        for k, v in full_metrics(y_test, pr, p).items():
            results["proposed"][k].append(v)

    return {model: {m: (float(np.mean(v)), float(np.std(v, ddof=1))) for m, v in metrics.items()}
            for model, metrics in results.items()}


def run_procedure_b(df: pd.DataFrame) -> dict:
    """Procedure B: single-split illustrative diagnostics for the
    validation corpus (Methods M9)."""
    X = df[FEATURES].values.astype(float)
    y = df["at_risk"].values
    X_train_sm, y_train_sm, X_test, y_test, _ = procedure_b_split(X, y)

    bp, gamma, alpha = IBM_CFG["params"], IBM_CFG["gamma"], IBM_CFG["alpha"]
    dtr = xgb.DMatrix(X_train_sm, label=y_train_sm)
    dte = xgb.DMatrix(X_test)
    booster = xgb.train(
        {**bp, "disable_default_eval_metric": 1}, dtr,
        num_boost_round=bp["n_estimators"], obj=focal_loss_obj(gamma, alpha),
    )
    prob = sigmoid(booster.predict(dte))
    pred = (prob >= 0.5).astype(int)

    explainer = shap.TreeExplainer(booster)
    shap_vals = explainer.shap_values(X_test)

    return {
        "y_test": y_test, "y_pred": pred, "y_prob": prob,
        "shap_values": shap_vals, "X_test": X_test,
        "n_test": len(y_test),
    }


def main():
    parser = argparse.ArgumentParser(description="Validation (IBM HR) corpus pipeline")
    parser.add_argument("--data", default=None, help="Path to a local copy of the IBM HR CSV (optional; auto-downloads if omitted)")
    parser.add_argument("--out", default="results/ibm_results.json", help="Output JSON path")
    args = parser.parse_args()

    path = args.data or download_data()
    df = load_and_prepare(path)
    print(f"Loaded {len(df)} records; attrition prevalence {df['at_risk'].mean()*100:.1f}%")

    print("Running Procedure A (repeated CV)...")
    proc_a = run_procedure_a(df)
    for model, metrics in proc_a.items():
        print(f"  {model}: AUC={metrics['auc'][0]:.4f}+/-{metrics['auc'][1]:.4f}  "
              f"F1={metrics['f1'][0]:.4f}+/-{metrics['f1'][1]:.4f}")

    print("Running Procedure B (single split diagnostics)...")
    proc_b = run_procedure_b(df)
    print(f"  Procedure B test set size: {proc_b['n_test']}")

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w") as f:
        json.dump({
            "procedure_a": proc_a,
            "procedure_b_n_test": proc_b["n_test"],
        }, f, indent=2)
    print(f"Saved summary to {args.out}")


if __name__ == "__main__":
    main()
