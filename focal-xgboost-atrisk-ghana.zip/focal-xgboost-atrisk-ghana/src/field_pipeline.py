"""
field_pipeline.py

Primary corpus (FIELD) pipeline, referenced by name in Methods M10.

Runs both evaluation procedures declared in Methods M9 on the primary
field corpus (Ghana Banking Cybersecurity Survey, n = 533):

  Procedure A - repeated stratified 5-fold CV, 3 repeats (15 folds total).
                Produces the headline mean +/- SD results (Results
                Tables 4, 5, 7).
  Procedure B - a single stratified 80:20 train:test split, drawn once,
                independently of Procedure A. Produces the illustrative
                diagnostics (Results Figure 4, Figure 6, Figure 7, Table 6).

Usage
-----
    python src/field_pipeline.py --data path/to/field_survey.xlsx

The raw field dataset is not distributed with this repository (Methods
M5, M21); provide your own de-identified copy locally to reproduce the
primary-corpus results. See data/README.md.
"""

import argparse
import json
import warnings

import numpy as np
import pandas as pd
import shap
import xgboost as xgb
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_selection import RFE
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.metrics import f1_score, roc_auc_score
from xgboost import XGBClassifier

from focal_loss import focal_loss_obj, sigmoid
from preprocessing import (
    SEED, full_metrics, leakage_audit,
    procedure_a_folds, procedure_a_fit_fold, procedure_b_split,
)

warnings.filterwarnings("ignore")
np.random.seed(SEED)

# ---------------------------------------------------------------------------
# Proposed model configuration (Methods M13): the specific hyperparameter
# values selected by the Optuna search for the primary corpus.
# ---------------------------------------------------------------------------
FIELD_CFG = {
    "params": {
        "max_depth": 3, "eta": 0.01024, "subsample": 0.9095,
        "colsample_bytree": 0.8064, "reg_alpha": 1.7993, "reg_lambda": 2.6174,
        "min_child_weight": 2, "n_estimators": 234,
    },
    "gamma": 0.9555,
    "alpha": 0.5256,
}

# Ten raw candidate predictors (Methods M7). Label-derived columns
# (knowledge-assessment and self-assessment item scores) are excluded by
# construction and verified absent via leakage_audit().
CANDIDATE_FEATURES = [
    "gender_enc", "age_group_enc", "job_role_enc", "banking_tenure_enc",
    "training_provided_enc", "training_sessions_enc", "phishing_sim_enc",
    "training_quality_enc", "E1_enc", "E2_enc",
]

# Eight predictors retained after SHAP ranking + RFE (Methods M7),
# reported with descriptive statistics in Table 1.
SELECTED_FEATURES = [
    "age_group_enc", "job_role_enc", "banking_tenure_enc",
    "training_sessions_enc", "phishing_sim_enc", "training_quality_enc",
    "E1_enc", "E2_enc",
]

LABEL_DERIVED_COLUMNS = [
    "C1_score", "C2_score", "C3_score", "C4_score", "C_total", "C_pct",
    "D1_num", "D2_num", "D3_num", "D4_num", "D5_num", "D_total", "at_risk",
]


def load_and_prepare(path: str) -> pd.DataFrame:
    """Load the raw questionnaire export and construct the at-risk label
    and encoded predictors (Methods M6, M7, M8)."""
    df_raw = pd.read_excel(path)

    rename = {}
    for c in df_raw.columns:
        for prefix, name in [
            ("A1", "gender"), ("A2", "age_group"), ("A3", "job_role"),
            ("A4", "banking_tenure"), ("B1", "training_provided"),
            ("B2", "training_sessions"), ("B3", "phishing_sim"),
            ("B4", "training_quality"), ("C1", "C1"), ("C2", "C2"),
            ("C3", "C3"), ("C4", "C4"), ("D1", "D1"), ("D2", "D2"),
            ("D3", "D3"), ("D4", "D4"), ("D5", "D5"),
            ("E1", "E1_topic"), ("E2", "E2_format"),
        ]:
            if c.startswith(prefix):
                rename[c] = name
                break
    df = df_raw.rename(columns=rename)

    # Knowledge-assessment scoring (Section C) — used ONLY to build the label.
    correct = {
        "C1": "Phishing email",
        "C2": "Verify with the IT department through a separate, trusted channel before clicking",
        "C3": "Using a unique password of 12+ characters combining letters, numbers, and symbols",
        "C4": "Report it to IT security without plugging it in",
    }
    for col, ans in correct.items():
        df[f"{col}_score"] = df[col].apply(
            lambda x, a=ans: 1 if isinstance(x, str) and a.lower() in x.lower() else 0
        )
    df["C_total"] = df[["C1_score", "C2_score", "C3_score", "C4_score"]].sum(axis=1)
    df["C_pct"] = df["C_total"] / 4

    # Self-assessment scoring (Section D) — used ONLY to build the label.
    def parse_likert(v):
        if pd.isna(v):
            return np.nan
        v = str(v).strip()
        if "," in v:
            v = v.split(",")[0].strip()
        for part in v.split("."):
            try:
                n = int(part.strip())
                if 1 <= n <= 5:
                    return n
            except ValueError:
                pass
        try:
            return int(v)
        except ValueError:
            return np.nan

    d_cols = ["D1", "D2", "D3", "D4", "D5"]
    for col in d_cols:
        df[f"{col}_num"] = df[col].apply(parse_likert)
    d_num_cols = [f"{c}_num" for c in d_cols]
    for col in d_num_cols:
        # Item-level imputation (Methods M6), distinct from the row-level
        # completeness criterion applied at acquisition (Methods M4).
        df[col] = df[col].fillna(df[col].median())
    df["D_total"] = df[d_num_cols].sum(axis=1)

    # Target label (Objective 1 / proposal definition).
    df["at_risk"] = ((df["C_pct"] < 0.60) | (df["D_total"] < 15)).astype(int)

    # Predictor encoding (Methods M7).
    df["gender_enc"] = df["gender"].map({"Male": 1, "Female": 0}).fillna(0).astype(int)
    df["age_group_enc"] = df["age_group"].map({
        "18–25 years": 1, "26–35 years": 2, "36–45 years": 3,
        "46–55 years": 4, "56 years and above": 5,
    }).fillna(0).astype(int)
    df["banking_tenure_enc"] = df["banking_tenure"].map({
        "Less than 1 year": 0, "1–3 years": 1, "4–7 years": 2,
        "8–12 years": 3, "More than 12 years": 4,
    }).fillna(0).astype(int)
    df["training_provided_enc"] = df["training_provided"].map(
        {"Yes": 2, "I am not aware": 1, "No": 0}
    ).fillna(0).astype(int)
    df["training_sessions_enc"] = df["training_sessions"].map({
        "None": 0, "1 session": 1, "2–3 sessions": 2,
        "4–5 sessions": 3, "More than 5 sessions": 4,
    }).fillna(0).astype(int)
    df["phishing_sim_enc"] = df["phishing_sim"].map({
        "Yes — and I identified the phishing attempt correctly": 2,
        "Yes — but I did not identify the phishing attempt": 1,
        "No — my bank has not conducted phishing simulations": 0,
        "I do not know what a phishing simulation is": 0,
    }).fillna(0).astype(int)
    df["training_quality_enc"] = df["training_quality"].map({
        "I have not received training": 0, "Very poor": 1, "Poor": 2,
        "Average": 3, "Good": 4, "Excellent": 5,
    }).fillna(0).astype(int)

    from sklearn.preprocessing import LabelEncoder

    def map_job_role(role):
        if pd.isna(role):
            return "Other"
        role = str(role).strip()
        mapping = {
            "Teller": "Teller", "IT": "IT", "Technology": "IT",
            "Cybersecurity": "IT", "Operations": "Operations",
            "Finance": "Finance", "Accounts": "Finance",
            "Management": "Management", "Senior Leadership": "Management",
            "Compliance": "Compliance", "Risk": "Compliance", "Legal": "Compliance",
            "Human Resources": "HR", "Audit": "Audit", "Credit": "Credit",
            "Mobile": "IT",
        }
        for key, val in mapping.items():
            if key.lower() in role.lower():
                return val
        return "Other"

    df["job_role_enc"] = LabelEncoder().fit_transform(df["job_role"].apply(map_job_role))
    df["E1_enc"] = LabelEncoder().fit_transform(
        df["E1_topic"].fillna("Unknown").apply(
            lambda x: x.split(",")[0].strip() if isinstance(x, str) else "Unknown"
        )
    )
    df["E2_enc"] = LabelEncoder().fit_transform(
        df["E2_format"].fillna("Unknown").apply(
            lambda x: x.split(",")[0].strip() if isinstance(x, str) else "Unknown"
        )
    )

    leakage_audit(CANDIDATE_FEATURES, LABEL_DERIVED_COLUMNS)
    return df


def select_features(X_train_sel_raw, y_train_sel_raw) -> list:
    """SHAP ranking + RFE feature selection (Methods M7), fit on the
    training partition only. Provided for reference; the eight features
    actually retained (SELECTED_FEATURES) are hard-coded above so that
    downstream runs are exactly reproducible without re-deriving them."""
    baseline = XGBClassifier(
        objective="binary:logistic", n_estimators=200, max_depth=4,
        learning_rate=0.1, subsample=0.8, colsample_bytree=0.8,
        use_label_encoder=False, eval_metric="logloss",
        random_state=SEED, verbosity=0,
    )
    baseline.fit(X_train_sel_raw, y_train_sel_raw)
    explainer = shap.TreeExplainer(baseline)
    shap_vals = explainer.shap_values(X_train_sel_raw)
    ranking = pd.DataFrame({
        "feature": CANDIDATE_FEATURES,
        "mean_abs_shap": np.abs(shap_vals).mean(axis=0),
    }).sort_values("mean_abs_shap", ascending=False)
    pruned = [f for f in CANDIDATE_FEATURES if f not in ranking.tail(2)["feature"].tolist()]

    rfe = RFE(
        estimator=XGBClassifier(n_estimators=100, random_state=SEED, verbosity=0,
                                 use_label_encoder=False, eval_metric="logloss"),
        n_features_to_select=min(8, len(pruned)),
    )
    rfe.fit(pd.DataFrame(X_train_sel_raw, columns=CANDIDATE_FEATURES)[pruned], y_train_sel_raw)
    return [f for f, s in zip(pruned, rfe.support_) if s]


def run_procedure_a(df: pd.DataFrame) -> dict:
    """Procedure A: repeated CV headline metrics for the proposed model,
    the unmodified baseline, and the ablation configuration (Methods M9,
    M11, M16; Results Tables 4, 5)."""
    X = df[SELECTED_FEATURES].values.astype(float)
    y = df["at_risk"].values
    folds = procedure_a_folds(X, y)

    bp, gamma, alpha = FIELD_CFG["params"], FIELD_CFG["gamma"], FIELD_CFG["alpha"]
    results = {k: {m: [] for m in ["acc", "prec", "rec", "f1", "auc", "brier"]}
               for k in ["baseline", "focal_only", "proposed"]}

    for train_idx, test_idx in folds:
        X_train_sm, y_train_sm, X_test, _ = procedure_a_fit_fold(
            X[train_idx], X[test_idx], y[train_idx]
        )
        y_test = y[test_idx]

        # Unmodified baseline (Methods M11).
        base_model = XGBClassifier(
            objective="binary:logistic", n_estimators=200, max_depth=4,
            learning_rate=0.1, subsample=0.8, colsample_bytree=0.8,
            use_label_encoder=False, eval_metric="logloss",
            random_state=SEED, verbosity=0,
        )
        base_model.fit(X_train_sm, y_train_sm)
        p = base_model.predict_proba(X_test)[:, 1]
        pr = (p >= 0.5).astype(int)
        for k, v in full_metrics(y_test, pr, p).items():
            results["baseline"][k].append(v)

        # Full proposed configuration (Methods M12).
        dtr = xgb.DMatrix(X_train_sm, label=y_train_sm)
        dte = xgb.DMatrix(X_test)
        booster = xgb.train(
            {**bp, "disable_default_eval_metric": 1}, dtr,
            num_boost_round=bp["n_estimators"], obj=focal_loss_obj(gamma, alpha),
        )
        p = sigmoid(booster.predict(dte))
        pr = (p >= 0.5).astype(int)
        for k, v in full_metrics(y_test, pr, p).items():
            results["proposed"][k].append(v)

        # Ablation intermediate: focal loss only, no independent tuning
        # (Methods M16).
        focal_only = xgb.train(
            {"max_depth": 5, "eta": 0.05, "disable_default_eval_metric": 1}, dtr,
            num_boost_round=200, obj=focal_loss_obj(1.5, 0.4),
        )
        p = sigmoid(focal_only.predict(dte))
        pr = (p >= 0.5).astype(int)
        for k, v in full_metrics(y_test, pr, p).items():
            results["focal_only"][k].append(v)

    return {model: {m: (float(np.mean(v)), float(np.std(v, ddof=1))) for m, v in metrics.items()}
            for model, metrics in results.items()}


def run_procedure_b(df: pd.DataFrame) -> dict:
    """Procedure B: single-split illustrative diagnostics for the primary
    corpus (Methods M9; Results Figure 4, Figure 6, Figure 7, Table 6)."""
    X = df[SELECTED_FEATURES].values.astype(float)
    y = df["at_risk"].values
    X_train_sm, y_train_sm, X_test, y_test, _ = procedure_b_split(X, y)

    bp, gamma, alpha = FIELD_CFG["params"], FIELD_CFG["gamma"], FIELD_CFG["alpha"]
    dtr = xgb.DMatrix(X_train_sm, label=y_train_sm)
    dte = xgb.DMatrix(X_test)
    booster = xgb.train(
        {**bp, "disable_default_eval_metric": 1}, dtr,
        num_boost_round=bp["n_estimators"], obj=focal_loss_obj(gamma, alpha),
    )
    prob = sigmoid(booster.predict(dte))
    pred = (prob >= 0.5).astype(int)

    explainer = shap.TreeExplainer(booster)
    shap_vals = explainer.shap_values(X_test)

    return {
        "y_test": y_test, "y_pred": pred, "y_prob": prob,
        "shap_values": shap_vals, "X_test": X_test,
        "n_test": len(y_test),
    }


def main():
    parser = argparse.ArgumentParser(description="Primary (field) corpus pipeline")
    parser.add_argument("--data", required=True, help="Path to the field questionnaire export (.xlsx)")
    parser.add_argument("--out", default="results/field_results.json", help="Output JSON path")
    args = parser.parse_args()

    df = load_and_prepare(args.data)
    print(f"Loaded {len(df)} records; at-risk prevalence {df['at_risk'].mean()*100:.1f}%")

    print("Running Procedure A (repeated CV)...")
    proc_a = run_procedure_a(df)
    for model, metrics in proc_a.items():
        print(f"  {model}: AUC={metrics['auc'][0]:.4f}+/-{metrics['auc'][1]:.4f}  "
              f"F1={metrics['f1'][0]:.4f}+/-{metrics['f1'][1]:.4f}")

    print("Running Procedure B (single split diagnostics)...")
    proc_b = run_procedure_b(df)
    print(f"  Procedure B test set size: {proc_b['n_test']}")

    import os
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w") as f:
        json.dump({
            "procedure_a": proc_a,
            "procedure_b_n_test": proc_b["n_test"],
        }, f, indent=2)
    print(f"Saved summary to {args.out}")


if __name__ == "__main__":
    main()
