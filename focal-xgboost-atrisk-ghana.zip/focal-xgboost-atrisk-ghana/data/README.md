# Data

## Primary corpus (FIELD) — restricted

The primary field dataset (Ghana Banking Cybersecurity Survey, n = 533)
is **not distributed** in this repository, per Methods M5 and M21:

- It contains responses collected under KNUST Committee on Human
  Research, Publications and Ethics clearance, with participant
  confidentiality protections that preclude public redistribution.
- Access may be requested from the corresponding author subject to a
  data-use agreement and institutional approval.

To run `src/field_pipeline.py`, place your own de-identified copy of the
questionnaire export locally (matching the column structure described
in Methods M4/M7) and pass its path via `--data`.

## Validation corpus (IBM HR Analytics) — public

The IBM HR Analytics Employee Attrition dataset (IBM, 2017) is openly
licensed and freely redistributable. `src/ibm_pipeline.py` downloads it
automatically on first run and caches it at
`data/ibm_hr_attrition.csv`. No manual download is required.

## This folder

Downloaded/cached data files (e.g. `ibm_hr_attrition.csv`) are written
here at runtime and are excluded from version control via `.gitignore`.
