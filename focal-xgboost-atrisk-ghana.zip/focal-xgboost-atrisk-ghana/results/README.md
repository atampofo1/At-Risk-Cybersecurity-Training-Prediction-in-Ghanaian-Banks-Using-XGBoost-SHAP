# Results

Output JSON summaries from `src/field_pipeline.py` and
`src/ibm_pipeline.py` are written here at runtime
(`field_results.json`, `ibm_results.json`).

This folder is tracked in version control (via `.gitkeep`) but its
generated contents are excluded — see `.gitignore`.
